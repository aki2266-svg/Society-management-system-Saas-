from django.contrib import admin

# Register your models here.
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Society, CustomUser

# Custom configuration for Society in Admin Panel
@admin.register(Society)
class SocietyAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_verified', 'created_at') # Columns shown in list view
    list_filter = ('is_verified',)                       # Filter sidebar
    search_fields = ('name',)
    actions = ['approve_societies']

    # Bulk action to verify societies quickly
    def approve_societies(self, request, queryset):
        queryset.update(is_verified=True)
    approve_societies.short_description = "Mark selected societies as Verified"

# Register the rest of the models

admin.site.register(CustomUser, UserAdmin) # Keeps Django's standard user layout
class CustomUserAdmin(UserAdmin):
    # Append the custom multi-tenant tracking columns into your master lists
    list_display = ('username', 'email', 'first_name', 'last_name', 'society', 'flat', 'is_staff')
    list_filter = ('role', 'society', 'is_staff', 'is_superuser')
    
    # Make custom parameters adjustable inside user administrative files
    fieldsets = UserAdmin.fieldsets + (
        ('Society Affiliation details', {'fields': ('role', 'phone_number', 'society', 'flat', 'society_name')}),
    )