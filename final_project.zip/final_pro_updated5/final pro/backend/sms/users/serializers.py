import re
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
from django.contrib.auth import authenticate, get_user_model
from .models import Society, CustomUser
from Flats.models import Flat
from django.db import transaction

User = get_user_model()

#  Shared mobile number restriction: must start with 6/7/8/9 and be exactly 10 digits
PHONE_REGEX = re.compile(r'^[6-9]\d{9}$')


def validate_mobile_number(value):
    """Raises a ValidationError if value is a non-empty string that isn't a valid
    10-digit mobile number starting with 6, 7, 8, or 9. Blank/None values are allowed
    here so existing optional-phone flows keep working; required-ness is unchanged."""
    if value in (None, ''):
        return value
    if not PHONE_REGEX.match(str(value).strip()):
        raise serializers.ValidationError(
            "Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9."
        )
    return value


class SocietyRegistrationSerializer(serializers.ModelSerializer):
    admin_first_name = serializers.CharField(write_only=True)
    admin_last_name = serializers.CharField(write_only=True)
    admin_username = serializers.CharField(write_only=True)
    admin_password = serializers.CharField(
        write_only=True,
        style={"input_type": "password"}
    )
    admin_phone = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = Society
        fields = [
            "id",
            "name",
            "address",
            "verification_proof",
            "admin_first_name",
            "admin_last_name",
            "admin_username",
            "admin_password",
            "admin_phone",
        ]

    def validate_admin_phone(self, value):
        return validate_mobile_number(value)

    def validate_verification_proof(self, file):
        try:
            file_content = file.read().decode("utf-8").lower()
            file.seek(0)

            required_keywords = [
                "society name",
                "builders name",
                "no of flats",
                "no of floors",
                "builder signature",
                "government official signature",
            ]

            for keyword in required_keywords:
                if keyword not in file_content:
                    raise serializers.ValidationError(
                        f"Invalid document. Missing keyword: '{keyword}'"
                    )

            return file

        except UnicodeDecodeError:
            raise serializers.ValidationError(
                "Upload a valid text (.txt) document."
            )

    def validate_admin_username(self, value):
        if CustomUser.objects.filter(username=value).exists():
            raise serializers.ValidationError(
                "This username already exists."
            )
        return value

    def create(self, validated_data):
        admin_first_name = validated_data.pop("admin_first_name")
        admin_last_name = validated_data.pop("admin_last_name")
        admin_username = validated_data.pop("admin_username")
        admin_password = validated_data.pop("admin_password")
        admin_phone = validated_data.pop("admin_phone", "")

        # Create Society
        society = Society.objects.create(**validated_data)

        # Create Society Admin
        user = CustomUser.objects.create_user(
            username=admin_username,
            password=admin_password,
            first_name=admin_first_name,
            last_name=admin_last_name,
            phone_number=admin_phone,
            society=society,
            society_name=society.name,
            role="society_admin",
        )

        print("Created User:", user.username)
        print("Linked Society:", user.society)

        return society


class UnifiedLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)
    society_name = serializers.CharField(required=False, allow_blank=True)

    def validate(self, data):
        username = (data.get('username') or '').strip()
        password = data.get('password')
        input_society_name = data.get('society_name', '').strip()

        # Usernames are stored with whatever casing they were registered
        # with, but people rarely remember/retype that exactly. Resolve
        # to the exact stored casing first (case-insensitive lookup) so
        # Django's authenticate() — which matches username exactly — has
        # a fair shot at the real value. This never weakens the password
        # check, it only prevents a harmless casing mismatch on the
        # username from producing a false "Invalid credentials" error.
        matched_user = CustomUser.objects.filter(username__iexact=username).first()
        lookup_username = matched_user.username if matched_user else username

        # 1. Authenticate credentials
        user = authenticate(username=lookup_username, password=password)
        if not user:
            raise serializers.ValidationError("Invalid credentials.")

        # 2. Allow Super Admins to bypass society checks completely
        if user.is_superuser or user.role == 'super_admin':
            data['user'] = user
            return data

        # 3. Block Login if Society Admin's linked Society is Unverified
        if user.role == 'society_admin':
            if not user.society:
                raise serializers.ValidationError(
                    "Your admin account is not linked to any registered society."
                )
            if not user.society.is_verified:
                raise serializers.ValidationError(
                    "Your society account is pending verification. Please wait for Super Admin approval."
                )

        # 4. Verify society name match for Residents, Guards, and Society Admins
        registered_society_name = ""
        if user.society:
            registered_society_name = user.society.name.strip().lower()
        elif user.society_name:
            registered_society_name = user.society_name.strip().lower()

        if input_society_name:
            if registered_society_name and registered_society_name != input_society_name.lower():
                raise serializers.ValidationError(
                    "This account is not registered under the specified society."
                )
        elif user.role in ['society_admin', 'resident']:
            raise serializers.ValidationError("Society name parameter is required for login.")

        # Bundle the authenticated user context if all checks pass
        data['user'] = user
        return data


class SocietyBriefSerializer(serializers.ModelSerializer):
    class Meta:
        model = Society
        fields = ['id', 'name', 'address']


class CurrentUserSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    society = SocietyBriefSerializer(read_only=True)

    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'first_name', 'last_name', 'phone_number', 'role', 'society', 'society_name']

    def get_role(self, obj):
        if obj.is_superuser:
            return 'super_admin'
        return getattr(obj, 'role', 'resident')


class ResidentRegistrationSerializer(serializers.ModelSerializer):
    role = serializers.ChoiceField(
        choices=[
            ('resident', 'Resident'),
            ('guard', 'Guard')
        ],
        required=False,
        default='resident'
    )

    class Meta:
        model = User
        fields = [
            'username',
            'password',
            'first_name',
            'last_name',
            'email',
            'phone_number',
            'role',
            'society',
            'flat',
            'flat_number',
            'block'
        ]
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def validate_phone_number(self, value):
        return validate_mobile_number(value)

    @transaction.atomic
    def create(self, validated_data):
        password = validated_data.pop('password', None)

        selected_society = validated_data.get('society')
        selected_flat = validated_data.get('flat')

        # Save society name
        if selected_society:
            validated_data['society_name'] = selected_society.name

        # Create user
        user = self.Meta.model(**validated_data)

        if password:
            user.set_password(password)

        user.save()

    
        # CREATE / UPDATE FLAT-RESIDENT PROFILE
    
        if selected_flat:
            from Flats.models import FlatResidentProfile

            profile, created = FlatResidentProfile.objects.update_or_create(
                user=user,
                defaults={
                    'flat': selected_flat
                }
            )

            # Mark flat occupied
            selected_flat.is_occupied = True
            selected_flat.save(update_fields=['is_occupied'])

        return user



class SocietySerializer(serializers.ModelSerializer):
    status = serializers.SerializerMethodField()
    admin_first_name = serializers.SerializerMethodField()
    admin_last_name = serializers.SerializerMethodField()
    admin_email = serializers.SerializerMethodField()

    class Meta:
        model = Society
        fields = [
            'id',
            'name',
            'address',
            'is_verified',
            'status',
            'created_at',
            'verification_proof',
            'admin_first_name',
            'admin_last_name',
            'admin_email',
        ]
        read_only_fields = ['created_at']

    def get_status(self, obj):
        return "approved" if obj.is_verified else "pending"

    def get_admin_first_name(self, obj):
        user = CustomUser.objects.filter(society=obj, role="society_admin").first()
        return user.first_name if user else ""

    def get_admin_last_name(self, obj):
        user = CustomUser.objects.filter(society=obj, role="society_admin").first()
        return user.last_name if user else ""

    def get_admin_email(self, obj):
        user = CustomUser.objects.filter(society=obj, role="society_admin").first()
        return user.email if user else ""