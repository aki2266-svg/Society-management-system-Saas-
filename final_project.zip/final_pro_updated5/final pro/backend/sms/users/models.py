from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings

class Society(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()
    verification_proof = models.FileField(upload_to='proofs/', null=True, blank=False)
    is_verified = models.BooleanField(default=False)
    admin = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="registered_societies"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Society"
        verbose_name_plural = "Societies"

    def __str__(self):
        return self.name


class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('super_admin', 'Super Admin'),
        ('society_admin', 'Society Admin'),
        ('resident', 'Resident'),
        ('guard', 'Guard'),  # 🟢 ADDED: Security Guard Role
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='resident')
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    society = models.ForeignKey(Society, on_delete=models.SET_NULL, null=True, blank=True)
    society_name = models.CharField(max_length=255, blank=True, null=True)
    
    flat = models.ForeignKey(
        'Flats.Flat', 
        on_delete=models.SET_NULL, 
        related_name='residents', 
        null=True, 
        blank=True,
        default=None
    )

    # 🟢 ADDED: Text fields for flat allocation when FK is not used directly
    flat_number = models.CharField(max_length=20, blank=True, null=True, help_text="e.g. A-204")
    block = models.CharField(max_length=20, blank=True, null=True, help_text="e.g. Block A")

    # 🟢 ADDED: Approval Workflow (Guards & Residents require admin verification)
    is_approved = models.BooleanField(default=False)

    # 🟢 ADDED: Helper role properties for permissions & API checks
    @property
    def is_super_admin(self):
        return self.role == 'super_admin' or self.is_superuser

    @property
    def is_society_admin(self):
        return self.role == 'society_admin'

    @property
    def is_resident(self):
        return self.role == 'resident'

    @property
    def is_guard(self):
        return self.role == 'guard'

    def save(self, *args, **kwargs):
        # Auto-approve Super Admins and Society Admins
        if self.role in ['super_admin', 'society_admin'] or self.is_superuser:
            self.is_approved = True
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"