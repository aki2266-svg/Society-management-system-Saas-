from rest_framework.permissions import AllowAny, IsAuthenticated,IsAdminUser
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import status, permissions, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import (
    SocietyRegistrationSerializer, UnifiedLoginSerializer, CurrentUserSerializer,
    ResidentRegistrationSerializer, SocietyBriefSerializer, SocietySerializer
)
from .models import Society, CustomUser


class RegisterSocietyView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = SocietyRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Society and Admin account successfully registered!"}, 
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UnifiedLoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = UnifiedLoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']

            # CHECK: Prevent unapproved accounts from logging in
            if not user.is_approved:
                return Response(
                    {"detail": "Your account is pending admin approval."},
                    status=status.HTTP_403_FORBIDDEN
                )

            refresh = RefreshToken.for_user(user)
            
            if user.is_superuser:
                role = 'super_admin'
            else:
                role = user.role  

            return Response({
                'token': str(refresh.access_token),
                'refresh': str(refresh),
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'role': role,
                    'is_approved': user.is_approved,
                    'society_name': user.society_name or (user.society.name if user.society else None)
                }
            }, status=status.HTTP_200_OK)
            
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CurrentUserView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        serializer = CurrentUserSerializer(request.user)
        return Response(serializer.data)


class ResidentRegistrationView(APIView):
    """Handles self-registration for both Residents and Guards."""
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = ResidentRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Account successfully created! Awaiting admin approval."}, 
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PendingUsersView(APIView):
    """
    GET /api/v1/auth/users/pending/
    Allows Admins to view pending (unapproved) users scoped to their society.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        
        # Ensure only admins can access this endpoint
        user_role = str(getattr(user, 'role', '')).lower()
        if not (user.is_superuser or user_role in ['society_admin', 'super_admin']):
            return Response(
                {"detail": "You do not have permission to perform this action."},
                status=status.HTTP_403_FORBIDDEN
            )

        qs = CustomUser.objects.filter(is_approved=False)
        if user_role == 'society_admin' and user.society:
            qs = qs.filter(society=user.society)

        serializer = CurrentUserSerializer(qs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class ApproveRejectUserView(APIView):
    """
    POST /api/v1/auth/users/<int:pk>/approve/
    POST /api/v1/auth/users/<int:pk>/reject/
    Allows Admins to approve or reject pending user accounts.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request, pk, action=None):
        user = request.user
        user_role = str(getattr(user, 'role', '')).lower()

        if not (user.is_superuser or user_role in ['society_admin', 'super_admin']):
            return Response(
                {"detail": "Permission denied."},
                status=status.HTTP_403_FORBIDDEN
            )

        try:
            target_user = CustomUser.objects.get(pk=pk)
        except CustomUser.DoesNotExist:
            return Response({"detail": "User not found."}, status=status.HTTP_404_NOT_FOUND)

        if action == 'approve':
            target_user.is_approved = True
            target_user.save()
            return Response({"message": f"User {target_user.username} approved successfully."})
        elif action == 'reject':
            target_user.delete()
            return Response({"message": f"User {target_user.username} application rejected and removed."})

        return Response({"detail": "Invalid action."}, status=status.HTTP_400_BAD_REQUEST)


class SocietyViewSet(viewsets.ModelViewSet):
    queryset = Society.objects.all()
    serializer_class = SocietySerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [AllowAny()]
        return [IsAuthenticated()]

    def get_queryset(self):
        queryset = Society.objects.all()
        status_param = self.request.query_params.get('status', None)
        
        if status_param is not None:
            status_param = status_param.lower()
            if status_param == 'approved':
                queryset = queryset.filter(is_verified=True)
            elif status_param in ['pending', 'rejected']:
                queryset = queryset.filter(is_verified=False)
        return queryset

    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        new_status = request.data.get('status')
        
        if new_status is not None:
            normalized_status = str(new_status).lower()
            if normalized_status == 'approved':
                instance.is_verified = True
                instance.save()
            elif normalized_status in ['rejected', 'pending']:
                instance.is_verified = False
                instance.save()
            else:
                return Response(
                    {"error": f"Invalid status choice: '{new_status}'"}, 
                    status=status.HTTP_400_BAD_REQUEST
                )

        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data, status=status.HTTP_200_OK)