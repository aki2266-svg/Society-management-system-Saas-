from django.urls import path,include
from .views import (
    RegisterSocietyView,
    UnifiedLoginView,
    CurrentUserView,
    ResidentRegistrationView,
    PendingUsersView,
    ApproveRejectUserView,
    SocietyViewSet,
)
from rest_framework.routers import DefaultRouter
router = DefaultRouter()
router.register(r'societies', SocietyViewSet, basename='society')

urlpatterns = [
    # Path: http://localhost:8000/api/v1/auth/register-society/
    path('register-society/', RegisterSocietyView.as_view(), name='register_society'),
    path('login/', UnifiedLoginView.as_view(), name='login'),
    path('me/', CurrentUserView.as_view(), name='current_user'),
    path('users/pending/', PendingUsersView.as_view(), name='pending_users'),
    path('users/<int:pk>/<str:action>/', ApproveRejectUserView.as_view(), name='approve_reject_user'),
    path('register/resident/', ResidentRegistrationView.as_view(), name='register_resident'),
    path('', include(router.urls)),
    ]