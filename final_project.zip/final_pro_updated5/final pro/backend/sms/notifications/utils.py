def notify(user, title, message, visitor=None):
    """Create a notification for a user. Imported lazily to avoid app-loading order issues."""
    from .models import Notification

    return Notification.objects.create(user=user, title=title, message=message, visitor=visitor)
