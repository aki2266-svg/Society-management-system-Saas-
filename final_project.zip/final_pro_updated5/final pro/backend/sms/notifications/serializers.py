from rest_framework import serializers

from .models import Notification


class NotificationSerializer(serializers.ModelSerializer):
    visitor_name = serializers.CharField(source="visitor.name", read_only=True, default=None)

    class Meta:
        model = Notification
        fields = ["id", "title", "message", "visitor", "visitor_name", "is_read", "created_at"]
        read_only_fields = fields
