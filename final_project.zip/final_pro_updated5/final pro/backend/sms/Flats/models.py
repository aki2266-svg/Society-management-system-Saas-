from django.db import models
from django.conf import settings
from users.models import Society

class Flat(models.Model):
    society = models.ForeignKey(Society, on_delete=models.CASCADE, related_name='flats_inventory')
    flat_number = models.CharField(max_length=50) # e.g., "B-402"
    block = models.CharField(max_length=50, blank=True, null=True)
    floor = models.IntegerField(blank=True, null=True)
    is_occupied = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('society', 'flat_number')

    def __str__(self):
        return f"{self.flat_number} - {self.society.name}"

class FlatResidentProfile(models.Model):
    """Links a registered user account to their specific physical flat layout."""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='flat_profile')
    flat = models.ForeignKey(Flat, on_delete=models.SET_NULL, null=True, blank=True, related_name='resident_profile')
    moved_in_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} lives in {self.flat.flat_number if self.flat else 'Unassigned'}"