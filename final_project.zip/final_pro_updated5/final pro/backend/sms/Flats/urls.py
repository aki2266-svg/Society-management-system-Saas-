from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import FlatViewSet, ResidentViewSet
from users.views import SocietyViewSet
from .views import SetupSocietyStructureView

router = DefaultRouter()
router.register(r'flats', FlatViewSet, basename='flat')
router.register(r'residents', ResidentViewSet, basename='resident')
router.register(r'societies', SocietyViewSet, basename='society')
urlpatterns = [
    path('', include(router.urls)),
    path('setup-structure/', SetupSocietyStructureView.as_view(), name='setup-structure'),
    
]