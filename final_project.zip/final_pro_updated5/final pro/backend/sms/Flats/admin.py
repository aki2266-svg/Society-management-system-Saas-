from django.contrib import admin
from .models import Flat
# Register your models here.
@admin.register(Flat)
class FlatAdmin(admin.ModelAdmin):
    list_display = ('flat_number', 'society', 'block', 'floor', 'is_occupied')
    list_filter = ('society', 'is_occupied')
    search_fields = ('flat_number', 'block')