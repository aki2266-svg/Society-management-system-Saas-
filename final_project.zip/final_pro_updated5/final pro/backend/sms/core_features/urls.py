from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import NoticeViewSet, ComplaintViewSet, BillViewSet, DashboardOverviewMetricsView

router = DefaultRouter()
router.register(r'notices', NoticeViewSet, basename='notice')
router.register(r'complaints', ComplaintViewSet, basename='complaint')
router.register(r'bills', BillViewSet, basename='bill')

urlpatterns = [
    path('dashboard/summary/', DashboardOverviewMetricsView.as_view(), name='dashboard-summary'),
    path('', include(router.urls)),
]