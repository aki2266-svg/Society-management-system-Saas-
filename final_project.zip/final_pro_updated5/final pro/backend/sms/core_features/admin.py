from django.contrib import admin
from .models import Notice,Complaint,Bill
admin.site.register(Notice)
admin.site.register(Complaint)
admin.site.register(Bill)
# Register your models here.
class NoticeAdmin(admin.ModelAdmin):
    list_display = ('title', 'society', 'created_at')
    list_filter = ('society', 'created_at')
    search_fields = ('title', 'content')
    
    # Exclude the society field from the manual form if you want it to auto-assign
    # fields = ('title', 'content') 

    def save_model(self, request, obj, form, change):
        # Automatically assign the notice to the logged-in admin's society
        if not obj.society_id and hasattr(request.user, 'society'):
            obj.society = request.user.society
        super().save_model(request, obj, form, change)