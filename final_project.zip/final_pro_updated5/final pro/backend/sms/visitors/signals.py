# Notification side-effects for visitor status changes are triggered explicitly
# from visitors/views.py (perform_create, VisitorDecisionView) rather than via
# post_save signals, so we have control over the exact message text per action.
# This file is kept as the registered signals module for future extension
# (e.g. SMS/email hooks) without needing to touch views.py.
