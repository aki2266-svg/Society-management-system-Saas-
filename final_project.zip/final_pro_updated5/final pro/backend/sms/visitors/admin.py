from django.contrib import admin

from .models import Visitor


@admin.register(Visitor)
class VisitorAdmin(admin.ModelAdmin):
    list_display = ("name", "resident", "logged_by", "status", "requested_at")
    list_filter = ("status", "purpose")
    search_fields = ("name", "phone", "resident__flat_number")
