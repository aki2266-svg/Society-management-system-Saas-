from django.urls import path

from .views import (
    VisitorListCreateView, VisitorDetailView, VisitorDecisionView,
    VisitorCheckInView, VisitorCheckOutView, DashboardStatsView,
)

urlpatterns = [
    path("", VisitorListCreateView.as_view(), name="visitor-list-create"),
    path("stats/", DashboardStatsView.as_view(), name="visitor-stats"),
    path("<int:pk>/", VisitorDetailView.as_view(), name="visitor-detail"),
    path("<int:pk>/decision/", VisitorDecisionView.as_view(), name="visitor-decision"),
    path("<int:pk>/check-in/", VisitorCheckInView.as_view(), name="visitor-check-in"),
    path("<int:pk>/check-out/", VisitorCheckOutView.as_view(), name="visitor-check-out"),
]
