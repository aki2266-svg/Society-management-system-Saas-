from rest_framework import serializers

from .models import Visitor


class VisitorSerializer(serializers.ModelSerializer):
    resident_name = serializers.CharField(source="resident.get_full_name", read_only=True)
    flat_number = serializers.CharField(source="resident.flat_number", read_only=True)
    logged_by_name = serializers.CharField(source="logged_by.get_full_name", read_only=True)

    class Meta:
        model = Visitor
        fields = [
            "id", "name", "phone", "purpose", "vehicle_number", "photo", "notes",
            "resident", "resident_name", "flat_number", "logged_by", "logged_by_name",
            "status", "requested_at", "decided_at", "entry_time", "exit_time",
        ]
        read_only_fields = [
            "id", "logged_by", "status", "requested_at", "decided_at",
            "entry_time", "exit_time", "resident_name", "flat_number", "logged_by_name",
        ]


class VisitorCreateSerializer(serializers.ModelSerializer):
    """Used by guards to log a new visitor entry request."""

    class Meta:
        model = Visitor
        fields = ["id", "name", "phone", "purpose", "vehicle_number", "photo", "notes", "resident"]

    def validate_resident(self, value):
        if str(getattr(value, 'role', '')).lower() != "resident":
            raise serializers.ValidationError("Selected user is not a resident.")
        return value
