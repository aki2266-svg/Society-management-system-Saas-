from django.conf import settings
from django.db import models


class Visitor(models.Model):
    class Purpose(models.TextChoices):
        GUEST = "GUEST", "Guest"
        DELIVERY = "DELIVERY", "Delivery"
        CAB = "CAB", "Cab / Auto"
        SERVICE = "SERVICE", "Service / Maintenance"
        OTHER = "OTHER", "Other"

    class Status(models.TextChoices):
        PENDING = "PENDING", "Pending approval"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        CHECKED_IN = "CHECKED_IN", "Checked in"
        CHECKED_OUT = "CHECKED_OUT", "Checked out"

    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    purpose = models.CharField(max_length=10, choices=Purpose.choices, default=Purpose.GUEST)
    vehicle_number = models.CharField(max_length=20, blank=True)
    photo = models.ImageField(upload_to="visitor_photos/", blank=True, null=True)
    notes = models.CharField(max_length=255, blank=True)

    resident = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="visitor_requests", limit_choices_to={"role": "resident"},
    )
    logged_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="visitors_logged", limit_choices_to={"role": "guard"},
    )

    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING)

    requested_at = models.DateTimeField(auto_now_add=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    entry_time = models.DateTimeField(null=True, blank=True)
    exit_time = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-requested_at"]

    def __str__(self):
        return f"{self.name} -> {self.resident.flat_number} ({self.status})"
