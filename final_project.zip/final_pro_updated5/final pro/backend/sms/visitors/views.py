from django.utils import timezone
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import BasePermission

from notifications.utils import notify
from .models import Visitor
from .serializers import VisitorSerializer, VisitorCreateSerializer


# --- INLINE PERMISSION CLASSES (Defined directly in this file) ---

class IsResident(BasePermission):
    def has_permission(self, request, view):
        return (
            request.user 
            and request.user.is_authenticated 
            and str(getattr(request.user, 'role', '')).lower() == 'resident'
        )

class IsGuard(BasePermission):
    def has_permission(self, request, view):
        return (
            request.user 
            and request.user.is_authenticated 
            and str(getattr(request.user, 'role', '')).lower() == 'guard'
        )

class IsGuardOrAdmin(BasePermission):
    def has_permission(self, request, view):
        if not (request.user and request.user.is_authenticated):
            return False
        user_role = str(getattr(request.user, 'role', '')).lower()
        return user_role in ['guard', 'society_admin', 'super_admin'] or request.user.is_superuser


# --- VIEWS ---

class VisitorListCreateView(generics.ListCreateAPIView):
    def get_permissions(self):
        if self.request.method == "POST":
            return [IsGuard()]
        return [permissions.IsAuthenticated()]

    def get_serializer_class(self):
        return VisitorCreateSerializer if self.request.method == "POST" else VisitorSerializer

    def get_queryset(self):
        user = self.request.user
        qs = Visitor.objects.select_related("resident", "logged_by")
        user_role = str(getattr(user, 'role', '')).lower()

        if user_role == "resident":
            qs = qs.filter(resident=user)
        elif user_role == "guard":
            qs = qs.filter(logged_by=user)

        status_param = self.request.query_params.get("status")
        if status_param:
            qs = qs.filter(status=status_param.upper())
        return qs

    def perform_create(self, serializer):
        visitor = serializer.save(logged_by=self.request.user, status=Visitor.Status.PENDING)
        notify(
            user=visitor.resident,
            title="New visitor at the gate",
            message=f"{visitor.name} ({visitor.get_purpose_display()}) is requesting entry.",
            visitor=visitor,
        )


class VisitorDetailView(generics.RetrieveAPIView):
    serializer_class = VisitorSerializer
    permission_classes = [permissions.IsAuthenticated]
    queryset = Visitor.objects.select_related("resident", "logged_by")


class VisitorDecisionView(APIView):
    permission_classes = [IsResident]

    def post(self, request, pk):
        try:
            visitor = Visitor.objects.get(pk=pk, resident=request.user)
        except Visitor.DoesNotExist:
            return Response({"detail": "Visitor request not found."}, status=status.HTTP_404_NOT_FOUND)

        if visitor.status != Visitor.Status.PENDING:
            return Response({"detail": "This request has already been decided."}, status=status.HTTP_400_BAD_REQUEST)

        decision = request.data.get("decision")
        if decision not in ("APPROVED", "REJECTED"):
            return Response({"detail": "decision must be APPROVED or REJECTED."}, status=status.HTTP_400_BAD_REQUEST)

        visitor.status = decision
        visitor.decided_at = timezone.now()
        visitor.save()

        if visitor.logged_by:
            verb = "approved" if decision == "APPROVED" else "rejected"
            notify(
                user=visitor.logged_by,
                title=f"Visitor {verb}",
                message=f"{visitor.resident.get_full_name() or visitor.resident.flat_number} {verb} the entry for {visitor.name}.",
                visitor=visitor,
            )

        return Response(VisitorSerializer(visitor).data)


class VisitorCheckInView(APIView):
    permission_classes = [IsGuardOrAdmin]

    def post(self, request, pk):
        try:
            visitor = Visitor.objects.get(pk=pk)
        except Visitor.DoesNotExist:
            return Response({"detail": "Visitor not found."}, status=status.HTTP_404_NOT_FOUND)

        if visitor.status != Visitor.Status.APPROVED:
            return Response({"detail": "Only approved visitors can be checked in."}, status=status.HTTP_400_BAD_REQUEST)

        visitor.status = Visitor.Status.CHECKED_IN
        visitor.entry_time = timezone.now()
        visitor.save()
        return Response(VisitorSerializer(visitor).data)


class VisitorCheckOutView(APIView):
    permission_classes = [IsGuardOrAdmin]

    def post(self, request, pk):
        try:
            visitor = Visitor.objects.get(pk=pk)
        except Visitor.DoesNotExist:
            return Response({"detail": "Visitor not found."}, status=status.HTTP_404_NOT_FOUND)

        if visitor.status != Visitor.Status.CHECKED_IN:
            return Response({"detail": "Only checked-in visitors can be checked out."}, status=status.HTTP_400_BAD_REQUEST)

        visitor.status = Visitor.Status.CHECKED_OUT
        visitor.exit_time = timezone.now()
        visitor.save()
        return Response(VisitorSerializer(visitor).data)


class DashboardStatsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        qs = Visitor.objects.all()
        user_role = str(getattr(user, 'role', '')).lower()

        if user_role == "resident":
            qs = qs.filter(resident=user)
        elif user_role == "guard":
            qs = qs.filter(logged_by=user)

        today = timezone.now().date()
        return Response({
            "pending": qs.filter(status=Visitor.Status.PENDING).count(),
            "checked_in": qs.filter(status=Visitor.Status.CHECKED_IN).count(),
            "today_total": qs.filter(requested_at__date=today).count(),
            "total": qs.count(),
        })