"""
URL configuration for sms project.
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

    path('admin/', admin.site.urls),
    
    
    path('api/v1/auth/', include('users.urls')),
    path('api/v1/numbers/', include('phnumbers.urls')),  # Clean single v1 endpoint
   
    
    path('api/v1/', include('core_features.urls')),
    path('api/v1/', include('Flats.urls')),
    path("api/visitors/", include("visitors.urls")),
    path("api/notifications/", include("notifications.urls")),
]

# CRITICAL FOR FILE UPLOADS
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)