from django.db import models

# Create your models here.


class EmergencyNumber(models.Model):
    service = models.CharField(max_length=150, help_text="e.g., Main Gate Security, Fire Station")
    contact = models.CharField(max_length=20, help_text="Phone number or shortcode")
    operational_hours = models.CharField(max_length=100, default="24/7", help_text="e.g., 24/7 or 9 AM - 8 PM")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']
        verbose_name = "Emergency Number"
        verbose_name_plural = "Emergency Numbers"

    def __str__(self):
        return f"{self.service} - {self.contact}"


class Worker(models.Model):
    name = models.CharField(max_length=150)
    role = models.CharField(max_length=100, help_text="e.g., Electrician, Plumber, Cleaner")
    phone = models.CharField(max_length=10)
    address = models.TextField(help_text="Residential or agency workspace address of the worker")
    availability = models.CharField(max_length=100, help_text="e.g., 9 AM - 6 PM or On-Call")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['id']
        verbose_name = "Worker"
        verbose_name_plural = "Workers"

    def __str__(self):
        return f"{self.name} ({self.role})"