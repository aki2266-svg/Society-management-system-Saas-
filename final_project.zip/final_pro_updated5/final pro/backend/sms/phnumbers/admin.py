from django.contrib import admin

# Register your models here.


from .models import EmergencyNumber, Worker

@admin.register(EmergencyNumber)
class EmergencyNumberAdmin(admin.ModelAdmin):
    list_display = ('service', 'contact', 'operational_hours')
    search_fields = ('service',)

@admin.register(Worker)
class WorkerAdmin(admin.ModelAdmin):
    list_display = ('name', 'role', 'phone', 'availability')
    list_filter = ('role',)
    search_fields = ('name', 'role', 'address')