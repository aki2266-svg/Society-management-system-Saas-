from django.apps import AppConfig


class PhnumbersConfig(AppConfig):
    name = 'phnumbers'
