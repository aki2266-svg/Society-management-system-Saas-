# numbers/serializers.py
from rest_framework import serializers
from .models import EmergencyNumber, Worker

class EmergencyNumberSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmergencyNumber
        fields = ['id', 'service', 'contact', 'operational_hours']

class WorkerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Worker
        fields = '__all__'