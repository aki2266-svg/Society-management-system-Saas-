# numbers/views.py
from rest_framework import viewsets
from rest_framework.decorators import api_view
from rest_framework.permissions import IsAuthenticatedOrReadOnly, BasePermission, SAFE_METHODS
from .models import EmergencyNumber, Worker
from .serializers import EmergencyNumberSerializer, WorkerSerializer
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import BasePermission, SAFE_METHODS

class IsAdminUserOrReadOnly(BasePermission):
    """
    Custom permission to only allow administrators to edit an object.
    Anyone can view (GET).
    """
    def has_permission(self, request, view):
        # Read-only actions are open to anyone
        if request.method in SAFE_METHODS:
            return True
        
        # Write actions require user to be authenticated AND an admin
        return (
            request.user and 
            request.user.is_authenticated and 
            (request.user.is_staff or request.user.is_superuser)
        )
class CanManageWorkers(BasePermission):
    """
    - All authenticated users (Residents & Admins) can GET/READ workers.
    - Only Admins, Superadmins, and Staff can POST, PUT, PATCH, or DELETE.
    """
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False

        if request.method in SAFE_METHODS:
            return True

        if request.user.is_superuser or request.user.is_staff:
            return True

        user_role = str(getattr(request.user, 'role', '')).lower()
        return user_role in ['society_admin', 'admin', 'super_admin']

class EmergencyNumberViewSet(viewsets.ModelViewSet):
    queryset = EmergencyNumber.objects.all()
    serializer_class = EmergencyNumberSerializer
    # Requires a user to be logged in to add/edit numbers; anyone can view them.
    permission_classes = [IsAuthenticatedOrReadOnly] 


class WorkerViewSet(viewsets.ModelViewSet):
    queryset = Worker.objects.all()
    serializer_class = WorkerSerializer
    authentication_classes = [JWTAuthentication]
    permission_classes = [CanManageWorkers]

    def get_queryset(self):
        user = self.request.user
        if not user or not user.is_authenticated:
            return Worker.objects.none()

        try:
            #  Check direct society link on User (Admins)
            society = getattr(user, 'society', None)

            #  Check resident flat relationship safely
            if not society:
                flat_profile = getattr(user, 'flat_profile', None)
                if flat_profile:
                    flat = getattr(flat_profile, 'flat', None)
                    if flat:
                        society = getattr(flat, 'society', None)

            #  Filter if society is found and Worker model has 'society' field
            if society and hasattr(Worker, 'society'):
                return Worker.objects.filter(society=society)

        except Exception as e:
            # Prevent 500 error on query failure
            print(f"Error filtering worker queryset: {e}")

        # Fallback return all workers
        return Worker.objects.all()

    def perform_create(self, serializer):
        user = self.request.user
        society = getattr(user, 'society', None)

        # Only pass society if the user has one assigned and the serializer accepts it
        if society and 'society' in serializer.fields:
            serializer.save(society=society)
        else:
            serializer.save()        