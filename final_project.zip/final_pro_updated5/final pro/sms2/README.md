# NestOS — Society Management System (Frontend)

React + Vite + Tailwind CSS frontend for a multi-tenant Society Management System.
Three roles are supported out of the box:

- **super_admin** — approves/rejects new society registrations
- **society_admin** — manages residents, flats, bills, complaints, notices for their own society
- **resident** — views/pays bills, raises complaints, reads notices

## 1. Setup

```bash
npm install
npm run dev
```

The app runs at `http://localhost:5173`.

To create a production build:

```bash
npm run build
```

## 2. Connecting to your Django backend

All API calls live under `src/api/`. Change the base URL in `src/api/axios.js`:

```js
export const BASE_URL = 'http://localhost:8000/api/v1'
```

### Expected endpoints

| Purpose | Method & path | Notes |
|---|---|---|
| Register society | `POST /auth/register-society/` | `multipart/form-data`, see original spec below |
| Login | `POST /auth/login/` | body `{ username, password }`, must return `{ token, user: { id, username, name, role } }`. `role` must be one of `super_admin`, `society_admin`, `resident` |
| Current user | `GET /auth/me/` | optional, not currently called but available |
| List societies | `GET /societies/?status=pending` | for super admin approval queue |
| Approve/reject society | `PATCH /societies/:id/` | body `{ status: 'approved' \| 'rejected' }` |
| List/add/remove residents | `GET/POST/DELETE /residents/` | |
| List/add/remove flats | `GET/POST/DELETE /flats/` | flat objects expected to include `is_occupied` |
| List/add/remove bills | `GET/POST/DELETE /bills/` | bill objects expected to include `status`: `unpaid` \| `paid` |
| Pay a bill | `POST /bills/:id/pay/` | body `{ method }` |
| List/add complaints | `GET/POST /complaints/` | |
| Update complaint status | `PATCH /complaints/:id/` | body `{ status: 'open' \| 'in_progress' \| 'resolved' }` |
| List/add/remove notices | `GET/POST/DELETE /notices/` | |

All authenticated requests automatically send `Authorization: Bearer <token>` (the token
returned from login, stored in `localStorage`). If your Django backend uses a different
auth scheme (e.g. DRF Token auth uses `Authorization: Token <token>`), update the header
in `src/api/axios.js`.

### Registration document rules (from the original spec)

The verification `.txt` file uploaded on registration must contain these lines for the
backend validator to accept it:

- society name
- builders name
- no of flats
- no of floors
- builder signature
- government official signature

## 3. Project structure

```
src/
  api/            One file per resource (auth, societies, residents, billing, complaints, notices)
  context/        AuthContext — login state, role, token handling
  components/     Shared UI: Navbar, Sidebar, DashboardLayout, ProtectedRoute, Modal, Badge, etc.
  pages/          One file per screen
  App.jsx         Route definitions, grouped by role
```

## 4. Notes for your viva / demo

- Routing is role-gated: `ProtectedRoute` redirects unauthenticated users to `/login`,
  and redirects users to `/` if they try to access a page outside their role.
- The registration flow does not log the admin in immediately — it shows a
  "pending review" screen, matching the document-gated approval workflow.
- All list pages handle loading, empty, and error states so the UI never looks broken
  if the backend isn't reachable yet.
