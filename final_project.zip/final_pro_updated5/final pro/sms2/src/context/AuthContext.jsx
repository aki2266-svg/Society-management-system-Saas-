import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import api from '../api/api'

const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  // 1. Initialize user state safely from localStorage
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('sms_user') || localStorage.getItem('vms_user')
    return stored ? JSON.parse(stored) : null
  })

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // 2. CRITICAL SYNC HOOK: Verify token and re-apply Authorization header on mount/refresh
  useEffect(() => {
    const token = localStorage.getItem('sms_token') || localStorage.getItem('vms_access')
    const storedUser = localStorage.getItem('sms_user') || localStorage.getItem('vms_user')

    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
      
      // Verify active session with backend (/api/v1/auth/me/)
      api
        .get('/api/v1/auth/me/')
        .then((res) => {
          setUser(res.data)
          localStorage.setItem('sms_user', JSON.stringify(res.data))
        })
        .catch(() => {
          // Fallback to local cache if network/endpoint fails
          if (storedUser && !user) {
            setUser(JSON.parse(storedUser))
          }
        })
        .finally(() => setLoading(false))
    } else {
      if (storedUser && !user) {
        setUser(JSON.parse(storedUser))
      }
      setLoading(false)
    }
  }, [])

  // 3. Login Function (/api/v1/auth/login/)
  const login = useCallback(async (credentials, passwordArg) => {
    try {
      setLoading(true)
      setError('')

      const payload = typeof credentials === 'object' ? credentials : { username: credentials, password: passwordArg }
      const response = await api.post('/api/v1/auth/login/', payload)

      const token = response.data.token || response.data.access
      const refreshToken = response.data.refresh
      const userData = response.data.user || response.data

      if (token) {
        localStorage.setItem('sms_token', token)
        localStorage.setItem('vms_access', token)
        if (refreshToken) localStorage.setItem('vms_refresh', refreshToken)
        localStorage.setItem('sms_user', JSON.stringify(userData))
        localStorage.setItem('vms_user', JSON.stringify(userData))
        
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`
        setUser(userData)
      }

      return response.data
    } catch (err) {
      const errMsg = err.response?.data?.detail || err.response?.data?.non_field_errors?.[0] || 'Login failed'
      setError(errMsg)
      console.error("Login failed:", err.response?.data || err.message)
      throw err
    } finally {
      setLoading(false)
    }
  }, [])

  // 4. Register Function (/api/v1/auth/register/)
  const register = useCallback(async (payload) => {
    try {
      setLoading(true)
      setError('')
      const res = await api.post('/api/v1/auth/register/resident/', payload)
      return res.data
    } catch (err) {
      const errMsg = err.response?.data?.detail || err.response?.data?.non_field_errors?.[0] || 'Registration failed'
      setError(errMsg)
      throw err
    } finally {
      setLoading(false)
    }
  }, [])

  // 5. Logout Function
  const logout = useCallback(() => {
    localStorage.removeItem('sms_token')
    localStorage.removeItem('sms_user')
    localStorage.removeItem('vms_access')
    localStorage.removeItem('vms_refresh')
    localStorage.removeItem('vms_user')
    delete api.defaults.headers.common['Authorization']
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider value={{ user, setUser, login, register, logout, loading, error, setError }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) throw new Error("useAuth must be used within AuthProvider")
  
  // Matched with backend roles: 'society_admin', 'super_admin', or superuser
  const isAdmin = context.user?.role === 'society_admin' || context.user?.role === 'super_admin' || context.user?.is_superuser
  return { ...context, isAdmin }
}