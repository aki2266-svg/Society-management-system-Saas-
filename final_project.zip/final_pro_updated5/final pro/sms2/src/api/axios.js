import axios from 'axios'

// Change this to your deployed Django API base URL when you go live.
export const BASE_URL = 'http://localhost:8000/api/v1'

const api = axios.create({
  baseURL: BASE_URL,
})

// Attach the JWT/token automatically on every request, if we have one.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('sms_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
},
(error) => {
    return Promise.reject(error);
}
)

// If the backend says the token is invalid/expired, log the user out.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('sms_token')
      localStorage.removeItem('sms_user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api
