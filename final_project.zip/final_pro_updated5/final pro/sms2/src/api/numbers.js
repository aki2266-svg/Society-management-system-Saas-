// src/api/numbers.js
import api from '../api/api'; // Ensure path to api.js is correct

// ==========================================
// EMERGENCY NUMBERS ENDPOINTS
// ==========================================

export const fetchEmergencyNumbers = () => {
  return api.get('/api/v1/numbers/');
};

export const addEmergencyNumber = (data) => {
  return api.post('/api/v1/numbers/', data);
};

// ==========================================
// WORKERS ENDPOINTS
// ==========================================

export const fetchWorkers = () => {
  // Registered via router in numbers/urls.py
  return api.get('/api/v1/numbers/workers/');
};

export const addWorker = (data) => {
  return api.post('/api/v1/numbers/workers/', data);
};