import api from './api'

// 🟢 Unified with your Django /api/v1/ versioned prefix namespace
export const listNotices = () => {
  return api.get('/api/v1/notices/')
}

export const createNotice = (noticeData) => {
  return api.post('/api/v1/notices/', noticeData)
}

export const deleteNotice = (id) => {
  return api.delete(`/api/v1/notices/${id}/`)
}