// src/api/complaints.js
import api from './axios'

export const fetchComplaints = () => {
  return api.get('/complaints/')
}

export const listComplaints = fetchComplaints

export const createComplaint = (complaintData) => {
  return api.post('/complaints/', complaintData)
}

export const fetchDashboardSummary = () => {
  return api.get('/dashboard/summary/')
}