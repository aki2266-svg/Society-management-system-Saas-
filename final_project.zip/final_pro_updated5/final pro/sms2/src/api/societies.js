import api from './axios'

// GET /api/v1/societies/?status=pending|approved|rejected
export const listSocieties = (status) =>
  api.get('/auth/societies/', { params: status ? { status } : {} })

// PATCH /api/v1/societies/:id/  { status: 'approved' | 'rejected' }
export const updateSocietyStatus = (id, status) =>
  api.patch(`/auth/societies/${id}/`, { status })
