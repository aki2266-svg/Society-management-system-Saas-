import api from './axios'


export const registerSociety = (formData) =>
  api.post('/auth/register-society/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export const login = (username, password) =>
  api.post('/auth/login/', { 
    username: username, 
    password: password 
  })

// 3. GET /api/v1/auth/me/
export const getCurrentUser = () => api.get('/auth/me/')