import api from './axios'

// GET /api/v1/residents/
export const listResidents = () => api.get('/residents/')

// POST /api/v1/residents/
export const createResident = (data) => api.post('/auth/register/resident/', data)

// PATCH /api/v1/residents/:id/
export const updateResident = (id, data) => api.patch(`/residents/${id}/`, data)

// DELETE /api/v1/residents/:id/
export const deleteResident = (id) => api.delete(`/residents/${id}/`)

// GET /api/v1/flats/
export const listFlats = () => api.get('/flats/')

// POST /api/v1/flats/
export const createFlat = (data) => api.post('/flats/', data)

// PATCH /api/v1/flats/:id/
export const updateFlat = (id, data) => api.patch(`/flats/${id}/`, data)

// DELETE /api/v1/flats/:id/
export const deleteFlat = (id) => api.delete(`/flats/${id}/`)
