import api from './axios'

// GET /api/v1/bills/  (admin: all bills, resident: own bills only)
export const listBills = () => api.get('/bills/')

// POST /api/v1/bills/  { flat, title, amount, due_date }
export const createBill = (data) => api.post('/bills/', data)

// DELETE /api/v1/bills/:id/
export const deleteBill = (id) => api.delete(`/bills/${id}/`)

// POST /api/v1/bills/:id/pay/  { method }
export const payBill = (id, method) => api.post(`/bills/${id}/pay/`, { method })

// GET /api/v1/payments/
export const listPayments = () => api.get('/payments/')
