// src/App.jsx
import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Layout from './components/Layout'

import Login from './pages/Login'
import Register from './pages/Register'
import RegisterSociety from './pages/RegisterSociety'
import RegisterResident from './pages/ResidentRegister'
import RegisterSuccess from './pages/RegisterSuccess'

import SuperAdminDashboard from './pages/SuperAdminDashboard'
import AdminDashboard from './pages/AdminDashboard'
import Residents from './pages/Residents'
import Flats from './pages/Flats'
import Bills from './pages/Bills'
import Complaints from './pages/Complaints'
import Notices from './pages/Notices'

import GuardDashboard from './pages/GuardDashboard'
import ResidentDashboard from './pages/ResidentDashboard'
import ResidentBills from './pages/ResidentBills'
import ResidentComplaints from './pages/ResidentComplaints'
import ResidentNotices from './pages/ResidentNotices'

// 1. The Lookup Map (supports normalized and uppercase backend roles)
const roleHome = {
  super_admin: '/super-admin',
  superadmin: '/super-admin',
  society_admin: '/admin',
  admin: '/admin',
  ADMIN: '/admin',
  guard: '/guard',
  GUARD: '/guard',
  resident: '/resident',
  RESIDENT: '/resident',
}

// 2. THE ROUTE BALANCER: Distinguishes users on the root path "/" and renders direct components or redirects
const Home = () => {
  const { user } = useAuth()
  
  if (!user) return <Navigate to="/login" replace />
  
  // Normalize key to resolve target route seamlessly
  const normalizedRole = user.role ? String(user.role).toLowerCase() : ''
  const targetRoute = roleHome[user.role] || roleHome[normalizedRole]

  console.log("Root balancing for user:", user.username, "Role:", user.role)

  if (targetRoute) {
    return <Navigate to={targetRoute} replace />
  }

  // Direct component fallback matching state logic from snippet 1
  const DashboardComponent = {
    RESIDENT: ResidentDashboard,
    resident: ResidentDashboard,
    GUARD: GuardDashboard,
    guard: GuardDashboard,
    ADMIN: AdminDashboard,
    admin: AdminDashboard,
    society_admin: AdminDashboard,
  }[user.role]

  if (DashboardComponent) {
    return (
      <Layout>
        <DashboardComponent />
      </Layout>
    )
  }

  return <Navigate to="/login" replace />
}

function App() {
  return (
    <Routes>
      {/* Root route manages the redirect entry point */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Home />
          </ProtectedRoute>
        }
      />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/register-society" element={<RegisterSociety />} />
      <Route path="/register-resident" element={<RegisterResident />} />
      <Route path="/register-success" element={<RegisterSuccess />} />

      {/* Super Admin Route */}
      <Route
        path="/super-admin"
        element={
          <ProtectedRoute roles={['super_admin', 'superadmin']}>
            <SuperAdminDashboard />
          </ProtectedRoute>
        }
      />

      {/* 🏢 Society Admin Protected Layout Group */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute roles={['society_admin', 'admin', 'ADMIN']}>
            <AdminDashboard />
          </ProtectedRoute>
        }
      >
        {/* Sub-routes under /admin */}
        <Route index element={<div>Welcome to Admin Overview Panel</div>} />
        <Route path="residents" element={<Residents />} />
        <Route path="flats" element={<Flats />} />
        <Route path="bills" element={<Bills />} />
        <Route path="complaints" element={<Complaints />} />
        <Route path="notices" element={<Notices />} />
      </Route>

      {/* 🛡️ Guard Protected Route */}
      <Route
        path="/guard"
        element={
          <ProtectedRoute roles={['guard', 'GUARD']}>
            <GuardDashboard />
          </ProtectedRoute>
        }
      />

      {/* Resident Protected Layout Group */}
      <Route
        path="/resident"
        element={
          <ProtectedRoute roles={['resident', 'RESIDENT']}>
            <ResidentDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/resident/bills"
        element={
          <ProtectedRoute roles={['resident', 'RESIDENT']}>
            <ResidentBills />
          </ProtectedRoute>
        }
      />
      <Route
        path="/resident/complaints"
        element={
          <ProtectedRoute roles={['resident', 'RESIDENT']}>
            <ResidentComplaints />
          </ProtectedRoute>
        }
      />
      <Route
        path="/resident/notices"
        element={
          <ProtectedRoute roles={['resident', 'RESIDENT']}>
            <ResidentNotices />
          </ProtectedRoute>
        }
      />

      {/* Catch-all fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default App