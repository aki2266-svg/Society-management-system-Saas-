import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import NotificationBell from "./NotificationBell";

const NAV = {
  RESIDENT: [{ to: "/", label: "Visitor requests", icon: "door" }],
  GUARD: [{ to: "/", label: "Gate desk", icon: "shield" }],
  ADMIN: [{ to: "/", label: "Overview", icon: "grid" }],
};

const ICONS = {
  door: (
    <path d="M5 21V5a2 2 0 0 1 2-2h6l4 4v14M9 12h.01" strokeLinecap="round" strokeLinejoin="round" />
  ),
  shield: <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" strokeLinecap="round" strokeLinejoin="round" />,
  grid: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </>
  ),
};

export default function Layout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const items = NAV[user.role] || [];

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen flex bg-ink-50">
      <aside className="w-60 shrink-0 bg-ink-950 text-ink-100 flex flex-col">
        <div className="px-6 py-6 flex items-center gap-2.5">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#F0654A" strokeWidth="2.4">
            <path d="M4 20V6a2 2 0 0 1 2-2h5v16" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M11 8h9v12" className="gate-bar raised" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-display font-semibold text-lg tracking-tight">Gatekeeper</span>
        </div>

        <nav className="flex-1 px-3 space-y-1">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  isActive ? "bg-ink-800 text-white" : "text-ink-300 hover:bg-ink-900 hover:text-white"
                }`
              }
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                {ICONS[item.icon]}
              </svg>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-4 py-5 border-t border-ink-800">
          <p className="text-xs text-ink-400 font-mono">{user.role}</p>
          <p className="text-sm font-semibold truncate">{user.first_name || user.username}</p>
          {user.flat_number && <p className="text-xs text-ink-400">{user.flat_number}</p>}
          <button
            onClick={handleLogout}
            className="mt-3 text-xs font-semibold text-signal-stop hover:underline"
          >
            Sign out
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-ink-100 bg-white flex items-center justify-between px-8">
          <p className="text-sm text-ink-400">
            {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}
          </p>
          <NotificationBell />
        </header>
        <main className="flex-1 p-8 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
