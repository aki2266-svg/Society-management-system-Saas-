import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const roleLabel = {
  super_admin: 'Platform Admin',
  society_admin: 'Society Admin',
  resident: 'Resident',
  guard: 'Guard',
}

const getInitials = (name = '') => {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase()
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
}

const Navbar = () => {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const displayName = user?.name || user?.first_name || user?.username || ''

  return (
    <header className="h-16 bg-blueprint-900 text-white flex items-center justify-between px-6 shrink-0 border-b border-black/20 shadow-sm z-10">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center font-display font-bold text-blueprint-950 shadow-sm">
          N
        </div>
        <span className="font-display font-semibold tracking-tight text-lg">NestOS</span>
      </div>

      {user && (
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 pr-3 border-r border-white/10">
            <div className="w-8 h-8 rounded-full bg-blueprint-700 border border-white/10 flex items-center justify-center text-xs font-semibold text-amber-400">
              {getInitials(displayName)}
            </div>
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium leading-tight">{displayName}</p>
              <p className="text-xs text-blueprint-100/60 leading-tight">{roleLabel[user.role] || user.role}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="text-sm font-medium bg-blueprint-800 hover:bg-blueprint-700 active:scale-95 transition-all px-3.5 py-1.5 rounded-md border border-white/5"
          >
            Log out
          </button>
        </div>
      )}
    </header>
  )
}

export default Navbar
