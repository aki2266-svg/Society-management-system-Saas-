import React from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// Wrap any page that needs a logged-in user. Pass `roles` to restrict
// the page to specific roles, e.g. <ProtectedRoute roles={['society_admin']}>
const ProtectedRoute = ({ children, roles }) => {
  const { user } = useAuth()

  if (!user) {
    return <Navigate to="/login" replace />
  }

  if (roles && !roles.includes(user.role)) {
    return <Navigate to="/" replace />
  }

  return children
}

export default ProtectedRoute
