import { useEffect, useRef, useState } from "react";
import client from "../api/client";

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const boxRef = useRef(null);

  const fetchUnread = () => {
    client
      .get("/notifications/unread-count/")
      .then((res) => setUnread(res.data.unread_count))
      .catch(() => {});
  };

  const fetchList = () => {
    client
      .get("/notifications/")
      .then((res) => setItems(res.data.results || res.data))
      .catch(() => {});
  };

  useEffect(() => {
    fetchUnread();
    const id = setInterval(fetchUnread, 8000); // poll for near-real-time updates
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    function onClickOutside(e) {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const toggle = () => {
    if (!open) fetchList();
    setOpen((v) => !v);
  };

  const markAllRead = async () => {
    await client.post("/notifications/read-all/");
    fetchUnread();
    fetchList();
  };

  return (
    <div className="relative" ref={boxRef}>
      <button
        onClick={toggle}
        className="relative w-10 h-10 rounded-full bg-white border border-ink-100 flex items-center justify-center hover:border-ink-300 transition-colors"
        aria-label="Notifications"
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        {unread > 0 && (
          <span className="absolute -top-1 -right-1 bg-signal-stop text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-ink-50">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-card border border-ink-100 overflow-hidden z-20">
          <div className="flex items-center justify-between px-4 py-3 border-b border-ink-100">
            <p className="font-display font-semibold text-sm">Notifications</p>
            <button onClick={markAllRead} className="text-xs text-signal-live font-semibold hover:underline">
              Mark all read
            </button>
          </div>
          <div className="max-h-80 overflow-y-auto scrollbar-thin">
            {items.length === 0 && (
              <p className="text-sm text-ink-400 px-4 py-6 text-center">Nothing here yet.</p>
            )}
            {items.map((n) => (
              <div
                key={n.id}
                className={`px-4 py-3 border-b border-ink-50 last:border-0 ${!n.is_read ? "bg-signal-live-soft/40" : ""}`}
              >
                <p className="text-sm font-semibold text-ink-800">{n.title}</p>
                <p className="text-xs text-ink-500 mt-0.5">{n.message}</p>
                <p className="text-[10px] text-ink-300 mt-1 font-mono">
                  {new Date(n.created_at).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
