import React from 'react'

const styles = {
  pending: 'bg-amber-500/15 text-amber-600',
  approved: 'bg-emerald-500/15 text-emerald-600',
  paid: 'bg-emerald-500/15 text-emerald-600',
  rejected: 'bg-red-500/15 text-red-600',
  open: 'bg-amber-500/15 text-amber-600',
  in_progress: 'bg-blueprint-500/15 text-blueprint-700',
  resolved: 'bg-emerald-500/15 text-emerald-600',
  unpaid: 'bg-red-500/15 text-red-600',
}

const labels = {
  in_progress: 'In progress',
}

const Badge = ({ status }) => (
  <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold capitalize ${styles[status] || 'bg-blueprint-100 text-blueprint-800'}`}>
    {labels[status] || status}
  </span>
)

export default Badge
