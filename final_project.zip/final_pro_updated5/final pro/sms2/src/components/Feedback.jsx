import React from 'react'

export const Loader = () => (
  <div className="flex items-center justify-center py-16 text-blueprint-800/60 text-sm">Loading…</div>
)

export const EmptyState = ({ title, subtitle }) => (
  <div className="text-center py-16 border border-dashed border-blueprint-100 rounded-xl bg-white">
    <p className="font-display font-semibold text-blueprint-900">{title}</p>
    {subtitle && <p className="text-sm text-blueprint-800/60 mt-1">{subtitle}</p>}
  </div>
)

export const ErrorBanner = ({ message }) => {
  if (!message) return null
  return (
    <div className="bg-red-500/10 border border-red-500/30 text-red-700 text-sm rounded-lg px-4 py-3 mb-4">
      {message}
    </div>
  )
}

export const SuccessBanner = ({ message }) => {
  if (!message) return null
  return (
    <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-700 text-sm rounded-lg px-4 py-3 mb-4">
      {message}
    </div>
  )
}
