import React from 'react'
import { NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

// Simple inline icon set (no extra dependency) — one glyph per nav destination.
const ICONS = {
  overview: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
    </>
  ),
  approvals: <path d="M9 12.5l2 2 4.5-4.5M12 21c4.5-1.5 8-5.5 8-11V5l-8-3-8 3v5c0 5.5 3.5 9.5 8 11Z" strokeLinecap="round" strokeLinejoin="round" />,
  residents: <path d="M17 21v-1.5a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V21M10 11.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM19 21v-1.5a3.5 3.5 0 0 0-2.5-3.35M14.5 4.6a3.5 3.5 0 0 1 0 6.8" strokeLinecap="round" strokeLinejoin="round" />,
  flats: <path d="M4 21V8l8-5 8 5v13M9 21v-6h6v6" strokeLinecap="round" strokeLinejoin="round" />,

  complaints: <path d="M12 9v4m0 4h.01M10.3 3.9 2.6 17.3A1.5 1.5 0 0 0 4 19.6h16a1.5 1.5 0 0 0 1.3-2.3L13.7 3.9a1.5 1.5 0 0 0-2.6 0Z" strokeLinecap="round" strokeLinejoin="round" />,
  notices: <path d="M5 4h14v13l-3-2H9l-3 2V4Zm3 4h8M8 11h5" strokeLinecap="round" strokeLinejoin="round" />,
}

const superAdminLinks = [{ to: '/super-admin', label: 'Society Approvals', icon: 'approvals' }]

const societyAdminLinks = [
  { to: '/admin', label: 'Overview', icon: 'overview' },
  { to: '/admin/residents', label: 'Residents', icon: 'residents' },
  { to: '/admin/flats', label: 'Flats', icon: 'flats' },
  { to: '/admin/bills', label: 'Bills', icon: 'bills' },
  { to: '/admin/complaints', label: 'Complaints', icon: 'complaints' },
  { to: '/admin/notices', label: 'Notices', icon: 'notices' },
]

const residentLinks = [
  { to: '/resident', label: 'Overview', icon: 'overview' },
  { to: '/resident/complaints', label: 'My Complaints', icon: 'complaints' },
  { to: '/resident/notices', label: 'Notices', icon: 'notices' },
]

const sectionLabel = {
  super_admin: 'Platform',
  society_admin: 'Society Management',
  resident: 'My Society',
}

const linkClasses = ({ isActive }) =>
  `group relative flex items-center gap-3 pl-4 pr-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 ${
    isActive
      ? 'bg-white/10 text-white shadow-sm'
      : 'text-blueprint-100/70 hover:text-white hover:bg-white/5'
  }`

const Sidebar = () => {
  const { user } = useAuth()
  if (!user) return null

  const links =
    user.role === 'super_admin' ? superAdminLinks : user.role === 'society_admin' ? societyAdminLinks : residentLinks

  return (
    <nav className="w-60 bg-blueprint-900 text-white flex flex-col gap-1 shrink-0 py-5 px-3 border-r border-black/10">
      <p className="px-4 pb-3 mb-1 text-[11px] font-semibold uppercase tracking-widest text-blueprint-100/40 border-b border-white/5">
        {sectionLabel[user.role] || 'Menu'}
      </p>

      {links.map((link) => (
        <NavLink key={link.to} to={link.to} end className={linkClasses}>
          {({ isActive }) => (
            <>
              <span
                className={`absolute left-0 top-1.5 bottom-1.5 w-0.5 rounded-full bg-amber-500 transition-opacity ${
                  isActive ? 'opacity-100' : 'opacity-0'
                }`}
              />
              <svg
                width="17"
                height="17"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={isActive ? 2.1 : 1.8}
                className={`shrink-0 transition-colors ${isActive ? 'text-amber-400' : 'text-blueprint-100/50 group-hover:text-blueprint-100'}`}
              >
                {ICONS[link.icon]}
              </svg>
              <span className="truncate">{link.label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  )
}

export default Sidebar
