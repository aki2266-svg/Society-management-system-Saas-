const STYLES = {
  PENDING: "bg-signal-wait-soft text-signal-wait",
  APPROVED: "bg-signal-live-soft text-signal-live",
  REJECTED: "bg-signal-stop-soft text-signal-stop",
  CHECKED_IN: "bg-signal-go-soft text-signal-go",
  CHECKED_OUT: "bg-ink-100 text-ink-500",
};

const LABELS = {
  PENDING: "Pending",
  APPROVED: "Approved",
  REJECTED: "Rejected",
  CHECKED_IN: "Checked in",
  CHECKED_OUT: "Checked out",
};

export default function StatusBadge({ status }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold tracking-wide ${
        STYLES[status] || "bg-ink-100 text-ink-500"
      }`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {LABELS[status] || status}
    </span>
  );
}
