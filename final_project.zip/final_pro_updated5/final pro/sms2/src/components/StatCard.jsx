import React from 'react'

export default function StatCard({ label, value, accent = "ink" }) {
  // Map variant keys to specific text colors while preserving boolean support
  const accents = {
    ink: "text-blueprint-900",
    go: "text-emerald-600",
    wait: "text-amber-600",
    live: "text-sky-600",
    // Fallback if accent prop is passed as boolean (e.g. accent={true})
    true: "text-amber-600",
    false: "text-blueprint-900",
  }

  const selectedAccent = typeof accent === 'boolean' ? accents[String(accent)] : (accents[accent] || accents.ink)

  return (
    <div className="bg-white rounded-2xl shadow-card border border-blueprint-100 px-5 py-4 flex-1 min-w-[140px] transition-all">
      <p className="text-xs uppercase tracking-wider text-blueprint-800/70 font-semibold mb-1">
        {label}
      </p>
      <p className={`text-3xl font-display font-semibold ${selectedAccent}`}>
        {value}
      </p>
    </div>
  )
}