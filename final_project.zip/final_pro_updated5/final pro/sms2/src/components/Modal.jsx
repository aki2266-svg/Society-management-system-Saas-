import React from 'react'

const Modal = ({ title, onClose, children }) => (
  <div className="fixed inset-0 bg-blueprint-950/50 flex items-center justify-center z-50 p-4">
    <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display font-semibold text-lg text-blueprint-900">{title}</h3>
        <button
          onClick={onClose}
          aria-label="Close"
          className="text-blueprint-800/50 hover:text-blueprint-900 text-xl leading-none"
        >
          &times;
        </button>
      </div>
      {children}
    </div>
  </div>
)

export default Modal
