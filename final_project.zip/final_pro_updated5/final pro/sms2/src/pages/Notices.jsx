import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listNotices, createNotice, deleteNotice } from '../api/notices'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Modal from '../components/Modal'

const emptyForm = { title: '', body: '' }

const Notices = () => {
  const [notices, setNotices] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await listNotices()
      setNotices(res.data.results || res.data)
    } catch {
      setError('Could not load notices.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      await createNotice(form)
      setSuccess('Notice posted.')
      setShowModal(false)
      setForm(emptyForm)
      load()
    } catch {
      setError('Could not post notice. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    try {
      await deleteNotice(id)
      setNotices((prev) => prev.filter((n) => n.id !== id))
    } catch {
      setError('Could not remove notice.')
    }
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">Notices</h1>
          <p className="text-sm text-blueprint-800/60">Announcements visible to all residents.</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-amber-500 hover:bg-amber-600 text-blueprint-950 font-semibold text-sm px-4 py-2 rounded-lg"
        >
          + Post notice
        </button>
      </div>

      <ErrorBanner message={error} />
      <SuccessBanner message={success} />

      {loading ? (
        <Loader />
      ) : notices.length === 0 ? (
        <EmptyState title="No notices yet" subtitle="Post your first announcement." />
      ) : (
        <div className="grid gap-3">
          {notices.map((n) => (
            <div key={n.id} className="bg-white rounded-xl shadow-card border border-blueprint-100 p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-blueprint-900">{n.title}</p>
                  <p className="text-xs text-blueprint-800/50 mt-0.5">
                    {n.created_at ? new Date(n.created_at).toLocaleDateString() : ''}
                  </p>
                </div>
                <button onClick={() => handleDelete(n.id)} className="text-xs text-red-600 hover:underline">
                  Remove
                </button>
              </div>
              <p className="text-sm text-blueprint-800/70 mt-2">{n.body}</p>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <Modal title="Post a notice" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd} className="space-y-3">
            <input
              required
              placeholder="Title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <textarea
              required
              rows={4}
              placeholder="Details"
              value={form.body}
              onChange={(e) => setForm({ ...form, body: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <button
              type="submit"
              disabled={saving}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-blueprint-950 font-semibold py-2 rounded-lg text-sm"
            >
              {saving ? 'Posting…' : 'Post notice'}
            </button>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  )
}

export default Notices
