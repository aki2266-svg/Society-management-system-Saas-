// src/pages/ResidentDashboard.jsx
import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import StatCard from '../components/StatCard'
import StatusBadge from '../components/StatusBadge'
import client from '../api/client'
import { listNotices } from '../api/notices'
import { 
  fetchEmergencyNumbers, 
  fetchWorkers, 
  addEmergencyNumber, 
  addWorker 
} from '../api/numbers' 
import { fetchComplaints, createComplaint, fetchDashboardSummary } from '../api/complaints'
import { Loader, ErrorBanner, SuccessBanner } from '../components/Feedback'
import { useAuth } from '../context/AuthContext'

const PURPOSE_LABEL = {
  GUEST: "Guest", 
  DELIVERY: "Delivery", 
  CAB: "Cab / Auto", 
  SERVICE: "Service", 
  OTHER: "Other",
}

const ResidentDashboard = () => {
  const { user } = useAuth()
  
  // Administrative Detection Boundary
  const isSocietyAdmin = 
    user?.role === 'society_admin' || 
    user?.role === 'admin' || 
    user?.role === 'super_admin' ||
    user?.is_staff === true || 
    user?.is_superuser === true ||
    user?.is_society_managed === true ||
    localStorage.getItem('user_role') === 'society_admin'

  const [activeTab, setActiveTab] = useState('overview') 
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  // Visitor state and polling tracking
  const [visitors, setVisitors] = useState([])
  const [visitorStats, setVisitorStats] = useState(null)
  const [busyId, setBusyId] = useState(null)

  const [data, setData] = useState({
  activeComplaintsList: [],
  recentNoticesList: [],
  stats: {
    openComplaints: 0,
    notices: 0
  }
})

  const [emergencyNumbers, setEmergencyNumbers] = useState([])
  const [workers, setWorkers] = useState([])
  const [complaints, setComplaints] = useState([])

  // Form parameters
  const [newEmergency, setNewEmergency] = useState({ service: '', contact: '', operational_hours: '24/7' })
  const [newWorker, setNewWorker] = useState({ name: '', role: '', phone: '', address: '', availability: '' })
  const [newComplaint, setNewComplaint] = useState({ title: '', description: '', category: 'General' })

  // Polling helper for Gate Visitor requests
  const loadVisitors = async () => {
    try {
      const [vRes, sRes] = await Promise.all([
        client.get('/visitors/'), 
        client.get('/visitors/stats/')
      ])
      setVisitors(vRes.data.results || vRes.data)
      setVisitorStats(sRes.data)
    } catch (err) {
      console.error("Visitor polling sync error:", err)
    }
  }

  const loadDashboardContext = async () => {
    setLoading(true)
    try {
      const safeExtractArray = (res) => {
        if (!res) return []
        if (Array.isArray(res)) return res
        if (Array.isArray(res.data)) return res.data
        if (Array.isArray(res.data?.results)) return res.data.results
        return []
      }

      const [emergencyRes, workersRes, noticesRes, complaintsRes, summaryRes] = await Promise.all([
        fetchEmergencyNumbers().catch(err => { console.error("Emergency Fetch Error:", err); return []; }),
        fetchWorkers().catch(err => { console.error("Workers Fetch Error:", err); return []; }),
        listNotices().catch(err => { console.error("Notices Fetch Error:", err); return []; }),
        fetchComplaints().catch(err => { console.error("Complaints Fetch Error:", err); return []; }),
        fetchDashboardSummary().catch(err => { console.error("Summary Fetch Error:", err); return {}; })
      ])

      const emergencyList = safeExtractArray(emergencyRes)
      const workersList = safeExtractArray(workersRes)
      const rawNotices = safeExtractArray(noticesRes)
      const rawComplaints = safeExtractArray(complaintsRes)
      
      const summaryData = summaryRes?.data || summaryRes || {}

      setComplaints(rawComplaints)
      setEmergencyNumbers(emergencyList)
      setWorkers(workersList)

      setData(prev => ({
        ...prev,
        recentNoticesList: rawNotices.slice(0, 3),
        activeComplaintsList: rawComplaints,
        stats: {
  openComplaints:
    summaryData.open_complaints ??
    summaryData.openComplaints ??
    rawComplaints.length,
  notices: rawNotices.length,
}
      }))

      await loadVisitors()
    } catch (err) {
      console.error("Dashboard population trace error:", err)
      setError('Could not fully sync your remote database dashboard context.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadDashboardContext()
    const visitorInterval = setInterval(loadVisitors, 8000)
    return () => clearInterval(visitorInterval)
  }, [])

  const decideVisitor = async (id, decision) => {
    setBusyId(id)
    try {
      await client.post(`/visitors/${id}/decision/`, { decision })
      await loadVisitors()
      setSuccess(`Visitor marked as ${decision.toLowerCase()}`)
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) {
      console.error("Visitor Decision Error:", err)
      setError("Failed to record decision on visitor request.")
      setTimeout(() => setError(''), 4000)
    } finally {
      setBusyId(null)
    }
  }

  const handleAddEmergency = async (e) => {
    e.preventDefault()
    try {
      await addEmergencyNumber(newEmergency)
      setSuccess('Emergency contact added successfully!')
      setNewEmergency({ service: '', contact: '', operational_hours: '24/7' })
      await loadDashboardContext()
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) {
      console.error("🔴 Emergency Submission Error Details:", err.response?.data)
      const errDetail = err.response?.data?.detail || err.response?.data?.message || 'Failed to save emergency data entry.'
      setError(typeof errDetail === 'object' ? JSON.stringify(errDetail) : errDetail)
      setTimeout(() => setError(''), 4000)
    }
  }

  const handleAddWorker = async (e) => {
    e.preventDefault()
    try {
      await addWorker(newWorker)
      setSuccess('Worker added to system registry!')
      setNewWorker({ name: '', role: '', phone: '', address: '', availability: '' })
      await loadDashboardContext()
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) {
      console.error("🔴 Worker Submission Error Details:", err.response?.data)
      const errData = err.response?.data
      let errorMessage = 'Authorization error: Admin clearance required.'

      if (errData) {
        if (typeof errData === 'string') errorMessage = errData
        else if (errData.detail) errorMessage = errData.detail
        else if (typeof errData === 'object') {
          const firstKey = Object.keys(errData)[0]
          errorMessage = `${firstKey}: ${Array.isArray(errData[firstKey]) ? errData[firstKey][0] : errData[firstKey]}`
        }
      }

      setError(errorMessage)
      setTimeout(() => setError(''), 4000)
    }
  }

  const handleAddComplaint = async (e) => {
    e.preventDefault()
    try {
      await createComplaint(newComplaint)
      setSuccess('Grievance / Complaint lodged successfully!')
      setNewComplaint({ title: '', description: '', category: 'General' })
      await loadDashboardContext()
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) {
      console.error("🔴 Complaint Submission Error Details:", err.response?.data)
      const errData = err.response?.data
      let errorMessage = 'Failed to submit complaint. Please check form parameters.'

      if (errData) {
        if (typeof errData === 'string') errorMessage = errData
        else if (errData.detail) errorMessage = errData.detail
        else if (typeof errData === 'object') {
          const firstKey = Object.keys(errData)[0]
          errorMessage = `${firstKey}: ${Array.isArray(errData[firstKey]) ? errData[firstKey][0] : errData[firstKey]}`
        }
      }

      setError(errorMessage)
      setTimeout(() => setError(''), 4000)
    }
  }

  const pendingVisitors = visitors.filter((v) => v.status === "PENDING")
  const visitorHistory = visitors.filter((v) => v.status !== "PENDING")

  return (
    <DashboardLayout>
      {/* Dashboard Top Header Section */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-blueprint-100 pb-4">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900 mb-1">
            Welcome{user?.first_name ? `, ${user.first_name}` : user?.name ? `, ${user.name}` : ''}
          </h1>
          <p className="text-sm text-blueprint-800/60">
            Internal operations & maintenance environment console.
          </p>
        </div>
        <div className="mt-2 sm:mt-0">
          {isSocietyAdmin ? (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200 shadow-sm animate-pulse">
              🛡️ Administrative Session Clearance Granted
            </span>
          ) : (
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-blueprint-50 text-blueprint-700 border border-blueprint-200">
              👤 Resident Account Profile View
            </span>
          )}
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="flex border-b border-blueprint-100 mb-6 overflow-x-auto text-sm gap-2">
        <button 
          onClick={() => setActiveTab('overview')} 
          className={`py-2 px-4 border-b-2 whitespace-nowrap transition-all ${activeTab === 'overview' ? 'border-amber-500 text-blueprint-950 font-semibold' : 'border-transparent text-blueprint-800/60 hover:text-blueprint-900'}`}
        >
          Overview Mode
        </button>
        <button 
          onClick={() => setActiveTab('visitors')} 
          className={`py-2 px-4 border-b-2 whitespace-nowrap transition-all ${activeTab === 'visitors' ? 'border-amber-500 text-blueprint-950 font-semibold' : 'border-transparent text-blueprint-800/60 hover:text-blueprint-900'}`}
        >
          Gate Approvals {pendingVisitors.length > 0 && `(${pendingVisitors.length})`}
        </button>
        <button 
          onClick={() => setActiveTab('complaints')} 
          className={`py-2 px-4 border-b-2 whitespace-nowrap transition-all ${activeTab === 'complaints' ? 'border-amber-500 text-blueprint-950 font-semibold' : 'border-transparent text-blueprint-800/60 hover:text-blueprint-900'}`}
        >
          Complaints & Grievances
        </button>
        <button 
          onClick={() => setActiveTab('emergency')} 
          className={`py-2 px-4 border-b-2 whitespace-nowrap transition-all ${activeTab === 'emergency' ? 'border-amber-500 text-blueprint-950 font-semibold' : 'border-transparent text-blueprint-800/60 hover:text-blueprint-900'}`}
        >
          Emergency Contacts
        </button>
        <button 
          onClick={() => setActiveTab('workers')} 
          className={`py-2 px-4 border-b-2 whitespace-nowrap transition-all ${activeTab === 'workers' ? 'border-amber-500 text-blueprint-950 font-semibold' : 'border-transparent text-blueprint-800/60 hover:text-blueprint-900'}`}
        >
          Staff & Operations Registry
        </button>
      </div>

      {/* Feedback Messages */}
      {error && <ErrorBanner message={error} />}
      {success && <SuccessBanner message={success} />}

      {loading ? (
        <div className="py-12"><Loader /></div>
      ) : (
        <div className="space-y-6">
          
          {/* TAB 1: OVERVIEW COMPONENT PANEL */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                <StatCard label="Open Grievances / Complaints" value={data.stats.openComplaints} />
                <StatCard label="Active Circulars & Announcements" value={data.stats.notices} />
              </div>

              {visitorStats && (
                <div className="bg-slate-50 border border-blueprint-100 rounded-xl p-4">
                  <h3 className="text-xs font-bold text-blueprint-900 uppercase tracking-wider mb-3">Gate Access Summary</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <StatCard label="Awaiting Decision" value={visitorStats.pending} accent="wait" />
                    <StatCard label="Currently Inside" value={visitorStats.checked_in} accent="go" />
                    <StatCard label="Today Total" value={visitorStats.today_total} accent="live" />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: VISITORS & GATE CLEARANCE PANEL */}
          {activeTab === 'visitors' && (
            <div className="space-y-8 max-w-4xl">
              <div>
                <h1 className="text-2xl font-display font-semibold mb-1">Visitor Requests</h1>
                <p className="text-sm text-blueprint-800/60">Approve or turn away anyone the guard sends to your door.</p>
              </div>

              <section>
                <h2 className="text-xs font-semibold text-blueprint-900 uppercase tracking-wider mb-3">
                  Pending Your Approval
                </h2>
                {pendingVisitors.length === 0 && (
                  <div className="bg-white border border-dashed border-blueprint-200 rounded-2xl p-8 text-center text-sm text-blueprint-800/60">
                    No one's waiting at the gate right now.
                  </div>
                )}
                <div className="space-y-3">
                  {pendingVisitors.map((v) => (
                    <div key={v.id} className="bg-white rounded-2xl shadow-card border border-blueprint-100 p-4 flex items-center justify-between gap-4">
                      <div>
                        <p className="font-semibold text-blueprint-950">{v.name}</p>
                        <p className="text-xs text-blueprint-800/70 mt-0.5">
                          {PURPOSE_LABEL[v.purpose] || v.purpose} · {v.phone}
                          {v.vehicle_number && ` · ${v.vehicle_number}`}
                        </p>
                        <p className="text-xs text-blueprint-800/50 mt-1 font-mono">
                          requested {new Date(v.requested_at).toLocaleTimeString()}
                        </p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button
                          disabled={busyId === v.id}
                          onClick={() => decideVisitor(v.id, "REJECTED")}
                          className="px-4 py-2 rounded-xl text-sm font-semibold text-red-600 bg-red-50 hover:bg-red-600 hover:text-white transition-colors disabled:opacity-50"
                        >
                          Deny
                        </button>
                        <button
                          disabled={busyId === v.id}
                          onClick={() => decideVisitor(v.id, "APPROVED")}
                          className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors disabled:opacity-50"
                        >
                          Approve
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              <section>
                <h2 className="text-xs font-semibold text-blueprint-900 uppercase tracking-wider mb-3">History</h2>
                <div className="bg-white rounded-2xl shadow-card border border-blueprint-100 overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="text-left text-xs text-blueprint-800/60 uppercase tracking-wider border-b border-blueprint-100">
                        <th className="px-4 py-3 font-semibold">Visitor</th>
                        <th className="px-4 py-3 font-semibold">Purpose</th>
                        <th className="px-4 py-3 font-semibold">Status</th>
                        <th className="px-4 py-3 font-semibold">When</th>
                      </tr>
                    </thead>
                    <tbody>
                      {visitorHistory.map((v) => (
                        <tr key={v.id} className="border-b border-blueprint-50 last:border-0">
                          <td className="px-4 py-3 font-medium text-blueprint-900">{v.name}</td>
                          <td className="px-4 py-3 text-blueprint-800/70">{PURPOSE_LABEL[v.purpose] || v.purpose}</td>
                          <td className="px-4 py-3"><StatusBadge status={v.status} /></td>
                          <td className="px-4 py-3 text-blueprint-800/60 font-mono text-xs">
                            {new Date(v.requested_at).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                      {visitorHistory.length === 0 && (
                        <tr><td colSpan={4} className="px-4 py-6 text-center text-blueprint-800/50">No visitor history yet.</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </section>
            </div>
          )}

          {/* TAB 3: COMPLAINTS & GRIEVANCES PANEL */}
          {activeTab === 'complaints' && (
            <div className="space-y-6">
              <form onSubmit={handleAddComplaint} className="bg-slate-50 p-5 rounded-xl border border-blueprint-100 grid grid-cols-1 md:grid-cols-3 gap-4 shadow-sm">
                <div className="md:col-span-3">
                  <h4 className="text-xs font-bold text-blueprint-900 uppercase tracking-wider">📝 File New Grievance / Maintenance Ticket</h4>
                </div>
                <div>
                  <label className="block text-xs font-medium text-blueprint-800 mb-1">Issue Title</label>
                  <input type="text" required value={newComplaint.title} onChange={(e) => setNewComplaint({...newComplaint, title: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" placeholder="e.g. Water Leakage in Flat" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-blueprint-800 mb-1">Category</label>
                  <select value={newComplaint.category} onChange={(e) => setNewComplaint({...newComplaint, category: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500">
                    <option value="General">General</option>
                    <option value="Plumbing">Plumbing</option>
                    <option value="Electrical">Electrical</option>
                    <option value="Security">Security</option>
                    <option value="Cleanliness">Cleanliness</option>
                  </select>
                </div>
                <div className="md:col-span-3">
                  <label className="block text-xs font-medium text-blueprint-800 mb-1">Detailed Description</label>
                  <textarea required rows="2" value={newComplaint.description} onChange={(e) => setNewComplaint({...newComplaint, description: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" placeholder="Describe the maintenance issue clearly..."></textarea>
                </div>
                <div className="md:col-span-3 flex justify-end">
                  <button type="submit" className="bg-amber-500 hover:bg-amber-600 text-white text-sm font-semibold py-2 px-6 rounded-lg transition-all shadow-sm">
                    Submit Grievance Ticket
                  </button>
                </div>
              </form>

              <div className="bg-white rounded-xl shadow-card border border-blueprint-100 overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="bg-blueprint-100/60 text-blueprint-900 text-xs uppercase font-semibold border-b border-blueprint-100">
                    <tr>
                      <th className="px-6 py-4">Title</th>
                      <th className="px-6 py-4">Category</th>
                      <th className="px-6 py-4">Description</th>
                      <th className="px-6 py-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blueprint-500/10">
                    {complaints.length === 0 ? (
                      <tr><td colSpan="4" className="px-6 py-8 text-center text-blueprint-800/40 font-medium">No open grievances logged.</td></tr>
                    ) : (
                      complaints.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-semibold text-blueprint-900">{item.title}</td>
                          <td className="px-6 py-4 text-xs font-medium text-blueprint-800">{item.category || 'General'}</td>
                          <td className="px-6 py-4 text-xs text-blueprint-800/70">{item.description}</td>
                          <td className="px-6 py-4">
                            <span className={`text-xs px-2.5 py-1 rounded font-semibold uppercase ${
                              item.status === 'Resolved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                            }`}>
                              {item.status || 'Pending'}
                            </span>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: EMERGENCY SYSTEM NUMBERS */}
          {activeTab === 'emergency' && (
            <div className="space-y-6">
              {isSocietyAdmin && (
                <form onSubmit={handleAddEmergency} className="bg-slate-50 p-5 rounded-xl border border-blueprint-100 grid grid-cols-1 md:grid-cols-4 gap-4 items-end shadow-sm">
                  <div className="md:col-span-4">
                    <h4 className="text-xs font-bold text-blueprint-900 uppercase tracking-wider">Add New Hotline Registry</h4>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Service Desk Name</label>
                    <input type="text" required value={newEmergency.service} onChange={(e) => setNewEmergency({...newEmergency, service: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:outline-none focus:ring-1 focus:ring-amber-500" placeholder="e.g. Electric Desk" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Contact Number</label>
                    <input type="text" required value={newEmergency.contact} onChange={(e) => setNewEmergency({...newEmergency, contact: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:outline-none focus:ring-1 focus:ring-amber-500" placeholder="e.g. +91 999..." />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Hours</label>
                    <input type="text" value={newEmergency.operational_hours} onChange={(e) => setNewEmergency({...newEmergency, operational_hours: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:outline-none focus:ring-1 focus:ring-amber-500" />
                  </div>
                  <button type="submit" className="bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium py-2 px-4 rounded transition-all duration-150 shadow-sm">
                    Add Contact
                  </button>
                </form>
              )}

              <div className="bg-white rounded-xl shadow-card border border-blueprint-100 overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="bg-blueprint-100/60 text-blueprint-900 text-xs uppercase font-semibold border-b border-blueprint-100">
                    <tr>
                      <th className="px-6 py-4">Service</th>
                      <th className="px-6 py-4">Contact</th>
                      <th className="px-6 py-4">Operational Window</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blueprint-500/10">
                    {emergencyNumbers.length === 0 ? (
                      <tr><td colSpan="3" className="px-6 py-8 text-center text-blueprint-800/40 font-medium">No emergency infrastructure contacts mapped yet.</td></tr>
                    ) : (
                      emergencyNumbers.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-semibold text-blueprint-900">{item.service}</td>
                          <td className="px-6 py-4 font-mono font-bold text-red-600 text-base">{item.contact}</td>
                          <td className="px-6 py-4 text-xs font-medium text-blueprint-800/70">{item.operational_hours}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: WORKERS & STAFF MANAGEMENT OPERATIONS */}
          {activeTab === 'workers' && (
            <div className="space-y-6">
              {isSocietyAdmin ? (
                <form onSubmit={handleAddWorker} className="bg-amber-50/20 p-5 rounded-xl border border-amber-200/60 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4 items-end shadow-sm">
                  <div className="md:col-span-5 flex items-center justify-between border-b border-amber-200/40 pb-2">
                    <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                      🛠️ Register Society Maintenance Worker Profile
                    </h4>
                    <span className="text-[10px] bg-amber-600 text-white font-bold px-2 py-0.5 rounded uppercase">
                      Admin Write Access
                    </span>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Worker Full Name</label>
                    <input type="text" required placeholder="e.g. Ramesh Kumar" value={newWorker.name} onChange={(e) => setNewWorker({...newWorker, name: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Service Domain (Role)</label>
                    <input type="text" required placeholder="e.g. Plumber, Electrician" value={newWorker.role} onChange={(e) => setNewWorker({...newWorker, role: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Mobile Contact String</label>
                    <input type="text" required placeholder="+91 XXXXX XXXXX" value={newWorker.phone} onChange={(e) => setNewWorker({...newWorker, phone: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Residential Address</label>
                    <input type="text" required placeholder="Local Area Info" value={newWorker.address} onChange={(e) => setNewWorker({...newWorker, address: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-blueprint-800 mb-1">Shift Timings Window</label>
                    <input type="text" placeholder="e.g. 9 AM - 6 PM" value={newWorker.availability} onChange={(e) => setNewWorker({...newWorker, availability: e.target.value})} className="w-full text-sm p-2 rounded border border-blueprint-200 focus:ring-1 focus:ring-amber-500" />
                  </div>
                  <div className="md:col-span-5 flex justify-end pt-2">
                    <button type="submit" className="bg-blueprint-900 hover:bg-blueprint-950 text-white text-sm font-semibold py-2 px-6 rounded-lg transition-all shadow-sm">
                      Submit Profile to Registry
                    </button>
                  </div>
                </form>
              ) : (
                <div className="bg-slate-50 border border-blueprint-100 rounded-xl p-4 text-xs text-blueprint-800/60 flex items-center gap-2">
                  <span>ℹ️</span>
                  <span>Notice: To update staffing directory parameters or register field units, configure assignments directly through your allocated Admin Login Portal route.</span>
                </div>
              )}

              <div className="bg-white rounded-xl shadow-card border border-blueprint-100 overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="bg-blueprint-100/60 text-blueprint-900 text-xs uppercase font-semibold border-b border-blueprint-100">
                    <tr>
                      <th className="px-6 py-4">Staff Member</th>
                      <th className="px-6 py-4">Role Profile</th>
                      <th className="px-6 py-4">Phone / Contact</th>
                      <th className="px-6 py-4">Address Context</th>
                      <th className="px-6 py-4">Availability Window</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blueprint-500/10">
                    {workers.length === 0 ? (
                      <tr><td colSpan="5" className="px-6 py-8 text-center text-blueprint-800/40 font-medium">No service staff profiles registered inside this society database instance.</td></tr>
                    ) : (
                      workers.map((worker) => (
                        <tr key={worker.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-semibold text-blueprint-900">{worker.name}</td>
                          <td className="px-6 py-4">
                            <span className="bg-blueprint-50 text-blueprint-900 text-xs px-2.5 py-1 rounded font-semibold tracking-wide uppercase border border-blueprint-100">
                              {worker.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 font-mono font-medium text-blueprint-800">{worker.phone}</td>
                          <td className="px-6 py-4 text-xs text-blueprint-800/70 max-w-xs truncate">{worker.address}</td>
                          <td className="px-6 py-4 text-xs font-semibold text-emerald-700 bg-emerald-50/40 px-2 py-1 rounded border border-emerald-100 text-center w-max block my-3">
                            {worker.availability || 'On Call / Dynamic'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      )}
    </DashboardLayout>
  )
}

export default ResidentDashboard