import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listResidents, createResident, deleteResident } from '../api/residents'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Modal from '../components/Modal'

const emptyForm = { first_name: '', last_name: '', email: '', phone: '', flat_number: '' }

const Residents = () => {
  const [residents, setResidents] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await listResidents()
      setResidents(res.data.results || res.data)
    } catch {
      setError('Could not load residents.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      await createResident(form)
      setSuccess('Resident added.')
      setShowModal(false)
      setForm(emptyForm)
      load()
    } catch {
      setError('Could not add resident. Check the details and try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    try {
      await deleteResident(id)
      setResidents((prev) => prev.filter((r) => r.id !== id))
    } catch {
      setError('Could not remove resident.')
    }
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">Residents</h1>
          <p className="text-sm text-blueprint-800/60">Everyone registered under your society.</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-amber-500 hover:bg-amber-600 text-blueprint-950 font-semibold text-sm px-4 py-2 rounded-lg"
        >
          + Add resident
        </button>
      </div>

      <ErrorBanner message={error} />
      <SuccessBanner message={success} />

      {loading ? (
        <Loader />
      ) : residents.length === 0 ? (
        <EmptyState title="No residents yet" subtitle="Add your first resident to get started." />
      ) : (
        <div className="bg-white rounded-xl shadow-card border border-blueprint-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-blueprint-100/60 text-blueprint-900 text-left">
              <tr>
                <th className="px-4 py-3 font-semibold">Name</th>
                <th className="px-4 py-3 font-semibold">Flat</th>
                <th className="px-4 py-3 font-semibold">Contact</th>
                <th className="px-4 py-3 font-semibold"></th>
              </tr>
            </thead>
            <tbody>
              {residents.map((r) => (
                <tr key={r.id} className="border-t border-blueprint-100">
                  <td className="px-4 py-3 font-medium text-blueprint-900">
                    {r.first_name} {r.last_name}
                  </td>
                  <td className="px-4 py-3 text-blueprint-800/70">{r.flat_number || '—'}</td>
                  <td className="px-4 py-3 text-blueprint-800/70">
                    {r.email}
                    {r.phone ? ` · ${r.phone}` : ''}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(r.id)} className="text-xs text-red-600 hover:underline">
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal title="Add resident" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <input
                required
                placeholder="First name"
                value={form.first_name}
                onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
              />
              <input
                required
                placeholder="Last name"
                value={form.last_name}
                onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
              />
            </div>
            <input
              required
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <input
              placeholder="Phone"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <input
              required
              placeholder="Flat number (e.g. A-101)"
              value={form.flat_number}
              onChange={(e) => setForm({ ...form, flat_number: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <button
              type="submit"
              disabled={saving}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-blueprint-950 font-semibold py-2 rounded-lg text-sm"
            >
              {saving ? 'Saving…' : 'Add resident'}
            </button>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  )
}

export default Residents
