import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listFlats, createFlat, deleteFlat } from '../api/residents'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Modal from '../components/Modal'
import Badge from '../components/Badge'

const emptyForm = { flat_number: '', floor: '', block: '' }

const Flats = () => {
  const [flats, setFlats] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await listFlats()
      setFlats(res.data.results || res.data)
    } catch {
      setError('Could not load flats.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      await createFlat(form)
      setSuccess('Flat added.')
      setShowModal(false)
      setForm(emptyForm)
      load()
    } catch {
      setError('Could not add flat. Check the details and try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    try {
      await deleteFlat(id)
      setFlats((prev) => prev.filter((f) => f.id !== id))
    } catch {
      setError('Could not remove flat.')
    }
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">Flats</h1>
          <p className="text-sm text-blueprint-800/60">The full inventory of units in your society.</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-amber-500 hover:bg-amber-600 text-blueprint-950 font-semibold text-sm px-4 py-2 rounded-lg"
        >
          + Add flat
        </button>
      </div>

      <ErrorBanner message={error} />
      <SuccessBanner message={success} />

      {loading ? (
        <Loader />
      ) : flats.length === 0 ? (
        <EmptyState title="No flats yet" subtitle="Add your first flat to start assigning residents." />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {flats.map((f) => (
            <div key={f.id} className="bg-white rounded-xl shadow-card border border-blueprint-100 p-4">
              <div className="flex items-start justify-between">
                <p className="font-display font-semibold text-blueprint-900">{f.flat_number}</p>
                <Badge status={f.is_occupied ? 'approved' : 'pending'} />
              </div>
              <p className="text-xs text-blueprint-800/60 mt-1">
                Block {f.block || '—'} · Floor {f.floor ?? '—'}
              </p>
              <button
                onClick={() => handleDelete(f.id)}
                className="text-xs text-red-600 hover:underline mt-3"
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <Modal title="Add flat" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd} className="space-y-3">
            <input
              required
              placeholder="Flat number (e.g. A-101)"
              value={form.flat_number}
              onChange={(e) => setForm({ ...form, flat_number: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                placeholder="Block"
                value={form.block}
                onChange={(e) => setForm({ ...form, block: e.target.value })}
                className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
              />
              <input
                type="number"
                placeholder="Floor"
                value={form.floor}
                onChange={(e) => setForm({ ...form, floor: e.target.value })}
                className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={saving}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-blueprint-950 font-semibold py-2 rounded-lg text-sm"
            >
              {saving ? 'Saving…' : 'Add flat'}
            </button>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  )
}

export default Flats
