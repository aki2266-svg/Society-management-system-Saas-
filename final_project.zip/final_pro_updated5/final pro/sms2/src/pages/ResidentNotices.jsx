import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout";
import { listNotices } from "../api/notices";
import { Loader, EmptyState, ErrorBanner } from "../components/Feedback";

const ResidentNotices = () => {
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const loadNotices = async () => {
      try {
        const res = await listNotices();

        console.log("Notice API Response:", res.data);

        const data = Array.isArray(res.data)
          ? res.data
          : res.data.results || [];

        setNotices(data);
      } catch (err) {
        console.error(err);
        setError("Could not load notices.");
      } finally {
        setLoading(false);
      }
    };

    loadNotices();
  }, []);

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-blueprint-900">
          Society Notices
        </h1>
        <p className="text-blueprint-800/60 mt-1">
          Stay updated with the latest announcements from your society.
        </p>
      </div>

      <ErrorBanner message={error} />

      {loading ? (
        <Loader />
      ) : notices.length === 0 ? (
        <EmptyState
          title="No Notices Available"
          subtitle="There are currently no announcements."
        />
      ) : (
        <div className="space-y-4">
          {notices.map((notice) => (
            <div
              key={notice.id}
              className="bg-white border border-gray-200 rounded-xl shadow-md p-5 hover:shadow-lg transition"
            >
              <div className="flex justify-between items-start mb-2">
                <h2 className="text-lg font-semibold text-blueprint-900">
                  {notice.title}
                </h2>

                {notice.created_at && (
                  <span className="text-xs text-gray-500">
                    {new Date(notice.created_at).toLocaleDateString()}
                  </span>
                )}
              </div>

              <p className="text-gray-700 leading-relaxed">
                {notice.body ||
                  notice.description ||
                  notice.content ||
                  notice.message ||
                  "No description available."}
              </p>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
};

export default ResidentNotices;