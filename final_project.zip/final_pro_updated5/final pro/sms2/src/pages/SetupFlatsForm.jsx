import React, { useState } from 'react'
import api from '../api/api'
import { Loader, ErrorBanner } from '../components/Feedback'

const SetupFlatsForm = ({ onSetupComplete }) => {
  const [numBlocks, setNumBlocks] = useState(1)
  const [floorsPerBlock, setFloorsPerBlock] = useState(1)
  const [flatsPerFloor, setFlatsPerFloor] = useState(4)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleGenerateAndSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // Calls your Django SetupSocietyStructureView endpoint directly
      await api.post('/api/v1/setup-structure/', {
        num_blocks: parseInt(numBlocks, 10),
        floors_per_block: parseInt(floorsPerBlock, 10),
        flats_per_floor: parseInt(flatsPerFloor, 10),
      })

      // Notify parent component to refresh layout and show the dashboard
      if (onSetupComplete) {
        onSetupComplete()
      }
    } catch (err) {
      console.error('Failed to setup society structure:', err)
      const backendError = err.response?.data?.error || 'Failed to auto-generate flats. Please check your network connection and backend endpoint.'
      setError(backendError)
    } finally {
      setLoading(false)
    }
  }

  const calculatedTotal = (parseInt(numBlocks, 10) || 0) * (parseInt(floorsPerBlock, 10) || 0) * (parseInt(flatsPerFloor, 10) || 0)

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-2xl border border-blueprint-100 shadow-lg p-6 sm:p-8 space-y-6">
        <div className="text-center space-y-2">
          <span className="text-4xl">🏢</span>
          <h2 className="text-2xl font-bold text-blueprint-950">Initial Society Setup</h2>
          <p className="text-xs text-blueprint-800/70">
            Define your society layout once to automatically configure all blocks and flat numbers.
          </p>
        </div>

        {error && <ErrorBanner message={error} />}

        <form onSubmit={handleGenerateAndSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
              Number of Blocks / Towers
            </label>
            <input
              type="number"
              min="1"
              max="26"
              required
              value={numBlocks}
              onChange={(e) => setNumBlocks(e.target.value)}
              className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
              placeholder="e.g. 2 (Block A, Block B)"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
              Number of Floors per Block
            </label>
            <input
              type="number"
              min="1"
              required
              value={floorsPerBlock}
              onChange={(e) => setFloorsPerBlock(e.target.value)}
              className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
              placeholder="e.g. 5"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
              Flats per Floor
            </label>
            <input
              type="number"
              min="1"
              required
              value={flatsPerFloor}
              onChange={(e) => setFlatsPerFloor(e.target.value)}
              className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
              placeholder="e.g. 4"
            />
          </div>

          <div className="bg-amber-50 border border-amber-200/60 rounded-xl p-3 text-xs text-amber-900">
            💡 This will automatically generate <strong>{calculatedTotal} flats</strong> (e.g. A-101, A-102...).
          </div>

          <button
            type="submit"
            disabled={loading || calculatedTotal <= 0}
            className="w-full bg-amber-500 hover:bg-amber-600 active:scale-[0.99] text-blueprint-950 font-semibold py-3.5 rounded-xl transition-all shadow-sm hover:shadow text-sm cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? <Loader /> : 'Generate & Proceed to Dashboard'}
          </button>
        </form>
      </div>
    </div>
  )
}

export default SetupFlatsForm