import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { ErrorBanner } from "../components/Feedback";

// Absolute routing map directory matrix
const roleHome = {
  super_admin: "/super-admin",
  superadmin: "/super-admin",
  society_admin: "/admin",
  admin: "/admin",
  guard: "/guard",
  GUARD: "/guard",
  resident: "/resident",
  RESIDENT: "/",
  ADMIN: "/",
};

export default function Login() {
  const { login, loading, error: authError } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Component Input State Parameters
  const [form, setForm] = useState({ username: "", password: "" });
  const [societyName, setSocietyName] = useState("");
  const [localError, setLocalError] = useState("");
  const [busy, setBusy] = useState(false);
  const [raised, setRaised] = useState(false);

  // Strict path evaluation strategy to isolate UI initial button states cleanly
  const [role, setRole] = useState(() => {
    const currentPath = location.pathname.toLowerCase().trim();

    if (currentPath === "/super-admin" || currentPath === "/superadmin") {
      return "super_admin";
    }
    if (currentPath === "/admin" || currentPath === "/admin/") {
      return "society_admin";
    }
    if (currentPath === "/guard" || currentPath === "/guard/") {
      return "guard";
    }

    return "resident"; // Default fall-back context framework layer
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLocalError("");
    setBusy(true);

    try {
      // 🟢 Payload contains standard username & password expected by backend serializer
      const credentials = {
        username: form.username.trim(),
        password: form.password,
        society_name: societyName.trim(),
      };

      const responseData = await login(credentials, form.username, form.password);
      const verifiedUser = responseData?.user || responseData;

      setRaised(true);

      const rawRole = verifiedUser?.role;

      if (!rawRole) {
        console.error("Authentication completed but no role field was detected in user payload:", verifiedUser);
        setLocalError("Account data error: User role profile mapping could not be verified.");
        setBusy(false);
        return;
      }

      const trueBackendRole = String(rawRole).toLowerCase().trim();
      console.log("Routing via true backend role string key:", trueBackendRole);

      const targetDashboardPath = roleHome[trueBackendRole] || roleHome[rawRole];

      setTimeout(() => {
        if (targetDashboardPath) {
          navigate(targetDashboardPath);
        } else {
          console.warn(`Unmapped role token [${trueBackendRole}] matched. Falling back to platform root.`);
          navigate("/");
        }
      }, 450);
    } catch (err) {
      console.error("Authentication handshake execution failure:", err);
      const drfData = err.response?.data;
      const detail =
        drfData?.detail ||
        (Array.isArray(drfData?.non_field_errors) && drfData.non_field_errors[0]) ||
        "Couldn't sign in. Check your username and password.";
      setLocalError(detail);
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-blueprint-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        
        {/* LOGO AND BRAND HEADER FRAME */}
        <div className="flex items-center gap-2 justify-center mb-8">
          <div className="w-9 h-9 rounded-md bg-amber-500 flex items-center justify-center font-display font-bold text-blueprint-950 relative overflow-hidden">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#241A42" strokeWidth="2.5">
              <path d="M4 20V6a2 2 0 0 1 2-2h5v16" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M11 8h9v12" className={`gate-bar ${raised ? "raised" : ""}`} strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <span className="font-display font-semibold text-2xl text-white tracking-tight">SMS</span>
        </div>

        {/* INTERACTION INTERFACE PANEL */}
        <div className="bg-white rounded-2xl shadow-xl p-7">
          <h1 className="font-display font-semibold text-xl text-blueprint-900 mb-1">Welcome back</h1>
          <p className="text-sm text-blueprint-800/60 mb-6">Log in to manage your society.</p>

          <ErrorBanner message={localError || authError} />

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* ROLE TOGGLE CONTROLS */}
            <div>
              <label className="block text-sm font-medium text-blueprint-900 mb-2">Log in as</label>
              <div className="grid grid-cols-3 gap-1.5 bg-blueprint-50 p-1 rounded-xl border border-blueprint-100">
                
                {/* RESIDENT SELECTION BUTTON */}
                <button
                  type="button"
                  onClick={() => setRole('resident')}
                  className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
                    role === 'resident'
                      ? 'bg-amber-500 text-blueprint-950 shadow-sm'
                      : 'text-blueprint-800/70 hover:text-blueprint-900'
                  }`}
                >
                  {role === 'resident' && (
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  Resident
                </button>

                {/* GUARD SELECTION BUTTON */}
                <button
                  type="button"
                  onClick={() => setRole('guard')}
                  className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
                    role === 'guard'
                      ? 'bg-amber-500 text-blueprint-950 shadow-sm'
                      : 'text-blueprint-800/70 hover:text-blueprint-900'
                  }`}
                >
                  {role === 'guard' && (
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  Guard
                </button>

                {/* ADMINISTRATOR SELECTION BUTTON */}
                <button
                  type="button"
                  onClick={() => setRole('society_admin')}
                  className={`flex items-center justify-center gap-1.5 py-2 text-xs font-semibold rounded-lg transition-all ${
                    role === 'society_admin'
                      ? 'bg-amber-500 text-blueprint-950 shadow-sm'
                      : 'text-blueprint-800/70 hover:text-blueprint-900'
                  }`}
                >
                  {role === 'society_admin' && (
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  Admin
                </button>
              </div>
            </div>

            {/* SOCIETY CAPTURE */}
            <div>
              <label className="block text-sm font-medium text-blueprint-900 mb-1">Society Name</label>
              <input
                type="text"
                required
                value={societyName}
                onChange={(e) => setSocietyName(e.target.value)}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/50"
                placeholder="e.g. Green Park Residency"
              />
            </div>

            {/* CREDENTIALS */}
            <div>
              <label className="block text-sm font-medium text-blueprint-900 mb-1">Username</label>
              <input
                type="text"
                required
                autoFocus
                value={form.username}
                onChange={(e) => setForm({ ...form, username: e.target.value })}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder={
                  role === 'society_admin' 
                    ? "e.g. admin_greenpark" 
                    : role === 'guard'
                    ? "e.g. guard1"
                    : "e.g. resident_101"
                }
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-blueprint-900 mb-1">Password</label>
              <input
                type="password"
                required
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                placeholder="••••••••"
              />
            </div>
            
            {/* SUBMIT BUTTON */}
            <button
              type="submit"
              disabled={busy || loading}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 transition-colors text-blueprint-950 font-semibold py-2.5 rounded-lg text-sm"
            >
              {busy || loading ? 'Logging in…' : 'Log in'}
            </button>
          </form>

          {/* DYNAMIC REGISTRATION ROUTING SUBTEXT HOOK */}
          <p className="text-sm text-center text-blueprint-800/70 mt-6">
            {role === 'society_admin' ? (
              <>
                Registering a new society?{' '}
                <Link to="/register-society" className="text-amber-600 font-medium hover:underline">
                  Apply here
                </Link>
              </>
            ) : role === 'guard' ? (
              <>
                New security guard?{' '}
                <Link to="/register" className="text-amber-600 font-medium hover:underline">
                  Register here
                </Link>
              </>
            ) : (
              <>
                New resident to the society?{' '}
                <Link to="/register-resident" className="text-amber-600 font-medium hover:underline">
                  Register here
                </Link>
              </>
            )}
          </p>

        </div>
      </div>
    </div>
  );
}