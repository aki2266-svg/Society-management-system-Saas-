import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listBills, payBill } from '../api/billing'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Badge from '../components/Badge'

const ResidentBills = () => {
  const [bills, setBills] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [payingId, setPayingId] = useState(null)

  const load = async () => {
    setLoading(true)
    try {
      const res = await listBills()
      setBills(res.data.results || res.data)
    } catch {
      setError('Could not load your bills.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handlePay = async (id) => {
    setPayingId(id)
    setError('')
    try {
      await payBill(id, 'card')
      setSuccess('Payment successful.')
      load()
    } catch {
      setError('Payment could not be processed. Please try again.')
    } finally {
      setPayingId(null)
    }
  }

  return (
    <DashboardLayout>
      <h1 className="font-display font-semibold text-2xl text-blueprint-900 mb-1">My bills</h1>
      <p className="text-sm text-blueprint-800/60 mb-6">Maintenance and other charges for your flat.</p>

      <ErrorBanner message={error} />
      <SuccessBanner message={success} />

      {loading ? (
        <Loader />
      ) : bills.length === 0 ? (
        <EmptyState title="No bills yet" subtitle="You're all caught up." />
      ) : (
        <div className="grid gap-3">
          {bills.map((b) => (
            <div
              key={b.id}
              className="bg-white rounded-xl shadow-card border border-blueprint-100 p-4 flex items-center justify-between"
            >
              <div>
                <p className="font-medium text-blueprint-900">{b.title}</p>
                <p className="text-xs text-blueprint-800/60 mt-0.5">Due {b.due_date}</p>
              </div>
              <div className="flex items-center gap-4">
                <p className="font-display font-semibold text-blueprint-900">₹{b.amount}</p>
                <Badge status={b.status || 'unpaid'} />
                {(b.status || 'unpaid') !== 'paid' && (
                  <button
                    onClick={() => handlePay(b.id)}
                    disabled={payingId === b.id}
                    className="bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-blueprint-950 font-semibold text-xs px-3 py-1.5 rounded-md"
                  >
                    {payingId === b.id ? 'Processing…' : 'Pay now'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  )
}

export default ResidentBills
