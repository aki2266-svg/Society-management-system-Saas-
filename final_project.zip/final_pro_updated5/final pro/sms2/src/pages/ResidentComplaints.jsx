import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listComplaints, createComplaint } from '../api/complaints'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Badge from '../components/Badge'
import Modal from '../components/Modal'

const emptyForm = { title: '', description: '', category: 'Plumbing' }

const ResidentComplaints = () => {
  const [complaints, setComplaints] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const res = await listComplaints()
      setComplaints(res.data?.results || res.data || [])
    } catch (err) {
      console.error('🔴 Fetch Complaints Error:', err)
      setError(err.response?.data?.detail || 'Could not load your complaints.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    setSuccess('')
    
    try {
      await createComplaint(form)
      setSuccess('Complaint submitted successfully!')
      setShowModal(false)
      setForm(emptyForm)
      await load() // Re-fetch updated list from backend
      setTimeout(() => setSuccess(''), 4000)
    } catch (err) {
      console.error('🔴 Submit Complaint Error:', err.response?.data)
      
      const errData = err.response?.data
      let errorMessage = 'Could not submit complaint. Please try again.'

      if (errData) {
        if (typeof errData === 'string') {
          errorMessage = errData
        } else if (errData.detail) {
          errorMessage = errData.detail
        } else if (typeof errData === 'object') {
          // Parse DRF field errors like { title: ["This field is required."] }
          const firstKey = Object.keys(errData)[0]
          const fieldErr = Array.isArray(errData[firstKey]) ? errData[firstKey][0] : errData[firstKey]
          errorMessage = `${firstKey}: ${fieldErr}`
        }
      }

      setError(errorMessage)
      setTimeout(() => setError(''), 5000)
    } finally {
      setSaving(false)
    }
  }

  const handleOpenModal = () => {
    setError('')
    setSuccess('')
    setShowModal(true)
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">My complaints</h1>
          <p className="text-sm text-blueprint-800/60">Raise an issue and track its progress.</p>
        </div>
        <button
          onClick={handleOpenModal}
          className="bg-amber-500 hover:bg-amber-600 text-blueprint-950 font-semibold text-sm px-4 py-2 rounded-lg transition-colors shadow-sm"
        >
          + New complaint
        </button>
      </div>

      {error && <ErrorBanner message={error} />}
      {success && <SuccessBanner message={success} />}

      {loading ? (
        <Loader />
      ) : complaints.length === 0 ? (
        <EmptyState title="No complaints yet" subtitle="Raise one if something needs attention." />
      ) : (
        <div className="grid gap-3">
          {complaints.map((c) => (
            <div key={c.id || c.pk} className="bg-white rounded-xl shadow-card border border-blueprint-100 p-4">
              <div className="flex items-start justify-between">
                <p className="font-medium text-blueprint-900">{c.title}</p>
                <Badge status={c.status || 'Pending'} />
              </div>
              <p className="text-xs font-semibold text-amber-700 mt-1 uppercase tracking-wider">{c.category || 'General'}</p>
              <p className="text-sm text-blueprint-800/70 mt-1">{c.description}</p>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <Modal title="Raise a complaint" onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-blueprint-800 mb-1">Category</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              >
                <option value="Plumbing">Plumbing</option>
                <option value="Electrical">Electrical</option>
                <option value="Security">Security</option>
                <option value="Cleanliness">Cleanliness</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-blueprint-800 mb-1">Title</label>
              <input
                required
                placeholder="Brief summary of the issue"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-blueprint-800 mb-1">Description</label>
              <textarea
                required
                rows={3}
                placeholder="Describe the issue in detail"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-blueprint-950 font-semibold py-2 rounded-lg text-sm transition-colors shadow-sm"
            >
              {saving ? 'Submitting…' : 'Submit complaint'}
            </button>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  )
}

export default ResidentComplaints