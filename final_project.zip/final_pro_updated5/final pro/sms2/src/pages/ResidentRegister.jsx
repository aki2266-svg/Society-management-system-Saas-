import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from '../api/api' // Path to your standard axios instance
import { ErrorBanner } from '../components/Feedback'

// 🟢 Mobile number restriction: must start with 6/7/8/9 and be exactly 10 digits
const PHONE_REGEX = /^[6-9]\d{9}$/

const ResidentRegister = () => {
  const navigate = useNavigate()
  
  // Form input state variables
  const [formData, setFormData] = useState({
    username: '',
    first_name: '',
    last_name: '',
    email: '',
    phone_number: '',
    password: '',
    society_id: '', // Tracks selected society to fetch flats
    flat_id: ''     // Links the resident profile to the flat primary key
  })

  // System management state
  const [societies, setSocieties] = useState([])
  const [flats, setFlats] = useState([])
  const [loading, setLoading] = useState(false)
  const [fetchingSocieties, setFetchingSocieties] = useState(true)
  const [fetchingFlats, setFetchingFlats] = useState(false)
  const [error, setError] = useState('')

  // 1. Fetch the list of societies on mount to populate the first dropdown menu
  useEffect(() => {
    const fetchSocietiesList = async () => {
      try {
        const response = await api.get('/api/v1/societies/') 
        // Handles standard arrays or paginated results ({ results: [...] })
        setSocieties(response.data.results || response.data || [])
      } catch (err) {
        console.error("Failed to load society directory:", err)
        setError('Could not retrieve the society directory. Please refresh.')
      } finally {
        setFetchingSocieties(false)
      }
    }
    fetchSocietiesList()
  }, [])

  // 2. Dynamic Fetch: Runs every time society_id changes in the form state
  useEffect(() => {
    if (!formData.society_id) {
      setFlats([])
      setFormData(prev => ({ ...prev, flat_id: '' }))
      return
    }

    const fetchFlatsForSociety = async () => {
      setFetchingFlats(true)
      try {
        // Appends backend availability query params if your API supports filtering
        const response = await api.get(`/api/v1/flats/?society_id=${formData.society_id}&available_only=true&is_occupied=false`)
        
        const rawFlats = response.data.results || response.data || []

        // 🟢 FILTER: Only keep flats that are NOT occupied and are marked available
        const unoccupiedFlats = rawFlats.filter((flat) => {
          const isExplicitlyOccupied = flat.is_occupied === true || flat.occupied === true
          const isExplicitlyUnavailable = flat.is_available === false || flat.available === false
          const hasResidentAssigned = Boolean(flat.resident || flat.current_resident || flat.tenant)

          return !isExplicitlyOccupied && !isExplicitlyUnavailable && !hasResidentAssigned
        })

        setFlats(unoccupiedFlats)
      } catch (err) {
        console.error("Failed to fetch available flats:", err)
        setError('Failed to load available flats for the selected society.')
      } finally
      {
        setFetchingFlats(false)
      }
    }

    fetchFlatsForSociety()
  }, [formData.society_id])

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    
    if (!formData.society_id || !formData.flat_id) {
      setError('Please select both your society and an available flat number.')
      return
    }

    if (formData.phone_number && !PHONE_REGEX.test(formData.phone_number)) {
      setError('Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.')
      return
    }

    setLoading(true)
    try {
      await api.post('/api/v1/auth/register/resident/', {
        username: formData.username,
        password: formData.password,
        first_name: formData.first_name,
        last_name: formData.last_name,
        email: formData.email,
        phone_number: formData.phone_number,
        society: parseInt(formData.society_id, 10),
        flat: parseInt(formData.flat_id, 10)
      })
      
      navigate('/register-success')
    } catch (err) {
      console.error("Registration validation error:", err)
      
      const backendErrors = err.response?.data
      if (typeof backendErrors === 'object' && backendErrors !== null) {
        const errorMsg = Object.entries(backendErrors)
          .map(([field, msg]) => `${field}: ${Array.isArray(msg) ? msg.join(' ') : msg}`)
          .join(' | ')
        setError(errorMsg)
      } else {
        setError(err.response?.data?.detail || 'Registration failed.')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-blueprint-950 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8">
        
        <div className="flex items-center gap-2 justify-center mb-6">
          <div className="w-8 h-8 rounded-md bg-amber-500 flex items-center justify-center font-display font-bold text-blueprint-950">
            N
          </div>
          <span className="font-display font-semibold text-xl text-blueprint-900 tracking-tight">NestOS Portal</span>
        </div>

        <h1 className="font-display font-semibold text-xl text-blueprint-900 mb-1 text-center">Resident Registration</h1>
        <p className="text-xs text-blueprint-800/60 mb-6 text-center">Select your housing community and property block to sign up.</p>

        <ErrorBanner message={error} />

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* STEP 1: SELECT YOUR SOCIETY */}
          <div>
            <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Select Your Society</label>
            {fetchingSocieties ? (
              <div className="text-xs text-blueprint-800/50 py-2 animate-pulse">Loading community listings...</div>
            ) : (
              <select
                name="society_id"
                required
                value={formData.society_id}
                onChange={handleChange}
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50"
              >
                <option value="">-- Click to choose your society --</option>
                {societies.map((soc) => (
                  <option key={soc.id} value={soc.id}>{soc.name}</option>
                ))}
              </select>
            )}
          </div>

          {/* STEP 2: DYNAMICALLY POPULATED FLAT SELECTOR */}
          <div>
            <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Select Your Flat Number</label>
            <select
              name="flat_id"
              required
              disabled={!formData.society_id || fetchingFlats || flats.length === 0}
              value={formData.flat_id}
              onChange={handleChange}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50 disabled:opacity-50"
            >
              <option value="">
                {fetchingFlats
                  ? "Loading unoccupied units..."
                  : flats.length === 0 && formData.society_id
                  ? "No unoccupied flats available"
                  : "-- Choose flat/room --"}
              </option>
              {flats.map((flat) => (
                <option key={flat.id} value={flat.id}>
                  Flat {flat.number || flat.flat_number || flat.house_no} {flat.block ? `(Block ${flat.block})` : ''}
                </option>
              ))}
            </select>
            {!formData.society_id && (
              <p className="text-[10px] text-blueprint-800/40 mt-1">Choose a society above first to show available units.</p>
            )}
            {formData.society_id && !fetchingFlats && flats.length === 0 && (
              <p className="text-[10px] text-amber-600 mt-1 font-medium">All units in this society are currently occupied or unassigned.</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">First Name</label>
              <input type="text" name="first_name" required value={formData.first_name} onChange={handleChange} className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500" placeholder="Aarav" />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Last Name</label>
              <input type="text" name="last_name" required value={formData.last_name} onChange={handleChange} className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500" placeholder="Patel" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Username</label>
              <input type="text" name="username" required value={formData.username} onChange={handleChange} className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500" placeholder="aarav_patel" />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Phone Number</label>
              <input
                type="tel"
                name="phone_number"
                inputMode="numeric"
                pattern="[6-9][0-9]{9}"
                maxLength={10}
                title="Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9."
                value={formData.phone_number}
                onChange={(e) =>
                  setFormData({ ...formData, phone_number: e.target.value.replace(/\D/g, '').slice(0, 10) })
                }
                className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500"
                placeholder="9XXXXXXXXX"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Email Address</label>
            <input type="email" name="email" required value={formData.email} onChange={handleChange} className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500" placeholder="name@domain.com" />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-blueprint-800 mb-1">Password</label>
            <input type="password" name="password" required value={formData.password} onChange={handleChange} className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500" placeholder="••••••••" />
          </div>

          <button
            type="submit"
            disabled={loading || fetchingSocieties || !formData.flat_id}
            className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 transition-colors text-blueprint-950 font-semibold py-2.5 rounded-lg text-sm mt-2 cursor-pointer"
          >
            {loading ? 'Creating Account...' : 'Register Profile'}
          </button>
        </form>

        <p className="text-xs text-center text-blueprint-800/70 mt-4">
          Already have an account?{' '}
          <Link to="/login" className="text-amber-600 font-medium hover:underline">
            Log in here
          </Link>
        </p>

      </div>
    </div>
  )
}

export default ResidentRegister;