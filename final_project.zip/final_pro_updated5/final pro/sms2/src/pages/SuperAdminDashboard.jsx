import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listSocieties, updateSocietyStatus } from '../api/societies'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Badge from '../components/Badge'

const SuperAdminDashboard = () => {
  const [societies, setSocieties] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [filter, setFilter] = useState('pending')

  const loadDashboardData = async (currentFilter) => {
    setLoading(true)
    setError('')
    try {
      // Hits backend API passing down 'pending', 'approved', or 'rejected'
      const res = await listSocieties(currentFilter === 'all' ? undefined : currentFilter)
      console.log(res.data)
      setSocieties(res.data.results || res.data)
    } catch (err) {
      setError('Failed to fetch society records from the database.')
    } finally {
      setLoading(false)
    }
  }

  // Reload data smoothly when filter selection states drop down or pivot
  useEffect(() => {
    loadDashboardData(filter)
  }, [filter])

  const processDecision = async (societyId, applicantName, decisionType) => {
    setSuccess('')
    setError('')
    
    // Save UI state snapshot as an emergency rollback layer
    const fallbackBackup = [...societies];
    
    try {
      // 1. Optimistically hide the element instantly from active rendering view
      setSocieties((prev) => prev.filter((item) => item.id !== societyId));
      
      // 2. Transmit to backend standard PATCH endpoint
      await updateSocietyStatus(societyId, decisionType)
      
      setSuccess(`Successfully marked registration managed by ${applicantName} as ${decisionType}.`);
      
      // 3. Force filter toggle viewport switch to reflect real-time updates
      setFilter(decisionType);
      
    } catch (err) {
      // Revert UI layout if API blocks access or drops connection
      setSocieties(fallbackBackup);
      setError(`Backend update failed. Could not alter status for ${applicantName}.`);
    }
  }

  return (
    <DashboardLayout>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">
            User-Society Approval Manager
          </h1>
          <p className="text-sm text-blueprint-800/60">
            Review incoming society registration requests attached directly to user profiles.
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-blueprint-800/60 uppercase tracking-wider">Active View:</span>
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm bg-white font-medium text-blueprint-900 shadow-sm"
          >
            <option value="pending">📥 Pending Review</option>
            <option value="approved">✅ Approved Societies</option>
            <option value="rejected">❌ Rejected Requests</option>
            <option value="all">🌐 Show All Records</option>
          </select>
        </div>
      </div>

      {error && <ErrorBanner message={error} />}
      {success && <SuccessBanner message={success} />}

      {loading ? (
        <div className="py-12"><Loader /></div>
      ) : societies.length === 0 ? (
        <EmptyState 
          title={`No ${filter} items found`} 
          subtitle="All clear! No current applications match this filter perspective." 
        />
      ) : (
        <div className="bg-white rounded-xl shadow-card border border-blueprint-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-blueprint-100/60 text-blueprint-900 text-left border-b border-blueprint-100">
              <tr>
                <th className="px-6 py-4 font-semibold">User / Applicant Profile</th>
                <th className="px-6 py-4 font-semibold">Assigned Society Details</th>
                <th className="px-6 py-4 font-semibold">Application Date</th>
                <th className="px-6 py-4 font-semibold">Status Badge</th>
                <th className="px-6 py-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-blueprint-500/10">
              {societies.map((item) => {
                const normalizedStatus = (item.status || 'pending').toLowerCase()
                const fullName = `${item.admin_first_name || 'System'} ${item.admin_last_name || 'User'}`
                
                return (
                  <tr key={item.id} className="hover:bg-blueprint-50/30 transition-colors">
                    <td className="px-6 py-4">
                      <p className="font-semibold text-blueprint-900">{fullName}</p>
                      <p className="text-xs text-blueprint-800/60">{item.admin_email || 'No email'}</p>
                    </td>
                    
                    <td className="px-6 py-4">
                      <p className="font-medium text-blueprint-800">{item.name}</p>
                      <p className="text-xs text-blueprint-800/40">{item.address || 'No location address'}</p>
                    </td>
                    
                    <td className="px-6 py-4 text-xs text-blueprint-800/70">
                      {item.created_at ? new Date(item.created_at).toLocaleDateString() : '—'}
                    </td>
                    
                    <td className="px-6 py-4">
                      <Badge status={normalizedStatus} />
                    </td>
                    
                    <td className="px-6 py-4 text-right">
                      {normalizedStatus === 'pending' ? (
                        <div className="flex gap-2 justify-end">
                          <button
                            onClick={() => processDecision(item.id, fullName, 'approved')}
                            className="text-xs font-semibold bg-emerald-500 text-white hover:bg-emerald-600 px-3 py-2 rounded-lg shadow-sm"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => processDecision(item.id, fullName, 'rejected')}
                            className="text-xs font-semibold bg-blueprint-100 text-blueprint-800 hover:bg-red-500 hover:text-white px-3 py-2 rounded-lg"
                          >
                            Reject
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs font-medium text-blueprint-800/40 italic">
                          Archived ({normalizedStatus})
                        </span>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </DashboardLayout>
  )
}

export default SuperAdminDashboard