import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../api/api";

// 🟢 Mobile number restriction: must start with 6/7/8/9 and be exactly 10 digits
const PHONE_REGEX = /^[6-9]\d{9}$/;

export default function RegisterGuard() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [societies, setSocieties] = useState([]);
  const [loadingSocieties, setLoadingSocieties] = useState(true);

  const [form, setForm] = useState({
    username: "",
    password: "",
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    society: "", // 🟢 Captures selected Society ID
    role: "guard", // 🟢 Must match backend ROLE_CHOICES ('guard') so the account is
                   // correctly distinguished from a resident during registration.
  });

  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  // 🟢 Fetch available societies on component mount
  useEffect(() => {
    api
      .get("/api/v1/auth/societies/")
      .then((res) => {
        const data = Array.isArray(res.data) ? res.data : res.data.results || [];
        setSocieties(data);
      })
      .catch((err) => {
        console.error("Failed to fetch societies:", err);
      })
      .finally(() => setLoadingSocieties(false));
  }, []);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError("");

    if (!form.society) {
      setError("Please select your society from the dropdown.");
      return;
    }

    if (form.phone && !PHONE_REGEX.test(form.phone)) {
      setError("Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.");
      return;
    }

    setBusy(true);
    try {
      // 🟢 Backend field is `phone_number`, not `phone`
      const { phone, ...rest } = form;
      await register({ ...rest, phone_number: phone });
      setDone(true);
    } catch (err) {
      const data = err.response?.data;
      const firstError = data && typeof data === "object" ? Object.values(data)[0] : null;
      setError((Array.isArray(firstError) ? firstError[0] : firstError) || "Registration failed. Please check your details.");
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-blueprint-950 flex items-center justify-center p-4">
        <div className="max-w-sm w-full bg-white rounded-2xl shadow-xl p-7 text-center">
          <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-4">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M20 6 9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <h2 className="font-display font-semibold text-lg text-blueprint-900 mb-2">Request submitted</h2>
          <p className="text-sm text-blueprint-800/60 mb-6">
            An admin needs to approve your guard account before you can sign in. Check back soon.
          </p>
          <Link to="/login" className="text-sm font-semibold text-amber-600 hover:underline">
            Back to sign in
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-blueprint-950 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-7">
        
        {/* LOGO AND BRAND HEADER */}
        <div className="flex items-center gap-2 justify-center mb-6">
          <div className="w-9 h-9 rounded-md bg-amber-500 flex items-center justify-center font-display font-bold text-blueprint-950 relative overflow-hidden">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#241A42" strokeWidth="2.5">
              <path d="M4 20V6a2 2 0 0 1 2-2h5v16" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M11 8h9v12" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <span className="font-display font-semibold text-2xl text-blueprint-900 tracking-tight">SMS</span>
        </div>

        <h2 className="text-xl font-display font-semibold text-blueprint-900 mb-1 text-center">Guard Registration</h2>
        <p className="text-sm text-blueprint-800/60 mb-6 text-center">Guard accounts require society admin approval.</p>

        <form onSubmit={submit} className="space-y-4">
          
          {/* 🟢 SOCIETY SELECT DROPDOWN */}
          <div>
            <label className="block text-xs font-semibold text-blueprint-900 mb-1">Select Society</label>
            <select
              required
              value={form.society}
              onChange={set("society")}
              disabled={loadingSocieties}
              className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30 text-blueprint-900"
            >
              <option value="">
                {loadingSocieties ? "Loading societies…" : "Select a society"}
              </option>
              {societies.map((soc) => (
                <option key={soc.id} value={soc.id}>
                  {soc.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-blueprint-900 mb-1">First name</label>
              <input required value={form.first_name} onChange={set("first_name")}
                className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-blueprint-900 mb-1">Last name</label>
              <input value={form.last_name} onChange={set("last_name")}
                className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-blueprint-900 mb-1">Username</label>
            <input required value={form.username} onChange={set("username")}
              className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-blueprint-900 mb-1">Password</label>
              <input required type="password" minLength={6} value={form.password} onChange={set("password")}
                className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-blueprint-900 mb-1">Phone</label>
              <input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "").slice(0, 10) })}
                type="tel"
                inputMode="numeric"
                pattern="[6-9][0-9]{9}"
                maxLength={10}
                placeholder="9XXXXXXXXX"
                title="Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9."
                className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-blueprint-900 mb-1">Email</label>
            <input type="email" value={form.email} onChange={set("email")}
              className="w-full px-3 py-2 rounded-lg border border-blueprint-100 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 bg-blueprint-50/30" />
          </div>

          {error && <p className="text-sm text-red-600 bg-red-50 border border-red-100 px-3.5 py-2.5 rounded-xl">{error}</p>}

          <button type="submit" disabled={busy || loadingSocieties}
            className="w-full py-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-blueprint-950 font-semibold text-sm transition-colors disabled:opacity-60">
            {busy ? "Submitting…" : "Request Guard Account"}
          </button>
        </form>

        <p className="text-sm text-blueprint-800/70 mt-6 text-center">
          Already have an account?{" "}
          <Link to="/login" className="text-amber-600 font-medium hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}