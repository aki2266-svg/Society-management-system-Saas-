import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { registerSociety } from '../api/auth'
import { ErrorBanner } from '../components/Feedback'

// 🟢 Mobile number restriction: must start with 6/7/8/9 and be exactly 10 digits
const PHONE_REGEX = /^[6-9]\d{9}$/

const initialState = {
  name: '',
  address: '',
  admin_first_name: '',
  admin_last_name: '',
  admin_username: '',
  admin_password: '',
  admin_phone: '',
}

const RegisterSociety = () => {
  const navigate = useNavigate()
  const [formData, setFormData] = useState(initialState)
  const [file, setFile] = useState(null)
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleFileChange = (e) => {
    setFile(e.target.files[0] || null)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (!file) {
      setError('Please upload the society existence verification proof document.')
      return
    }

    if (formData.admin_phone && !PHONE_REGEX.test(formData.admin_phone)) {
      setError('Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.')
      return
    }

    const data = new FormData()
    
    // Explicitly mapping input data keys to exactly match what the Django serializer expects
    data.append('name', formData.name)
    data.append('address', formData.address)
    data.append('verification_proof', file)
    data.append('admin_first_name', formData.admin_first_name)
    data.append('admin_last_name', formData.admin_last_name)
    data.append('admin_username', formData.admin_username)
    data.append('admin_password', formData.admin_password)
    data.append('admin_phone', formData.admin_phone)

    setSubmitting(true)
    try {
      await registerSociety(data)
      navigate('/register-success')
    } catch (err) {
      const payload = err.response?.data
      setError(
        typeof payload === 'string'
          ? payload
          : payload
          ? Object.values(payload).flat().join(' ')
          : 'Something went wrong connecting to the backend.'
      )
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-paper py-10 px-4">
      <div className="max-w-xl mx-auto">
        <Link to="/login" className="text-sm text-blueprint-800/60 hover:text-blueprint-900">
          &larr; Back to login
        </Link>

        <div className="bg-white rounded-2xl shadow-card border border-blueprint-100 p-7 mt-4">
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">Register your society</h1>
          <p className="text-sm text-blueprint-800/60 mt-1 mb-6">
            Submit your society's details along with proof of existence. A platform admin will review and approve
            your account before you can log in.
          </p>

          <ErrorBanner message={error} />

          <form onSubmit={handleSubmit} className="space-y-6">
            <fieldset className="space-y-4">
              <legend className="font-display font-semibold text-blueprint-900 mb-1">Society info</legend>
              <div>
                <label className="block text-sm font-medium text-blueprint-900 mb-1">Society name</label>
                <input
                  name="name"
                  type="text"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blueprint-900 mb-1">Address</label>
                <textarea
                  name="address"
                  required
                  rows={2}
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blueprint-900 mb-1">
                  Verification proof document (.txt)
                </label>
                <input
                  type="file"
                  accept=".txt"
                  required
                  onChange={handleFileChange}
                  className="w-full text-sm text-blueprint-800/80 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-blueprint-100 file:text-blueprint-900 file:text-sm file:font-medium"
                />
                <p className="text-xs text-blueprint-800/50 mt-1">
                  Must include: society name, builders name, no of flats, no of floors, builder signature,
                  government official signature.
                </p>
              </div>
            </fieldset>

            <fieldset className="space-y-4">
              <legend className="font-display font-semibold text-blueprint-900 mb-1">Admin account</legend>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-blueprint-900 mb-1">First name</label>
                  <input
                    name="admin_first_name"
                    type="text"
                    required
                    value={formData.admin_first_name}
                    onChange={handleChange}
                    className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-blueprint-900 mb-1">Last name</label>
                  <input
                    name="admin_last_name"
                    type="text"
                    required
                    value={formData.admin_last_name}
                    onChange={handleChange}
                    className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-blueprint-900 mb-1">Username</label>
                <input
                  name="admin_username"
                  type="text"
                  required
                  value={formData.admin_username}
                  onChange={handleChange}
                  className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blueprint-900 mb-1">Password</label>
                <input
                  name="admin_password"
                  type="password"
                  required
                  value={formData.admin_password}
                  onChange={handleChange}
                  className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-blueprint-900 mb-1">Phone number</label>
                <input
                  name="admin_phone"
                  type="tel"
                  inputMode="numeric"
                  pattern="[6-9][0-9]{9}"
                  maxLength={10}
                  title="Enter a valid 10-digit mobile number starting with 6, 7, 8, or 9."
                  placeholder="9XXXXXXXXX"
                  value={formData.admin_phone}
                  onChange={(e) =>
                    setFormData({ ...formData, admin_phone: e.target.value.replace(/\D/g, '').slice(0, 10) })
                  }
                  className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </fieldset>

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 transition-colors text-blueprint-950 font-semibold py-2.5 rounded-lg text-sm"
            >
              {submitting ? 'Submitting…' : 'Submit registration request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default RegisterSociety