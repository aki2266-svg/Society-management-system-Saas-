import React from 'react'
import { Link } from 'react-router-dom'

const RegisterSuccess = () => (
  <div className="min-h-screen bg-paper flex items-center justify-center p-4">
    <div className="bg-white rounded-2xl shadow-card border border-blueprint-100 p-8 max-w-md text-center">
      <div className="w-12 h-12 rounded-full bg-emerald-500/15 text-emerald-600 flex items-center justify-center mx-auto mb-4 text-2xl">
        ✓
      </div>
      <h1 className="font-display font-semibold text-xl text-blueprint-900">Request submitted</h1>
      <p className="text-sm text-blueprint-800/60 mt-2">
        Your society's registration is pending review. You'll be able to log in once a platform admin approves your
        verification document.
      </p>
      <Link
        to="/login"
        className="inline-block mt-6 bg-blueprint-900 hover:bg-blueprint-800 text-white text-sm font-medium px-5 py-2.5 rounded-lg"
      >
        Back to login
      </Link>
    </div>
  </div>
)

export default RegisterSuccess
