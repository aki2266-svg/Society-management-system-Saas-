import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { listBills, createBill, deleteBill } from '../api/billing'
import { listFlats } from '../api/residents'
import { Loader, EmptyState, ErrorBanner, SuccessBanner } from '../components/Feedback'
import Modal from '../components/Modal'
import Badge from '../components/Badge'

const emptyForm = { flat: '', title: '', amount: '', due_date: '' }

const Bills = () => {
  const [bills, setBills] = useState([])
  const [flats, setFlats] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const [billsRes, flatsRes] = await Promise.all([listBills(), listFlats()])
      setBills(billsRes.data.results || billsRes.data)
      setFlats(flatsRes.data.results || flatsRes.data)
    } catch {
      setError('Could not load bills.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleAdd = async (e) => {
    e.preventDefault()
    setSaving(true)
    setError('')
    try {
      await createBill(form)
      setSuccess('Bill raised.')
      setShowModal(false)
      setForm(emptyForm)
      load()
    } catch {
      setError('Could not raise the bill. Check the details and try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id) => {
    try {
      await deleteBill(id)
      setBills((prev) => prev.filter((b) => b.id !== id))
    } catch {
      setError('Could not remove bill.')
    }
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-semibold text-2xl text-blueprint-900">Bills</h1>
          <p className="text-sm text-blueprint-800/60">Maintenance and other charges raised to flats.</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-amber-500 hover:bg-amber-600 text-blueprint-950 font-semibold text-sm px-4 py-2 rounded-lg"
        >
          + Raise bill
        </button>
      </div>

      <ErrorBanner message={error} />
      <SuccessBanner message={success} />

      {loading ? (
        <Loader />
      ) : bills.length === 0 ? (
        <EmptyState title="No bills yet" subtitle="Raise your first bill to a flat." />
      ) : (
        <div className="bg-white rounded-xl shadow-card border border-blueprint-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-blueprint-100/60 text-blueprint-900 text-left">
              <tr>
                <th className="px-4 py-3 font-semibold">Flat</th>
                <th className="px-4 py-3 font-semibold">Title</th>
                <th className="px-4 py-3 font-semibold">Amount</th>
                <th className="px-4 py-3 font-semibold">Due date</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold"></th>
              </tr>
            </thead>
            <tbody>
              {bills.map((b) => (
                <tr key={b.id} className="border-t border-blueprint-100">
                  <td className="px-4 py-3 font-medium text-blueprint-900">{b.flat_number || b.flat}</td>
                  <td className="px-4 py-3 text-blueprint-800/70">{b.title}</td>
                  <td className="px-4 py-3 text-blueprint-800/70">₹{b.amount}</td>
                  <td className="px-4 py-3 text-blueprint-800/70">{b.due_date}</td>
                  <td className="px-4 py-3">
                    <Badge status={b.status || 'unpaid'} />
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(b.id)} className="text-xs text-red-600 hover:underline">
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <Modal title="Raise a bill" onClose={() => setShowModal(false)}>
          <form onSubmit={handleAdd} className="space-y-3">
            <select
              required
              value={form.flat}
              onChange={(e) => setForm({ ...form, flat: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm bg-white"
            >
              <option value="">Select flat</option>
              {flats.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.flat_number}
                </option>
              ))}
            </select>
            <input
              required
              placeholder="Title (e.g. Monthly maintenance - July)"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                required
                type="number"
                min="0"
                placeholder="Amount"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
              />
              <input
                required
                type="date"
                value={form.due_date}
                onChange={(e) => setForm({ ...form, due_date: e.target.value })}
                className="border border-blueprint-100 rounded-lg px-3 py-2 text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={saving}
              className="w-full bg-amber-500 hover:bg-amber-600 disabled:opacity-60 text-blueprint-950 font-semibold py-2 rounded-lg text-sm"
            >
              {saving ? 'Saving…' : 'Raise bill'}
            </button>
          </form>
        </Modal>
      )}
    </DashboardLayout>
  )
}

export default Bills
