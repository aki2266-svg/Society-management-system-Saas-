
import React, { useState, useEffect, useRef } from 'react'
import { Loader, ErrorBanner, SuccessBanner } from '../components/Feedback'
import client from '../api/client'
import { useAuth } from '../context/AuthContext'
import StatCard from '../components/StatCard'
import StatusBadge from '../components/StatusBadge'


// ---------------------------------------------------------
// AUTO SETUP COMPONENT
// ---------------------------------------------------------

const SetupFlatsForm = ({ onSetupComplete }) => {
  const [numBlocks, setNumBlocks] = useState(2)
  const [floorsPerBlock, setFloorsPerBlock] = useState(4)
  const [flatsPerFloor, setFlatsPerFloor] = useState(4)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const getBlockLetter = (index) =>
    String.fromCharCode(65 + index)

  const handleGenerateAndSubmit = async (e) => {
    e.preventDefault()

    setLoading(true)
    setError('')

    const generatedFlats = []

    for (let b = 0; b < parseInt(numBlocks); b++) {
      const blockLetter = getBlockLetter(b)
      const blockName = `Block ${blockLetter}`

      for (let f = 1; f <= parseInt(floorsPerBlock); f++) {
        for (let unit = 1; unit <= parseInt(flatsPerFloor); unit++) {

          const flatNum =
            `${blockLetter}-${f}${unit
              .toString()
              .padStart(2, '0')}`

          generatedFlats.push({
            flat_number: flatNum,
            block: blockName,
            floor: f
          })
        }
      }
    }

    try {

      for (const flatData of generatedFlats) {
        await client.post('/v1/flats/', flatData)
      }

      onSetupComplete()

    } catch (err) {

      console.error(
        'Failed to auto-generate flats:',
        err
      )

      setError(
        'Failed to auto-generate society flats structure. Check backend API and try again.'
      )

    } finally {
      setLoading(false)
    }
  }

  const totalCalculatedFlats =
    (parseInt(numBlocks) || 0) *
    (parseInt(floorsPerBlock) || 0) *
    (parseInt(flatsPerFloor) || 0)

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-8 animate-in fade-in duration-300">

      <div className="max-w-lg w-full bg-white rounded-2xl border border-blueprint-100 shadow-xl p-6 sm:p-8 space-y-6">

        <div className="text-center space-y-2">

          <span className="text-5xl inline-block mb-1">
            🏢
          </span>

          <h2 className="text-2xl font-bold text-blueprint-950">
            Initial Society Setup
          </h2>

          <p className="text-xs text-blueprint-800/70 max-w-sm mx-auto">
            Specify your building structure. Flat numbers will be automatically generated and registered into your society database.
          </p>

        </div>

        {error && <ErrorBanner message={error} />}

        <form
          onSubmit={handleGenerateAndSubmit}
          className="space-y-5"
        >

          <div>

            <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
              Number of Blocks / Towers
            </label>

            <input
              type="number"
              min="1"
              max="26"
              required
              value={numBlocks}
              onChange={(e) =>
                setNumBlocks(e.target.value)
              }
              className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
              placeholder="e.g. 2 (Block A, Block B)"
            />

          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

            <div>

              <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                Floors per Block
              </label>

              <input
                type="number"
                min="1"
                required
                value={floorsPerBlock}
                onChange={(e) =>
                  setFloorsPerBlock(e.target.value)
                }
                className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                placeholder="e.g. 4"
              />

            </div>

            <div>

              <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                Flats per Floor
              </label>

              <input
                type="number"
                min="1"
                required
                value={flatsPerFloor}
                onChange={(e) =>
                  setFlatsPerFloor(e.target.value)
                }
                className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                placeholder="e.g. 4"
              />

            </div>

          </div>

          <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3.5 text-xs text-amber-900 space-y-1">

            <p className="font-semibold flex items-center gap-1.5">
              <span>💡</span>
              Setup Summary:
            </p>

            <p className="text-amber-800/90">
              Generates <strong>{totalCalculatedFlats} total flats</strong> across {numBlocks} Block(s).
            </p>

          </div>

          <button
            type="submit"
            disabled={
              loading ||
              totalCalculatedFlats <= 0
            }
            className="w-full bg-amber-500 hover:bg-amber-600 active:scale-[0.99] text-blueprint-950 font-semibold py-3.5 rounded-xl transition-all shadow-sm hover:shadow text-sm cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading
              ? <Loader />
              : `Generate ${totalCalculatedFlats} Flats & Proceed`}
          </button>

        </form>

      </div>
    </div>
  )
}


// ---------------------------------------------------------
// MAIN ADMIN DASHBOARD
// ---------------------------------------------------------

export default function AdminDashboard() {

  const { user, logout } = useAuth()

  const isAdmin = Boolean(
    user &&
    (
      user.is_superuser ||
      [
        'society_admin',
        'admin',
        'super_admin'
      ].includes(
        String(user.role || '').toLowerCase()
      )
    )
  )

  // -------------------------------------------------------
  // STATES
  // -------------------------------------------------------

  const [checkingSetup, setCheckingSetup] =
    useState(true)

  const [hasFlats, setHasFlats] =
    useState(false)

  const [activeTab, setActiveTab] =
    useState('overview')

  const [loading, setLoading] =
    useState(false)

  const [error, setError] =
    useState('')

  const [success, setSuccess] =
    useState('')

  const [pending, setPending] =
    useState([])

  const [visitors, setVisitors] =
    useState([])

  const [stats, setStats] =
    useState(null)

  const [busyId, setBusyId] =
    useState(null)

  const [filter, setFilter] =
    useState('')

  const [flatsList, setFlatsList] =
    useState([])

  const [residentsList, setResidentsList] =
    useState([])

  const [complaints, setComplaints] =
    useState([])

  const [loadingComplaints, setLoadingComplaints] =
    useState(false)

  const [workersList, setWorkersList] =
    useState([])

  const [loadingWorkers, setLoadingWorkers] =
    useState(false)

  const [newNotice, setNewNotice] =
    useState({
      title: '',
      content: ''
    })

  const [newEmergency, setNewEmergency] =
    useState({
      service: '',
      contact: '',
      operational_hours: '24/7'
    })

  const [newWorker, setNewWorker] =
    useState({
      name: '',
      role: '',
      phone: '',
      address: '',
      availability: '9 AM - 6 PM'
    })

  const timerRef = useRef(null)


  // -------------------------------------------------------
  // NOTIFICATIONS
  // -------------------------------------------------------

  const showNotification = (
    type,
    message,
    duration = 3000
  ) => {

    if (timerRef.current) {
      clearTimeout(timerRef.current)
    }

    if (type === 'error') {
      setError(message)
      setSuccess('')
    } else {
      setSuccess(message)
      setError('')
    }

    timerRef.current =
      setTimeout(() => {
        setError('')
        setSuccess('')
      }, duration)
  }


  useEffect(() => {

    return () => {

      if (timerRef.current) {
        clearTimeout(timerRef.current)
      }

    }

  }, [])


  // -------------------------------------------------------
  // API RESPONSE HELPER
  // -------------------------------------------------------

  const extractArrayData = (resData) => {

    if (Array.isArray(resData)) {
      return resData
    }

    if (
      resData &&
      typeof resData === 'object'
    ) {

      if (Array.isArray(resData.results)) {
        return resData.results
      }

      if (Array.isArray(resData.data)) {
        return resData.data
      }

    }

    return []
  }


  // -------------------------------------------------------
  // LOAD GATE DATA
  // -------------------------------------------------------

  const loadGateData = async () => {

    try {

      const pendingRes =
        await client.get(
          '/v1/auth/users/pending/'
        )

      setPending(
        extractArrayData(pendingRes.data)
      )

    } catch (err) {

      console.error(
        'Failed to load pending users:',
        err
      )

      setPending([])

    }


    try {

      const visitorRes =
        await client.get(
          '/visitors/',
          {
            params: filter
              ? { status: filter }
              : {}
          }
        )

      setVisitors(
        extractArrayData(visitorRes.data)
      )

    } catch (err) {

      console.error(
        'Failed to load visitors:',
        err
      )

      setVisitors([])

    }


    try {

      const statsRes =
        await client.get(
          '/visitors/stats/'
        )

      setStats(statsRes.data)

    } catch (err) {

      console.error(
        'Failed to load visitor statistics:',
        err
      )

    }

  }


  useEffect(() => {

    loadGateData()

    const id =
      setInterval(
        loadGateData,
        10000
      )

    return () =>
      clearInterval(id)

  }, [filter])


  // -------------------------------------------------------
  // FLATS + RESIDENTS
  // -------------------------------------------------------

  const checkAndFetchData =
    async () => {

      setCheckingSetup(true)

      try {

        const [
          flatsRes,
          residentsRes
        ] = await Promise.all([
          client.get('/v1/flats/'),
          client.get('/v1/residents/')
        ])

        const flatsData =
          extractArrayData(
            flatsRes.data
          )

        const residentsData =
          extractArrayData(
            residentsRes.data
          )

        setFlatsList(flatsData)

        setResidentsList(
          residentsData
        )

        setHasFlats(
          flatsData.length > 0
        )

      } catch (err) {

        console.error(
          'Error verifying flats setup:',
          err
        )

        setFlatsList([])
        setResidentsList([])
        setHasFlats(false)

      } finally {

        setCheckingSetup(false)
        setLoading(false)

      }

    }


  useEffect(() => {

    checkAndFetchData()

  }, [])


  // -------------------------------------------------------
  // COMPLAINTS
  // -------------------------------------------------------

  const fetchComplaints =
    async () => {

      setLoadingComplaints(true)

      try {

        const res =
          await client.get(
            '/v1/complaints/'
          )

        setComplaints(
          extractArrayData(
            res.data
          )
        )

      } catch (err) {

        console.error(
          'Failed to retrieve complaints:',
          err
        )

        showNotification(
          'error',
          'Failed to retrieve complaints.',
          4000
        )

      } finally {

        setLoadingComplaints(false)

      }

    }


  // -------------------------------------------------------
  // WORKERS
  // -------------------------------------------------------

  const fetchWorkers =
    async () => {

      setLoadingWorkers(true)

      try {

        const res =
          await client.get(
            '/v1/numbers/workers/'
          )

        setWorkersList(
          extractArrayData(
            res.data
          )
        )

      } catch (err) {

        console.error(
          'Failed to load workers:',
          err
        )

        showNotification(
          'error',
          'Failed to load maintenance staff.',
          4000
        )

      } finally {

        setLoadingWorkers(false)

      }

    }


  useEffect(() => {

    if (hasFlats) {

      if (
        activeTab === 'complaints'
      ) {
        fetchComplaints()
      }

      if (
        activeTab === 'workers'
      ) {
        fetchWorkers()
      }

    }

  }, [
    activeTab,
    hasFlats
  ])


  // -------------------------------------------------------
  // APPROVE / REJECT USER
  // -------------------------------------------------------

  const approveUser =
    async (id, action) => {

      setBusyId(id)

      try {

        await client.post(
          `/v1/auth/users/${id}/${action}/`
        )

        await loadGateData()

        showNotification(
          'success',
          `User account ${action}d successfully.`
        )

      } catch (err) {

        console.error(
          'User approval error:',
          err
        )

        showNotification(
          'error',
          `Failed to ${action} user account.`,
          4000
        )

      } finally {

        setBusyId(null)

      }

    }


  // -------------------------------------------------------
  // COMPLAINT STATUS
  // -------------------------------------------------------

  const handleUpdateStatus =
    async (
      complaintId,
      newStatus
    ) => {

      try {

        const response =
          await client.patch(
            `/v1/complaints/${complaintId}/`,
            {
              status: newStatus
            }
          )

        showNotification(
          'success',
          'Complaint status updated.'
        )

        setComplaints(
          (prev) =>
            prev.map(
              (c) =>
                c.id === complaintId
                  ? response.data
                  : c
            )
        )

      } catch (err) {

        console.error(
          'Complaint update error:',
          err
        )

        showNotification(
          'error',
          'Could not update complaint status.',
          4000
        )

      }

    }


  // -------------------------------------------------------
  // NOTICE
  // -------------------------------------------------------

  const handleAddNotice =
    async (e) => {

      e.preventDefault()

      try {

        await client.post(
          '/v1/notices/',
          newNotice
        )

        showNotification(
          'success',
          'Notice published successfully!'
        )

        setNewNotice({
          title: '',
          content: ''
        })

      } catch (err) {

        console.error(
          'Notice error:',
          err
        )

        showNotification(
          'error',
          'Failed to submit notice.',
          4000
        )

      }

    }


  // -------------------------------------------------------
  // EMERGENCY
  // -------------------------------------------------------

  const handleAddEmergency =
    async (e) => {

      e.preventDefault()

      try {

        await client.post(
          '/v1/numbers/emergency/',
          newEmergency
        )

        showNotification(
          'success',
          'Emergency hotline added.'
        )

        setNewEmergency({
          service: '',
          contact: '',
          operational_hours: '24/7'
        })

      } catch (err) {

        console.error(
          'Emergency contact error:',
          err
        )

        showNotification(
          'error',
          'Failed to record emergency contact.',
          4000
        )

      }

    }


  // -------------------------------------------------------
  // WORKER
  // -------------------------------------------------------

  const handleAddWorker =
    async (e) => {

      e.preventDefault()

      try {

        const res =
          await client.post(
            '/v1/numbers/workers/',
            newWorker
          )

        showNotification(
          'success',
          'Worker profile registered!'
        )

        setNewWorker({
          name: '',
          role: '',
          phone: '',
          address: '',
          availability: '9 AM - 6 PM'
        })

        setWorkersList(
          (prev) => [
            res.data,
            ...prev
          ]
        )

      } catch (err) {

        console.error(
          'Worker creation error:',
          err
        )

        showNotification(
          'error',
          'Could not save worker profile.',
          4000
        )

      }

    }


  // -------------------------------------------------------
  // DELETE RESIDENT
  // -------------------------------------------------------

  const handleDeleteResident =
    async (
      residentId,
      residentLabel
    ) => {

      if (
        !window.confirm(
          `Remove ${residentLabel || 'this resident'} from the society? This cannot be undone.`
        )
      ) {
        return
      }

      try {

        await client.delete(
          `/v1/residents/${residentId}/`
        )

        showNotification(
          'success',
          'Resident removed successfully.'
        )

        setResidentsList(
          (prev) =>
            prev.filter(
              (r) =>
                r.id !== residentId
            )
        )

      } catch (err) {

        console.error(
          'Delete resident error:',
          err
        )

        if (
          err?.response?.status === 403
        ) {

          showNotification(
            'error',
            'Only society admins can remove residents.',
            4000
          )

        } else {

          showNotification(
            'error',
            'Could not remove resident.',
            4000
          )

        }

      }

    }


  // -------------------------------------------------------
  // DELETE WORKER
  // -------------------------------------------------------

  const handleDeleteWorker =
    async (workerId) => {

      if (
        !window.confirm(
          'Remove this staff profile?'
        )
      ) {
        return
      }

      try {

        await client.delete(
          `/v1/numbers/workers/${workerId}/`
        )

        showNotification(
          'success',
          'Worker profile deleted.'
        )

        setWorkersList(
          (prev) =>
            prev.filter(
              (w) =>
                w.id !== workerId
            )
        )

      } catch (err) {

        console.error(
          'Delete worker error:',
          err
        )

        showNotification(
          'error',
          'Could not delete worker profile.',
          4000
        )

      }

    }


  // -------------------------------------------------------
  // INITIAL SETUP
  // -------------------------------------------------------

  if (checkingSetup) {

    return (
      <div className="py-24 flex justify-center items-center">
        <Loader />
      </div>
    )

  }


  if (!hasFlats) {

    return (
      <SetupFlatsForm
        onSetupComplete={
          () => checkAndFetchData()
        }
      />
    )

  }


  // -------------------------------------------------------
  // UI
  // -------------------------------------------------------

  return (

    <div className="space-y-8 max-w-6xl mx-auto px-4 sm:px-6 py-2 animate-in fade-in duration-300">

      {/* HEADER */}

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-blueprint-100 pb-5 gap-4">

        <div>

          <h1 className="font-display font-bold text-2xl sm:text-3xl text-blueprint-900 tracking-tight mb-1">
            Community Overview & Control Panel
          </h1>

          <p className="text-sm text-blueprint-800/70">
            Welcome back,
            <span className="font-medium text-blueprint-950">
              {' '}
              {user?.username || 'Admin'}
            </span>.
            Approve accounts and manage society activity.
          </p>

        </div>

        <div className="flex items-center gap-3 flex-wrap">

          <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200 shadow-sm">

            <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse" />

            Admin Access Active

          </span>

          {logout && (

            <button
              onClick={logout}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-rose-700 hover:text-rose-800 bg-rose-50 hover:bg-rose-100/80 border border-rose-200/80 rounded-full transition-all cursor-pointer shadow-sm active:scale-95"
            >
              Logout
            </button>

          )}

        </div>

      </div>


      {/* STATS */}

      {stats && (

        <div className="flex gap-4 mb-6 flex-wrap">

          <StatCard
            label="Pending approvals"
            value={pending.length}
            accent="wait"
          />

          <StatCard
            label="Visitors pending"
            value={stats.pending}
            accent="wait"
          />

          <StatCard
            label="Checked in now"
            value={stats.checked_in}
            accent="go"
          />

          <StatCard
            label="Total today"
            value={stats.today_total}
            accent="live"
          />

        </div>

      )}


      {/* TABS */}

      <div className="flex justify-center border-b border-blueprint-100 pb-1">

        <div className="flex overflow-x-auto text-sm gap-2 scrollbar-none max-w-full">

          {[
            'overview',
            'residents',
            'flats',
            'notices',
            'complaints',
            'emergency',
            'workers'
          ].map((tab) => {

            const isActive =
              activeTab === tab

            return (

              <button
                key={tab}
                onClick={() =>
                  setActiveTab(tab)
                }
                className={`relative py-2.5 px-5 font-medium whitespace-nowrap capitalize transition-all duration-200 rounded-lg text-sm ${
                  isActive
                    ? 'text-blueprint-950 font-semibold bg-blueprint-100/50 shadow-sm'
                    : 'text-blueprint-800/60 hover:text-blueprint-900 hover:bg-blueprint-50'
                }`}
              >

                {tab === 'overview'
                  ? 'Gate & Gate Approvals'
                  : tab === 'residents'
                  ? 'Resident Directory'
                  : tab === 'flats'
                  ? 'Flats Roster'
                  : tab === 'emergency'
                  ? 'Hotlines'
                  : tab === 'workers'
                  ? 'Operations Staff'
                  : tab === 'complaints'
                  ? 'Grievance Tickets'
                  : tab}

                {isActive && (
                  <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-amber-500 rounded-full" />
                )}

              </button>

            )

          })}

        </div>

      </div>


      {/* FEEDBACK */}

      {error && (
        <div className="max-w-3xl mx-auto">
          <ErrorBanner message={error} />
        </div>
      )}

      {success && (
        <div className="max-w-3xl mx-auto">
          <SuccessBanner message={success} />
        </div>
      )}


      {loading ? (

        <div className="py-20 flex justify-center items-center">
          <Loader />
        </div>

      ) : (

        <div className="space-y-6">


          {/* =================================================
              OVERVIEW
          ================================================= */}

          {activeTab === 'overview' && (

            <div className="space-y-10 animate-in fade-in duration-300">

              {/* PENDING USERS */}

              <section>

                <h2 className="text-sm font-semibold text-ink-500 uppercase tracking-wider mb-3">
                  Awaiting account approval
                </h2>

                {pending.length === 0 ? (

                  <div className="bg-white border border-dashed border-ink-200 rounded-2xl p-8 text-center text-sm text-ink-400">
                    No pending sign-ups.
                  </div>

                ) : (

                  <div className="space-y-3">

                    {pending.map((u) => (

                      <div
                        key={u.id}
                        className="bg-white rounded-2xl shadow-card border border-ink-100 p-4 flex items-center justify-between"
                      >

                        <div>

                          <p className="font-semibold text-ink-900">

                            {u.first_name}
                            {' '}
                            {u.last_name}

                            <span className="text-xs font-mono text-ink-400 ml-1">
                              @{u.username}
                            </span>

                          </p>

                          <p className="text-xs text-ink-400 mt-0.5">

                            {String(u.role).toLowerCase() === 'resident'
                              ? `Resident · ${u.flat_number || 'no flat set'}`
                              : 'Security guard'}

                            {u.phone &&
                              ` · ${u.phone}`}

                          </p>

                        </div>

                        <div className="flex gap-2">

                          <button
                            disabled={busyId === u.id}
                            onClick={() =>
                              approveUser(
                                u.id,
                                'reject'
                              )
                            }
                            className="px-4 py-2 rounded-xl text-sm font-semibold text-signal-stop bg-signal-stop-soft hover:bg-signal-stop hover:text-white transition-colors disabled:opacity-50"
                          >
                            Reject
                          </button>

                          <button
                            disabled={busyId === u.id}
                            onClick={() =>
                              approveUser(
                                u.id,
                                'approve'
                              )
                            }
                            className="px-4 py-2 rounded-xl text-sm font-semibold text-white bg-signal-go hover:bg-signal-go/90 transition-colors disabled:opacity-50"
                          >
                            Approve
                          </button>

                        </div>

                      </div>

                    ))}

                  </div>

                )}

              </section>


              {/* VISITOR ACTIVITY */}

              <section>

                <div className="flex items-center justify-between mb-3">

                  <h2 className="text-sm font-semibold text-ink-500 uppercase tracking-wider">
                    All visitor activity
                  </h2>

                  <select
                    value={filter}
                    onChange={(e) =>
                      setFilter(e.target.value)
                    }
                    className="text-xs border border-ink-200 rounded-lg px-2.5 py-1.5 bg-white"
                  >

                    <option value="">
                      All statuses
                    </option>

                    <option value="PENDING">
                      Pending
                    </option>

                    <option value="APPROVED">
                      Approved
                    </option>

                    <option value="REJECTED">
                      Rejected
                    </option>

                    <option value="CHECKED_IN">
                      Checked in
                    </option>

                    <option value="CHECKED_OUT">
                      Checked out
                    </option>

                  </select>

                </div>


                <div className="bg-white rounded-2xl shadow-card border border-ink-100 overflow-hidden">

                  <table className="w-full text-sm">

                    <thead>

                      <tr className="text-left text-xs text-ink-400 uppercase tracking-wider border-b border-ink-100">

                        <th className="px-4 py-3 font-semibold">
                          Visitor
                        </th>

                        <th className="px-4 py-3 font-semibold">
                          Flat
                        </th>

                        <th className="px-4 py-3 font-semibold">
                          Logged by
                        </th>

                        <th className="px-4 py-3 font-semibold">
                          Status
                        </th>

                        <th className="px-4 py-3 font-semibold">
                          Requested
                        </th>

                        <th className="px-4 py-3 font-semibold">
                          Checked in
                        </th>

                        <th className="px-4 py-3 font-semibold">
                          Checked out
                        </th>

                      </tr>

                    </thead>

                    <tbody>

                      {visitors.map((v) => (

                        <tr
                          key={v.id}
                          className="border-b border-ink-50 last:border-0"
                        >

                          <td className="px-4 py-3 font-medium">
                            {v.name}
                          </td>

                          <td className="px-4 py-3 text-ink-500">

                            {v.flat_number ? (

                              <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-blueprint-100 text-blueprint-800 text-xs font-semibold">
                                {v.flat_number}
                              </span>

                            ) : (

                              <span className="text-ink-400">
                                —
                              </span>

                            )}

                          </td>

                          <td className="px-4 py-3 text-ink-500">
                            {v.logged_by_name || '—'}
                          </td>

                          <td className="px-4 py-3">
                            <StatusBadge status={v.status} />
                          </td>

                          <td className="px-4 py-3 text-ink-400 font-mono text-xs">
                            {v.requested_at
                              ? new Date(
                                  v.requested_at
                                ).toLocaleString()
                              : '—'}
                          </td>

                          <td className="px-4 py-3 text-ink-400 font-mono text-xs">
                            {v.entry_time
                              ? new Date(
                                  v.entry_time
                                ).toLocaleString()
                              : '—'}
                          </td>

                          <td className="px-4 py-3 text-ink-400 font-mono text-xs">
                            {v.exit_time
                              ? new Date(
                                  v.exit_time
                                ).toLocaleString()
                              : '—'}
                          </td>

                        </tr>

                      ))}

                      {visitors.length === 0 && (

                        <tr>

                          <td
                            colSpan={7}
                            className="px-4 py-6 text-center text-ink-400"
                          >
                            No matching visitor records.
                          </td>

                        </tr>

                      )}

                    </tbody>

                  </table>

                </div>

              </section>

            </div>

          )}


          {/* =================================================
              RESIDENTS
          ================================================= */}

          {activeTab === 'residents' && (

            <div className="bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden animate-in fade-in duration-300">

              <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center justify-between">

                <div className="flex items-center gap-3">

                  <span className="text-xl">
                    👥
                  </span>

                  <div>

                    <h3 className="text-base font-semibold text-blueprint-950">
                      Registered Resident Accounts
                    </h3>

                    <p className="text-xs text-blueprint-800/60">
                      Managed via /api/v1/residents/
                    </p>

                  </div>

                </div>

                <div className="flex items-center gap-3">

                  <span className="text-xs font-semibold bg-blueprint-100 text-blueprint-900 px-3 py-1 rounded-full border border-blueprint-200">
                    Total: {residentsList.length}
                  </span>

                  <button
                    onClick={checkAndFetchData}
                    className="text-xs font-semibold text-blueprint-800 hover:text-blueprint-950 bg-blueprint-100/60 px-3 py-1 rounded-lg border border-blueprint-200 transition-all cursor-pointer"
                  >
                    🔄 Refresh
                  </button>

                </div>

              </div>


              <div className="p-6 sm:p-8">

                {residentsList.length === 0 ? (

                  <div className="text-center py-10 text-blueprint-800/60">
                    <p className="text-sm font-medium">
                      No registered residents found.
                    </p>
                  </div>

                ) : (

                  <div className="overflow-x-auto">

                    <table className="w-full text-left text-sm border-collapse">

                      <thead>

                        <tr className="border-b border-blueprint-100 text-[11px] font-semibold uppercase tracking-wider text-blueprint-800/70 bg-blueprint-50/30">

                          <th className="py-3 px-4">
                            Resident Name / User
                          </th>

                          <th className="py-3 px-4">
                            Email Address
                          </th>

                          <th className="py-3 px-4">
                            Contact Phone
                          </th>

                          <th className="py-3 px-4">
                            Assigned Flat
                          </th>

                          {isAdmin && (
                            <th className="py-3 px-4 text-right">
                              Actions
                            </th>
                          )}

                        </tr>

                      </thead>

                      <tbody className="divide-y divide-blueprint-100/60">

                        {residentsList.map(
                          (resUser, idx) => {

                            const flatNum =
                              resUser.flat_number ||
                              resUser.flat?.flat_number ||
                              resUser.flat?.number

                            const flatBlock =
                              resUser.flat?.block ||
                              resUser.block

                            const residentName =
                              resUser.user?.first_name
                                ? `${resUser.user.first_name} ${resUser.user.last_name || ''}`.trim()
                                : resUser.first_name
                                ? `${resUser.first_name} ${resUser.last_name || ''}`.trim()
                                : resUser.name ||
                                  resUser.username ||
                                  'Resident'

                            return (

                              <tr
                                key={
                                  resUser.id ||
                                  idx
                                }
                                className="hover:bg-blueprint-50/20 transition-colors"
                              >

                                <td className="py-3.5 px-4 font-semibold text-blueprint-950">
                                  👤 {residentName}
                                </td>

                                <td className="py-3.5 px-4 text-blueprint-800/80 font-mono text-xs">
                                  {
                                    resUser.user?.email ||
                                    resUser.email ||
                                    'N/A'
                                  }
                                </td>

                                <td className="py-3.5 px-4 text-blueprint-800/80 font-mono text-xs">
                                  {
                                    resUser.phone ||
                                    resUser.phone_number ||
                                    resUser.user?.phone ||
                                    'N/A'
                                  }
                                </td>

                                <td className="py-3.5 px-4 font-medium text-xs">

                                  {flatNum ? (

                                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/80">

                                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />

                                      Flat {flatNum}

                                      {flatBlock &&
                                        ` (Block ${flatBlock})`}

                                    </span>

                                  ) : (

                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-500 border border-gray-200">
                                      Unassigned
                                    </span>

                                  )}

                                </td>

                                {isAdmin && (

                                  <td className="py-3.5 px-4 text-right">

                                    <button
                                      onClick={() =>
                                        handleDeleteResident(
                                          resUser.id,
                                          residentName
                                        )
                                      }
                                      className="px-3 py-1 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100/80 border border-rose-200/80 rounded-lg transition-all cursor-pointer"
                                    >
                                      Delete 🗑️
                                    </button>

                                  </td>

                                )}

                              </tr>

                            )

                          }
                        )}

                      </tbody>

                    </table>

                  </div>

                )}

              </div>

            </div>

          )}


          {/* =================================================
              FLATS
          ================================================= */}

          {activeTab === 'flats' && (

            <div className="bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden max-w-4xl mx-auto">

              <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center justify-between">

                <div className="flex items-center gap-3">

                  <span className="text-xl">
                    🚪
                  </span>

                  <div>

                    <h3 className="text-base font-semibold text-blueprint-950">
                      Society Flats Directory
                    </h3>

                    <p className="text-xs text-blueprint-800/60">
                      Real-time occupancy roster
                    </p>

                  </div>

                </div>

                <span className="text-xs font-semibold bg-blueprint-100 text-blueprint-900 px-3 py-1 rounded-full border border-blueprint-200">
                  Total: {flatsList.length}
                </span>

              </div>


              <div className="p-6 sm:p-8">

                {flatsList.length === 0 ? (

                  <p className="text-center text-sm text-blueprint-800/60 py-6">
                    No flats registered yet.
                  </p>

                ) : (

                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">

                    {flatsList.map(
                      (flat, idx) => {

                        const isOccupied =
                          flat.is_occupied ||
                          flat.resident_count > 0

                        return (

                          <div
                            key={
                              flat.id ||
                              idx
                            }
                            className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                              isOccupied
                                ? 'bg-rose-50/80 border-rose-200 text-rose-950'
                                : 'bg-emerald-50/30 border-emerald-200 text-emerald-950'
                            }`}
                          >

                            <div>

                              <div className="flex items-center justify-between mb-1">

                                <span className="font-bold text-sm">
                                  Flat {
                                    flat.flat_number ||
                                    flat.number
                                  }
                                </span>

                                <span
                                  className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                                    isOccupied
                                      ? 'bg-rose-200 text-rose-800'
                                      : 'bg-emerald-200 text-emerald-800'
                                  }`}
                                >
                                  {
                                    isOccupied
                                      ? 'Occupied'
                                      : 'Vacant'
                                  }
                                </span>

                              </div>

                              <p className="text-xs opacity-75">
                                {flat.block || 'N/A'}
                                {' '}
                                {
                                  flat.floor
                                    ? `(Floor ${flat.floor})`
                                    : ''
                                }
                              </p>

                            </div>

                          </div>

                        )

                      }
                    )}

                  </div>

                )}

              </div>

            </div>

          )}


          {/* =================================================
              NOTICES
          ================================================= */}

          {activeTab === 'notices' && (

            <div className="max-w-3xl mx-auto bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden animate-in fade-in duration-300">

              <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center gap-3">

                <span className="text-xl">
                  📢
                </span>

                <div>

                  <h3 className="text-base font-semibold text-blueprint-950">
                    Broadcast Public Notice
                  </h3>

                  <p className="text-xs text-blueprint-800/60">
                    Managed via /api/v1/notices/
                  </p>

                </div>

              </div>


              <form
                onSubmit={handleAddNotice}
                className="p-6 sm:p-8 space-y-6"
              >

                <div>

                  <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                    Notice Title
                  </label>

                  <input
                    type="text"
                    required
                    value={newNotice.title}
                    onChange={(e) =>
                      setNewNotice({
                        ...newNotice,
                        title: e.target.value
                      })
                    }
                    className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                    placeholder="e.g. Scheduled Water Maintenance"
                  />

                </div>


                <div>

                  <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                    Message Body
                  </label>

                  <textarea
                    rows="5"
                    required
                    value={newNotice.content}
                    onChange={(e) =>
                      setNewNotice({
                        ...newNotice,
                        content: e.target.value
                      })
                    }
                    className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                    placeholder="Type notice details..."
                  />

                </div>


                <button
                  type="submit"
                  className="w-full bg-amber-500 hover:bg-amber-600 active:scale-[0.99] text-blueprint-950 font-semibold py-3.5 rounded-xl transition-all shadow-sm hover:shadow text-sm cursor-pointer"
                >
                  Publish Announcement
                </button>

              </form>

            </div>

          )}


          {/* =================================================
              COMPLAINTS
          ================================================= */}

          {activeTab === 'complaints' && (

            <div className="max-w-4xl mx-auto bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden animate-in fade-in duration-300">

              <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center justify-between">

                <div className="flex items-center gap-3">

                  <span className="text-xl">
                    🛠️
                  </span>

                  <div>

                    <h3 className="text-base font-semibold text-blueprint-950">
                      Resident Grievances
                    </h3>

                    <p className="text-xs text-blueprint-800/60">
                      Managed via /api/v1/complaints/
                    </p>

                  </div>

                </div>

                <button
                  onClick={fetchComplaints}
                  className="text-xs font-semibold text-blueprint-800 hover:text-blueprint-950 bg-blueprint-100/60 px-3 py-1.5 rounded-lg border border-blueprint-200 transition-all"
                >
                  🔄 Refresh List
                </button>

              </div>


              <div className="p-6 sm:p-8">

                {loadingComplaints ? (

                  <div className="py-12 flex justify-center">
                    <Loader />
                  </div>

                ) : complaints.length === 0 ? (

                  <div className="text-center py-12 text-blueprint-800/60">

                    <p className="text-2xl mb-2">
                      🎉
                    </p>

                    <p className="text-sm font-medium">
                      No active complaints found.
                    </p>

                  </div>

                ) : (

                  <div className="space-y-4">

                    {complaints.map(
                      (item) => (

                        <div
                          key={item.id}
                          className="p-5 border border-blueprint-100 rounded-xl bg-blueprint-50/10 hover:border-blueprint-200 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                        >

                          <div className="space-y-1.5 max-w-xl">

                            <div className="flex items-center gap-2 flex-wrap">

                              <span className="font-semibold text-blueprint-950 text-sm">
                                {item.title}
                              </span>

                              <span className="text-xs px-2 py-0.5 rounded-md font-medium bg-blueprint-100 text-blueprint-800">
                                Flat {
                                  item.flat_number ||
                                  item.resident_flat ||
                                  'N/A'
                                }
                              </span>

                            </div>

                            <p className="text-xs text-blueprint-800/80 leading-relaxed">
                              {
                                item.description ||
                                item.content
                              }
                            </p>

                          </div>


                          <div className="shrink-0 flex items-center gap-2">

                            <select
                              value={
                                item.status ||
                                'pending'
                              }
                              onChange={(e) =>
                                handleUpdateStatus(
                                  item.id,
                                  e.target.value
                                )
                              }
                              className="text-xs font-semibold px-3 py-2 rounded-xl border transition-all cursor-pointer outline-none"
                            >

                              <option value="pending">
                                Pending ⏳
                              </option>

                              <option value="in_progress">
                                In Progress ⚙️
                              </option>

                              <option value="resolved">
                                Resolved ✅
                              </option>

                            </select>

                          </div>

                        </div>

                      )
                    )}

                  </div>

                )}

              </div>

            </div>

          )}


          {/* =================================================
              EMERGENCY
          ================================================= */}

          {activeTab === 'emergency' && (

            <div className="max-w-3xl mx-auto bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden animate-in fade-in duration-300">

              <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center gap-3">

                <span className="text-xl">
                  🚒
                </span>

                <div>

                  <h3 className="text-base font-semibold text-blueprint-950">
                    Register Emergency Hotline
                  </h3>

                  <p className="text-xs text-blueprint-800/60">
                    Managed via /api/v1/numbers/emergency/
                  </p>

                </div>

              </div>


              <form
                onSubmit={handleAddEmergency}
                className="p-6 sm:p-8 space-y-6"
              >

                <div>

                  <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                    Emergency Service / Department
                  </label>

                  <input
                    type="text"
                    required
                    value={newEmergency.service}
                    onChange={(e) =>
                      setNewEmergency({
                        ...newEmergency,
                        service: e.target.value
                      })
                    }
                    className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                    placeholder="e.g. Security Desk, Fire Safety Officer"
                  />

                </div>


                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                  <div>

                    <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                      Direct Contact
                    </label>

                    <input
                      type="text"
                      required
                      value={newEmergency.contact}
                      onChange={(e) =>
                        setNewEmergency({
                          ...newEmergency,
                          contact: e.target.value
                        })
                      }
                      className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                      placeholder="+91 XXXXX XXXXX"
                    />

                  </div>


                  <div>

                    <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                      Operational Hours
                    </label>

                    <input
                      type="text"
                      value={
                        newEmergency.operational_hours
                      }
                      onChange={(e) =>
                        setNewEmergency({
                          ...newEmergency,
                          operational_hours:
                            e.target.value
                        })
                      }
                      className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                    />

                  </div>

                </div>


                <button
                  type="submit"
                  className="w-full bg-amber-500 hover:bg-amber-600 active:scale-[0.99] text-blueprint-950 font-semibold py-3.5 rounded-xl transition-all shadow-sm hover:shadow text-sm cursor-pointer"
                >
                  Add Emergency Resource
                </button>

              </form>

            </div>

          )}


          {/* =================================================
              WORKERS
          ================================================= */}

          {activeTab === 'workers' && (

            <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in duration-300">

              <div className="bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden">

                <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center gap-3">

                  <span className="text-xl">
                    🛠️
                  </span>

                  <div>

                    <h3 className="text-base font-semibold text-blueprint-950">
                      Enroll Operations & Maintenance Staff
                    </h3>

                    <p className="text-xs text-blueprint-800/60">
                      Managed via /api/v1/numbers/workers/
                    </p>

                  </div>

                </div>


                <form
                  onSubmit={handleAddWorker}
                  className="p-6 sm:p-8 space-y-6"
                >

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                    <div>

                      <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                        Worker Full Name
                      </label>

                      <input
                        type="text"
                        required
                        value={newWorker.name}
                        onChange={(e) =>
                          setNewWorker({
                            ...newWorker,
                            name: e.target.value
                          })
                        }
                        className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                        placeholder="Ramesh Kumar"
                      />

                    </div>


                    <div>

                      <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                        Role / Trade Specialty
                      </label>

                      <input
                        type="text"
                        required
                        value={newWorker.role}
                        onChange={(e) =>
                          setNewWorker({
                            ...newWorker,
                            role: e.target.value
                          })
                        }
                        className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                        placeholder="e.g. Electrician, Plumber"
                      />

                    </div>

                  </div>


                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">

                    <div>

                      <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                        Contact Phone
                      </label>

                      <input
                        type="text"
                        required
                        value={newWorker.phone}
                        onChange={(e) =>
                          setNewWorker({
                            ...newWorker,
                            phone: e.target.value
                          })
                        }
                        className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                        placeholder="+91 XXXXX XXXXX"
                      />

                    </div>


                    <div>

                      <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                        Shift Availability
                      </label>

                      <input
                        type="text"
                        value={newWorker.availability}
                        onChange={(e) =>
                          setNewWorker({
                            ...newWorker,
                            availability:
                              e.target.value
                          })
                        }
                        className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                      />

                    </div>

                  </div>


                  <div>

                    <label className="block text-xs font-semibold uppercase tracking-wider text-blueprint-800/80 mb-2">
                      Address Record
                    </label>

                    <input
                      type="text"
                      required
                      value={newWorker.address}
                      onChange={(e) =>
                        setNewWorker({
                          ...newWorker,
                          address: e.target.value
                        })
                      }
                      className="w-full text-sm p-3 rounded-xl border border-blueprint-200 bg-blueprint-50/20 focus:bg-white focus:outline-none focus:border-amber-500 focus:ring-4 focus:ring-amber-500/10 transition-all"
                      placeholder="Local address details..."
                    />

                  </div>


                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 active:scale-[0.99] text-blueprint-950 font-semibold py-3.5 rounded-xl transition-all shadow-sm hover:shadow text-sm cursor-pointer"
                  >
                    Register Staff Profile
                  </button>

                </form>

              </div>


              {/* WORKERS LIST */}

              <div className="bg-white rounded-2xl border border-blueprint-100 shadow-sm overflow-hidden">

                <div className="bg-blueprint-50/50 px-6 sm:px-8 py-4 border-b border-blueprint-100 flex items-center justify-between">

                  <div>

                    <h3 className="text-base font-semibold text-blueprint-950">
                      Active Operations Roster
                    </h3>

                    <p className="text-xs text-blueprint-800/60">
                      Registered maintenance personnel
                    </p>

                  </div>

                  <button
                    onClick={fetchWorkers}
                    className="text-xs font-semibold text-blueprint-800 hover:text-blueprint-950 bg-blueprint-100/60 px-3 py-1.5 rounded-lg border border-blueprint-200 transition-all"
                  >
                    🔄 Refresh List
                  </button>

                </div>


                <div className="p-6 sm:p-8">

                  {loadingWorkers ? (

                    <div className="py-10 flex justify-center">
                      <Loader />
                    </div>

                  ) : workersList.length === 0 ? (

                    <div className="text-center py-10 text-blueprint-800/60">

                      <p className="text-2xl mb-2">
                        👷
                      </p>

                      <p className="text-sm font-medium">
                        No active maintenance personnel registered.
                      </p>

                    </div>

                  ) : (

                    <div className="overflow-x-auto">

                      <table className="w-full text-left text-sm border-collapse">

                        <thead>

                          <tr className="border-b border-blueprint-100 text-[11px] font-semibold uppercase tracking-wider text-blueprint-800/70 bg-blueprint-50/30">

                            <th className="py-3 px-4">
                              Name
                            </th>

                            <th className="py-3 px-4">
                              Role
                            </th>

                            <th className="py-3 px-4">
                              Phone
                            </th>

                            <th className="py-3 px-4 text-right">
                              Actions
                            </th>

                          </tr>

                        </thead>


                        <tbody className="divide-y divide-blueprint-100/60">

                          {workersList.map(
                            (worker) => (

                              <tr
                                key={worker.id}
                                className="hover:bg-blueprint-50/20 transition-colors"
                              >

                                <td className="py-3.5 px-4 font-semibold text-blueprint-950">
                                  {worker.name}
                                </td>

                                <td className="py-3.5 px-4">

                                  <span className="inline-block px-2.5 py-0.5 rounded-md text-xs font-medium bg-amber-50 text-amber-800 border border-amber-200/60">
                                    {worker.role}
                                  </span>

                                </td>

                                <td className="py-3.5 px-4 text-blueprint-800/80 font-mono text-xs">
                                  {worker.phone}
                                </td>

                                <td className="py-3.5 px-4 text-right">

                                  <button
                                    onClick={() =>
                                      handleDeleteWorker(
                                        worker.id
                                      )
                                    }
                                    className="px-3 py-1 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100/80 border border-rose-200/80 rounded-lg transition-all cursor-pointer"
                                  >
                                    Delete 🗑️
                                  </button>

                                </td>

                              </tr>

                            )
                          )}

                        </tbody>

                      </table>

                    </div>

                  )}

                </div>

              </div>

            </div>

          )}

        </div>

      )}

    </div>

  )
}

