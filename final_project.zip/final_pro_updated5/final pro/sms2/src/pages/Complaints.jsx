import React, { useEffect, useState } from 'react'
import DashboardLayout from '../components/DashboardLayout'
import { fetchComplaints as listComplaints } from '../api/complaints'
import { Loader, EmptyState, ErrorBanner } from '../components/Feedback'
import Badge from '../components/Badge'


const nextStatus = { open: 'in_progress', in_progress: 'resolved' }
const nextLabel = { open: 'Start progress', in_progress: 'Mark resolved' }

const Complaints = () => {
  const [complaints, setComplaints] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = async () => {
    setLoading(true)
    try {
      const res = await listComplaints()
      setComplaints(res.data.results || res.data)
    } catch {
      setError('Could not load complaints.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const handleAdvance = async (c) => {
    const status = nextStatus[c.status]
    if (!status) return
    try {
      await updateComplaintStatus(c.id, status)
      setComplaints((prev) => prev.map((item) => (item.id === c.id ? { ...item, status } : item)))
    } catch {
      setError('Could not update complaint status.')
    }
  }

  return (
    <DashboardLayout>
      <h1 className="font-display font-semibold text-2xl text-blueprint-900 mb-1">Complaints</h1>
      <p className="text-sm text-blueprint-800/60 mb-6">Issues raised by residents, from open to resolved.</p>

      <ErrorBanner message={error} />

      {loading ? (
        <Loader />
      ) : complaints.length === 0 ? (
        <EmptyState title="No complaints" subtitle="Residents haven't raised anything yet." />
      ) : (
        <div className="grid gap-3">
          {complaints.map((c) => (
            <div key={c.id} className="bg-white rounded-xl shadow-card border border-blueprint-100 p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium text-blueprint-900">{c.title}</p>
                  <p className="text-xs text-blueprint-800/50 mt-0.5">
                    {c.category ? `${c.category} · ` : ''}
                    Raised by {c.resident_name || 'resident'}
                  </p>
                </div>
                <Badge status={c.status} />
              </div>
              <p className="text-sm text-blueprint-800/70 mt-2">{c.description}</p>
              {nextStatus[c.status] && (
                <button
                  onClick={() => handleAdvance(c)}
                  className="mt-3 text-xs font-semibold bg-blueprint-100 text-blueprint-900 hover:bg-blueprint-100/70 px-3 py-1.5 rounded-md"
                >
                  {nextLabel[c.status]}
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </DashboardLayout>
  )
}

export default Complaints
