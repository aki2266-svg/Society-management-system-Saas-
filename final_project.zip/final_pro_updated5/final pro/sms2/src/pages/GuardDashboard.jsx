
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import client from "../api/client";
import StatCard from "../components/StatCard";
import StatusBadge from "../components/StatusBadge";
import { useAuth } from "../context/AuthContext";

const PURPOSES = [
  { value: "GUEST", label: "Guest" },
  { value: "DELIVERY", label: "Delivery" },
  { value: "CAB", label: "Cab / Auto" },
  { value: "SERVICE", label: "Service" },
  { value: "OTHER", label: "Other" },
];

const EMPTY = {
  name: "",
  phone: "",
  purpose: "GUEST",
  vehicle_number: "",
  resident: "",
};

export default function GuardDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [residents, setResidents] = useState([]);
  const [visitors, setVisitors] = useState([]);
  const [stats, setStats] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [busyId, setBusyId] = useState(null);

  // Load residents, visitors and statistics
  const load = async () => {
    try {
      const [vRes, sRes] = await Promise.all([
        client.get("/visitors/"),
        client.get("/visitors/stats/"),
      ]);

      setVisitors(vRes.data.results || vRes.data);
      setStats(sRes.data);
    } catch (err) {
      console.error("Failed to load visitor data:", err);
    }
  };

  useEffect(() => {
    const loadResidents = async () => {
      try {
        const res = await client.get("/v1/residents/");

        const data = res.data.results || res.data;

        console.log("Residents:", data);

        setResidents(data);
      } catch (err) {
        console.error("Failed to load residents:", err);
      }
    };

    loadResidents();
    load();

    const id = setInterval(load, 8000);

    return () => clearInterval(id);
  }, []);

  const set = (key) => (e) => {
    setForm({
      ...form,
      [key]: e.target.value,
    });
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");

    if (!form.resident) {
      setError("Select which flat this visitor is going to.");
      return;
    }

    setSubmitting(true);

    try {
      await client.post("/visitors/", form);

      setForm(EMPTY);
      load();
    } catch (err) {
      console.error("Visitor submission error:", err);

      setError(
        err.response?.data?.detail ||
          "Couldn't log this visitor. Check the details."
      );
    } finally {
      setSubmitting(false);
    }
  };

  const act = async (id, action) => {
    setBusyId(id);

    try {
      await client.post(`/visitors/${id}/${action}/`);
      load();
    } catch (err) {
      console.error(`Visitor ${action} error:`, err);
    } finally {
      setBusyId(null);
    }
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const active = visitors.filter((v) =>
    ["PENDING", "APPROVED", "CHECKED_IN"].includes(v.status)
  );

  const past = visitors.filter((v) =>
    ["CHECKED_OUT", "REJECTED"].includes(v.status)
  );

  return (
    <div className="max-w-6xl">

      {/* HEADER */}
      <div className="flex items-center justify-between mb-6 pb-4 border-b border-ink-100">
        <div>
          <p className="text-xs text-ink-400 font-mono uppercase tracking-wider">
            Guard
          </p>

          <p className="text-sm font-semibold text-ink-900">
            {user?.first_name || user?.username}
          </p>
        </div>

        <button
          onClick={handleLogout}
          className="px-3.5 py-2 rounded-xl text-xs font-semibold text-signal-stop bg-signal-stop-soft hover:bg-signal-stop hover:text-white transition-colors"
        >
          Sign out
        </button>
      </div>

      <div className="grid lg:grid-cols-[380px_1fr] gap-8">

        {/* LEFT SIDE */}
        <div>

          <h1 className="text-2xl font-display font-semibold mb-1">
            Gate desk
          </h1>

          <p className="text-sm text-ink-400 mb-6">
            Log a new visitor and send the request to their flat.
          </p>

          {/* VISITOR FORM */}
          <form
            onSubmit={submit}
            className="bg-white rounded-2xl shadow-card border border-ink-100 p-5 space-y-4"
          >

            {/* NAME */}
            <div>
              <label className="block text-xs font-semibold text-ink-500 mb-1.5">
                Visitor name
              </label>

              <input
                required
                value={form.name}
                onChange={set("name")}
                className="w-full px-3.5 py-2.5 rounded-xl border border-ink-200 text-sm focus:outline-none focus:ring-2 focus:ring-signal-go/40"
              />
            </div>

            {/* PHONE */}
            <div>
              <label className="block text-xs font-semibold text-ink-500 mb-1.5">
                Phone
              </label>

              <input
                required
                value={form.phone}
                onChange={set("phone")}
                className="w-full px-3.5 py-2.5 rounded-xl border border-ink-200 text-sm focus:outline-none focus:ring-2 focus:ring-signal-go/40"
              />
            </div>

            {/* VISITING FLAT */}
            <div>
              <label className="block text-xs font-semibold text-ink-500 mb-1.5">
                Visiting flat
              </label>

              <select
                required
                value={form.resident}
                onChange={set("resident")}
                className="w-full px-3.5 py-2.5 rounded-xl border border-ink-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-signal-go/40"
              >
                <option value="">
                  Select a flat…
                </option>

                {residents.map((r) => {

                  // Supports different possible serializer structures
                  const flatNumber =
                    r.flat_number ||
                    r.flat ||
                    r.flat?.flat_number ||
                    r.flat?.number ||
                    "Flat not assigned";

                  const firstName =
                    r.first_name ||
                    r.user?.first_name ||
                    "";

                  const lastName =
                    r.last_name ||
                    r.user?.last_name ||
                    "";

                  const fullName =
                    `${firstName} ${lastName}`.trim() ||
                    r.username ||
                    r.name ||
                    "Resident";

                  return (
                    <option key={r.id} value={r.id}>
                      {flatNumber} — {fullName}
                    </option>
                  );
                })}
              </select>
            </div>

            {/* PURPOSE + VEHICLE */}
            <div className="grid grid-cols-2 gap-3">

              <div>
                <label className="block text-xs font-semibold text-ink-500 mb-1.5">
                  Purpose
                </label>

                <select
                  value={form.purpose}
                  onChange={set("purpose")}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-ink-200 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-signal-go/40"
                >
                  {PURPOSES.map((p) => (
                    <option key={p.value} value={p.value}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-ink-500 mb-1.5">
                  Vehicle no.
                </label>

                <input
                  value={form.vehicle_number}
                  onChange={set("vehicle_number")}
                  placeholder="optional"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-ink-200 text-sm focus:outline-none focus:ring-2 focus:ring-signal-go/40"
                />
              </div>

            </div>

            {/* ERROR */}
            {error && (
              <p className="text-sm text-signal-stop bg-signal-stop-soft px-3.5 py-2.5 rounded-xl">
                {error}
              </p>
            )}

            {/* SUBMIT */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-xl bg-ink-950 text-white text-sm font-semibold hover:bg-ink-800 transition-colors disabled:opacity-60"
            >
              {submitting
                ? "Sending…"
                : "Send request to resident"}
            </button>

          </form>

          {/* STATS */}
          {stats && (
            <div className="flex gap-3 mt-6">

              <StatCard
                label="Pending"
                value={stats.pending}
                accent="wait"
              />

              <StatCard
                label="Inside now"
                value={stats.checked_in}
                accent="go"
              />

            </div>
          )}
        </div>

        {/* RIGHT SIDE */}
        <div>

          {/* ACTIVE */}
          <h2 className="text-sm font-semibold text-ink-500 uppercase tracking-wider mb-3">
            Active
          </h2>

          <div className="space-y-3 mb-10">

            {active.length === 0 && (
              <div className="bg-white border border-dashed border-ink-200 rounded-2xl p-8 text-center text-sm text-ink-400">
                No active visitors right now.
              </div>
            )}

            {active.map((v) => (
              <div
                key={v.id}
                className="bg-white rounded-2xl shadow-card border border-ink-100 p-4 flex items-center justify-between gap-4"
              >

                <div>
                  <p className="font-semibold text-ink-900">
                    {v.name}

                    <span className="text-ink-300 font-normal">
                      {" "}
                      · {v.flat_number}
                    </span>
                  </p>

                  <p className="text-xs text-ink-400 mt-0.5">
                    {v.phone}

                    {v.vehicle_number &&
                      ` · ${v.vehicle_number}`}
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0">

                  <StatusBadge status={v.status} />

                  {v.status === "APPROVED" && (
                    <button
                      disabled={busyId === v.id}
                      onClick={() =>
                        act(v.id, "check-in")
                      }
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-signal-live hover:bg-signal-live/90 disabled:opacity-50"
                    >
                      Check in
                    </button>
                  )}

                  {v.status === "CHECKED_IN" && (
                    <button
                      disabled={busyId === v.id}
                      onClick={() =>
                        act(v.id, "check-out")
                      }
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold text-ink-700 bg-ink-100 hover:bg-ink-200 disabled:opacity-50"
                    >
                      Check out
                    </button>
                  )}

                </div>
              </div>
            ))}

          </div>

          {/* LOG */}
          <h2 className="text-sm font-semibold text-ink-500 uppercase tracking-wider mb-3">
            Log
          </h2>

          <div className="bg-white rounded-2xl shadow-card border border-ink-100 overflow-hidden">

            <table className="w-full text-sm">

              <thead>
                <tr className="text-left text-xs text-ink-400 uppercase tracking-wider border-b border-ink-100">
                  <th className="px-4 py-3 font-semibold">
                    Visitor
                  </th>

                  <th className="px-4 py-3 font-semibold">
                    Flat
                  </th>

                  <th className="px-4 py-3 font-semibold">
                    Status
                  </th>
                </tr>
              </thead>

              <tbody>

                {past.map((v) => (
                  <tr
                    key={v.id}
                    className="border-b border-ink-50 last:border-0"
                  >

                    <td className="px-4 py-3 font-medium">
                      {v.name}
                    </td>

                    <td className="px-4 py-3 text-ink-500">
                      {v.flat_number}
                    </td>

                    <td className="px-4 py-3">
                      <StatusBadge status={v.status} />
                    </td>

                  </tr>
                ))}

                {past.length === 0 && (
                  <tr>
                    <td
                      colSpan={3}
                      className="px-4 py-6 text-center text-ink-400"
                    >
                      No completed entries yet.
                    </td>
                  </tr>
                )}

              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  );
}

