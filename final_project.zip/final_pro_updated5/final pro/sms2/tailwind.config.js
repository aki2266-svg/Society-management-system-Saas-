/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        blueprint: {
          950: '#1C1533',
          900: '#241A42',
          800: '#332356',
          700: '#443073',
          100: '#EDE9F9',
        },
        amber: {
          500: '#F0654A',
          600: '#D94F35',
        },
        paper: '#FAF8F4',
        // Neutral text/surface scale used across dashboards, sidebars and
        // status components (previously referenced but never defined).
        ink: {
          0: '#FFFFFF',
          50: '#F8FAFC',
          100: '#EEF1F6',
          200: '#E1E6EE',
          300: '#C9D1DE',
          400: '#94A0B4',
          500: '#64748B',
          700: '#3B4759',
          800: '#27313F',
          900: '#1A212C',
          950: '#10151D',
        },
        // Semantic status colors (pending / active / success / danger)
        // used by StatusBadge and dashboard indicators.
        signal: {
          go: '#16A34A',
          'go-soft': '#DCFCE7',
          stop: '#DC2626',
          'stop-soft': '#FEE2E2',
          wait: '#D97706',
          'wait-soft': '#FEF3C7',
          live: '#0284C7',
          'live-soft': '#E0F2FE',
        },
      },
      boxShadow: {
        card: '0 1px 2px rgba(14,26,46,0.06), 0 1px 12px rgba(14,26,46,0.05)',
        elevated: '0 8px 24px rgba(14,26,46,0.10), 0 2px 6px rgba(14,26,46,0.06)',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, #332356 0%, #1C1533 100%)',
      },
    },
  },
  plugins: [],
}
