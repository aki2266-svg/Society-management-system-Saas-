from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticatedOrReadOnly, AllowAny
from django.contrib.auth import get_user_model
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from django.db import transaction
from .models import Flat, FlatResidentProfile

User = get_user_model()


# ==========================================
# PERMISSIONS
# ==========================================
class IsAdminForDestroy(permissions.IsAuthenticatedOrReadOnly):
    """
    Same read/write behaviour as IsAuthenticatedOrReadOnly for every action,
    except DELETE (the 'destroy' action), which is restricted to Society
    Admins / Super Admins only. Residents and Guards can never delete
    resident records, even if authenticated.
    """

    def has_permission(self, request, view):
        if not super().has_permission(request, view):
            return False

        if getattr(view, 'action', None) == 'destroy':
            user = request.user
            if not (user and user.is_authenticated):
                return False

            role = str(getattr(user, 'role', '')).lower()
            return bool(
                user.is_superuser
                or getattr(user, 'is_super_admin', False)
                or getattr(user, 'is_society_admin', False)
                or role in ['society_admin', 'super_admin']
            )

        return True


# ==========================================
# SERIALIZERS
# ==========================================
class FlatSerializer(serializers.ModelSerializer):
    resident_count = serializers.SerializerMethodField()

    class Meta:
        model = Flat
        fields = ['id', 'flat_number', 'block', 'floor', 'is_occupied', 'resident_count']

    def get_resident_count(self, obj):
        return obj.residents.count()


class ResidentSerializer(serializers.ModelSerializer):
    flat_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)
    flat_number = serializers.CharField(source='flat_profile.flat.flat_number', read_only=True, default=None)
    flat = FlatSerializer(source='flat_profile.flat', read_only=True)

    class Meta:
        model = User
        fields = [
            'id', 'username', 'first_name', 'last_name', 
            'email', 'phone_number', 'flat_id', 'flat_number', 'flat'
        ]

# ==========================================
# MULTI-TENANT VIEWSETS & API VIEWS
# ==========================================


class FlatViewSet(viewsets.ModelViewSet):
    queryset = Flat.objects.all()
    serializer_class = FlatSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        queryset = Flat.objects.all()
        user = self.request.user
        
        # Read query parameters
        society_id = self.request.query_params.get('society_id')
        is_occupied_param = self.request.query_params.get('is_occupied')
        available_only_param = self.request.query_params.get('available_only')

        # -------------------------------------------------------------
        # 1. AUTHENTICATED USERS (Admins / Staff / Logged-in Residents)
        # -------------------------------------------------------------
        if user and user.is_authenticated:
            user_society = getattr(user, 'society', None)
            
            if user_society:
                queryset = queryset.filter(society=user_society)
            elif society_id:
                # Fallback for superadmins managing a specific society by ID
                queryset = queryset.filter(society_id=society_id)

            # Optional: Allow logged-in users to filter by occupancy if requested
            if is_occupied_param is not None:
                is_occupied = is_occupied_param.lower() in ['true', '1']
                queryset = queryset.filter(is_occupied=is_occupied)
            elif available_only_param == 'true':
                queryset = queryset.filter(is_occupied=False)

            return queryset

        # -------------------------------------------------------------
        # 2. UNAUTHENTICATED USERS (Public Resident Registration Form)
        # -------------------------------------------------------------
        if society_id:
            # PUBLIC REGISTRATION MUST ONLY RETURN UNOCCUPIED FLATS
            return queryset.filter(society_id=society_id, is_occupied=False)

        # Safety catch-all for public requests without a society_id parameter
        return Flat.objects.none()

    def perform_create(self, serializer):
        # Automatically attach logged-in admin's society when creating a flat individually
        user_society = getattr(self.request.user, 'society', None)
        serializer.save(society=user_society)


class ResidentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminForDestroy]
    serializer_class = ResidentSerializer

    def get_queryset(self):
        user = self.request.user
        if user and user.is_authenticated:
            return User.objects.filter(society=user.society, role='resident')

        society_id = self.request.query_params.get('society_id')
        if society_id:
            return User.objects.filter(society_id=society_id, role='resident')

        return User.objects.none()

    @transaction.atomic
    def perform_create(self, serializer):
        # 1. Save the new resident user
        user = serializer.save(society=self.request.user.society, role='resident')

        # 2. Extract flat ID from payload (handles direct 'flat_id' or nested data)
        flat_id = self.request.data.get('flat_id') or self.request.data.get('flat')

        if flat_id:
            try:
                flat_obj = Flat.objects.get(id=flat_id)
                
                # 3. Create or update profile assignment
                FlatResidentProfile.objects.update_or_create(
                    user=user,
                    defaults={'flat': flat_obj}
                )

                # 4. Mark flat as occupied in DB
                flat_obj.is_occupied = True
                flat_obj.save(update_fields=['is_occupied'])

            except Flat.DoesNotExist:
                pass

class SetupSocietyStructureView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        num_blocks = int(request.data.get('num_blocks', 0))
        floors_per_block = int(request.data.get('floors_per_block', 1))
        flats_per_floor = int(request.data.get('flats_per_floor', 4))

        # Total flats per block calculation
        flats_per_block = int(request.data.get('flats_per_block', floors_per_block * flats_per_floor))

        if num_blocks <= 0 or flats_per_block <= 0:
            return Response(
                {"error": "Number of blocks and flats per block must be greater than zero."},
                status=status.HTTP_400_BAD_REQUEST
            )

        user = request.user
        society = getattr(user, 'society', None)

        if not society:
            return Response(
                {"error": "No society profile associated with this admin user account."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if Flat.objects.filter(society=society).exists():
            return Response(
                {"error": "Society layout has already been initialized."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            flats_to_create = []

            with transaction.atomic():
                for b_idx in range(1, num_blocks + 1):
                    block_letter = chr(64 + b_idx) if b_idx <= 26 else f"{b_idx}"
                    block_name = f"Block {block_letter}"

                    # Loop through floors and units per floor
                    for f_idx in range(1, floors_per_block + 1):
                        for unit_idx in range(1, flats_per_floor + 1):
                            flat_num_str = f"{block_letter}-{f_idx}{unit_idx:02d}"  # e.g. A-101, A-102

                            flats_to_create.append(
                                Flat(
                                    society=society,
                                    flat_number=flat_num_str,
                                    block=block_name,
                                    floor=f_idx,
                                    is_occupied=False
                                )
                            )

                Flat.objects.bulk_create(flats_to_create)

            return Response({
                "message": "Society structure initialized successfully!",
                "flats_created": len(flats_to_create)
            }, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)