# numbers/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EmergencyNumberViewSet, WorkerViewSet

router = DefaultRouter()
# Handles /api/v1/numbers/workers/ and /api/v1/numbers/workers/<id>/
router.register(r'workers', WorkerViewSet, basename='worker')

# Explicit action mapping for Emergency Numbers
emergency_list = EmergencyNumberViewSet.as_view({
    'get': 'list',
    'post': 'create'
})

emergency_detail = EmergencyNumberViewSet.as_view({
    'get': 'retrieve',
    'put': 'update',
    'patch': 'partial_update',
    'delete': 'destroy'
})

urlpatterns = [
    # 1. Router paths FIRST (/workers/, /workers/<pk>/)
    path('', include(router.urls)),

    # 2. Explicit /emergency/ endpoints
    path('emergency/', emergency_list, name='emergency-number-list'),
    path('emergency/<int:pk>/', emergency_detail, name='emergency-number-detail'),

    # 3. Root endpoints (/api/v1/numbers/ and /api/v1/numbers/<pk>/)
    path('', emergency_list, name='emergency-number-root-list'),
    path('<int:pk>/', emergency_detail, name='emergency-number-root-detail'),
]