from django.shortcuts import render
from rest_framework import serializers, viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Notice, Complaint, Bill

# ==========================================
# 1. SERIALIZERS
# ==========================================
class NoticeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notice
        fields = ['id', 'title', 'content', 'society', 'created_at']
        read_only_fields = ['society']


class ComplaintSerializer(serializers.ModelSerializer):
    class Meta:
        model = Complaint
        fields = '__all__'
        read_only_fields = ['society', 'resident']


class BillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bill
        fields = '__all__'
        read_only_fields = ['society']


# ==========================================
# 2. DASHBOARD METRICS VIEW
# ==========================================
class DashboardOverviewMetricsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        society = getattr(user, 'society', None)

        if not society:
            return Response({
                "notice_count": 0,
                "pending_complaints": 0,
                "unpaid_bills_count": 0
            })

        if getattr(user, 'role', 'resident') == 'society_admin':
            return Response({
                "society_name": society.name,
                "notice_count": Notice.objects.filter(society=society).count(),
                "pending_complaints": Complaint.objects.filter(society=society, status='pending').count(),
                "unpaid_bills_count": Bill.objects.filter(society=society, status='unpaid').count(),
            })
        else:
            return Response({
                "society_name": society.name,
                "notice_count": Notice.objects.filter(society=society).count(),
                "pending_complaints": Complaint.objects.filter(resident=user, status='pending').count(),
                "unpaid_bills_count": Bill.objects.filter(resident=user, status='unpaid').count(),
            })


# ==========================================
# 3. AUTOMATIC CRUD VIEWSETS
# ==========================================
class NoticeViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = NoticeSerializer

    def perform_create(self, serializer):
        user_society = getattr(self.request.user, 'society', None)
        serializer.save(society=user_society)

    def get_queryset(self):
        user_society = getattr(self.request.user, 'society', None)
        if user_society:
            return Notice.objects.filter(society=user_society)
        return Notice.objects.none()


class ComplaintViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = ComplaintSerializer

    def perform_create(self, serializer):
        user = self.request.user
        user_society = getattr(user, 'society', None)
        serializer.save(resident=user, society=user_society)

    def get_queryset(self):
        user_society = getattr(self.request.user, 'society', None)
        if not user_society:
            return Complaint.objects.none()
        
        # Admins see all society complaints; residents only see what they submitted
        if getattr(self.request.user, 'role', 'resident') == 'society_admin':
            return Complaint.objects.filter(society=user_society)
        
        # 🟢 FIXED: Filter by society AND resident correctly
        return Complaint.objects.filter(society=user_society, resident=self.request.user)


class BillViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = BillSerializer

    def perform_create(self, serializer):
        user_society = getattr(self.request.user, 'society', None)
        serializer.save(society=user_society)

    def get_queryset(self):
        user_society = getattr(self.request.user, 'society', None)
        if not user_society:
            return Bill.objects.none()

        if getattr(self.request.user, 'role', 'resident') == 'society_admin':
            return Bill.objects.filter(society=user_society)
        return Bill.objects.filter(society=user_society, resident=self.request.user)