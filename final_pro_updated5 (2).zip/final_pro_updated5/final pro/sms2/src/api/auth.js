import api from './axios'

// 1. POST /api/v1/auth/register-society/ (multipart/form-data)
export const registerSociety = (formData) =>
  api.post('/auth/register-society/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

// 2. FIXED: Unified Login API Endpoint
// Receives username and password straight from AuthContext and passes them in the request body
export const login = (username, password) =>
  api.post('/auth/login/', { 
    username: username, 
    password: password 
  })

// 3. GET /api/v1/auth/me/
export const getCurrentUser = () => api.get('/auth/me/')