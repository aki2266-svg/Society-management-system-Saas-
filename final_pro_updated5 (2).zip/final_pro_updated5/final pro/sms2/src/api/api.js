// src/api/api.js
import axios from 'axios'


const api = axios.create({
  baseURL: 'http://127.0.0.1:8000',
  headers: {
    'Content-Type': 'application/json', // 🟢 Forces JSON parsing in Django
  },
})

// Dynamic Interceptor: Runs RIGHT BEFORE every single HTTP request
api.interceptors.request.use(
  (config) => {
    // Check all token keys used across your app
    const token = 
      localStorage.getItem('sms_token') || 
      localStorage.getItem('access_token') || 
      localStorage.getItem('token')

    if (token) {
      // SimpleJWT requires 'Bearer ', standard DRF TokenAuth requires 'Token '
      config.headers.Authorization = `Bearer ${token}`
    }
    
    return config
  },
  (error) => Promise.reject(error)
)

export default api